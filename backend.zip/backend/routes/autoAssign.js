// const express = require("express");
// const router = express.Router();
// const { poolPromise } = require("../db");

// // 1️⃣ FREE GEOCODING USING OPENSTREETMAP (NO API KEY REQUIRED)
// const https = require("https");

// // lightweight in-memory cache to reduce requests to Nominatim
// const geocodeCache = new Map();

// function fetchJson(url, headers = {}) {
//   return new Promise((resolve, reject) => {
//     const reqUrl = new URL(url);
//     const options = {
//       hostname: reqUrl.hostname,
//       path: reqUrl.pathname + reqUrl.search,
//       method: "GET",
//       headers,
//     };

//     const req = https.request(options, (res) => {
//       let body = "";
//       res.on("data", (chunk) => (body += chunk));
//       res.on("end", () => {
//         try {
//           const json = JSON.parse(body);
//           resolve({ status: res.statusCode, body: json });
//         } catch (e) {
//           reject(new Error("Invalid JSON response from geocoder"));
//         }
//       });
//     });

//     req.on("error", (err) => reject(err));
//     req.end();
//   });
// }

// async function getLatLng(address) {
//   if (!address || !address.trim()) return null;

//   // Normalize and add country to improve results
//   const fullAddress = `${address.trim()}, India`;

//   if (geocodeCache.has(fullAddress)) {
//     return geocodeCache.get(fullAddress);
//   }

//   const url = "https://nominatim.openstreetmap.org/search?" +
//     new URLSearchParams({
//       q: fullAddress,
//       format: "json",
//       limit: 1,
//     });

//   try {
//     // Retry a few times in case of transient network / rate-limit issues
//     const headers = {
//       "User-Agent": "CRM-System/1.0 (contact@yourdomain.com)",
//       "Accept-Language": "en",
//     };

//     const maxAttempts = 3;
//     for (let attempt = 1; attempt <= maxAttempts; attempt++) {
//       try {
//         const { status, body } = await fetchJson(url, headers);

//         if (status >= 200 && status < 300) {
//           if (Array.isArray(body) && body.length > 0) {
//             const coords = { lat: parseFloat(body[0].lat), lng: parseFloat(body[0].lon) };
//             // cache result for 1 hour
//             geocodeCache.set(fullAddress, coords);
//             setTimeout(() => geocodeCache.delete(fullAddress), 1000 * 60 * 60);
//             return coords;
//           }

//           // successful HTTP but empty result
//           console.warn(`Geocode attempt ${attempt}: no results for '${fullAddress}' (status ${status})`);
//           return null;
//         }

//         // Non-2xx response — log body if available for debugging
//         console.warn(`Geocode attempt ${attempt} failed: status=${status} for '${fullAddress}'`);
//         if (body) console.warn("Geocoder response body:", body);
//       } catch (err) {
//         console.error(`Geocode attempt ${attempt} error:`, err && err.message ? err.message : err);
//       }

//       // Exponential backoff before retrying
//       if (attempt < maxAttempts) {
//         const waitMs = 500 * Math.pow(2, attempt - 1);
//         await new Promise((r) => setTimeout(r, waitMs));
//       }
//     }

//     // all attempts failed
//     return null;
//   } catch (err) {
//     // Log and return null so caller can handle gracefully
//     console.error("Geocoding request failed:", err.message || err);
//     return null;
//   }
// }


// // 2️⃣ HAVERSINE FORMULA (DISTANCE IN KM)
// function haversineKm(lat1, lon1, lat2, lon2) {
//   const toRad = (v) => (v * Math.PI) / 180;
//   const R = 6371;

//   const dLat = toRad(lat2 - lat1);
//   const dLon = toRad(lon2 - lon1);

//   const a =
//     Math.sin(dLat / 2) ** 2 +
//     Math.cos(toRad(lat1)) *
//       Math.cos(toRad(lat2)) *
//       Math.sin(dLon / 2) ** 2;

//   return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
// }

// // 3️⃣ MAIN API — ASSIGN NEAREST SERVICE CENTER
// router.post("/assign-service-centre", async (req, res) => {
//   try {
//     const { customerAddress } = req.body;

//     console.log("AutoAssign: received customerAddress:", customerAddress);

//     if (!customerAddress || typeof customerAddress !== "string" || customerAddress.trim().length === 0)
//       return res.status(400).json({ error: "customerAddress is required" });

//     // Clean up address: remove repeated commas and words like 'undefined' or 'null'
//     const cleaned = customerAddress
//       .replace(/undefined|null/gi, "")
//       .split(",")
//       .map((s) => s && s.trim())
//       .filter(Boolean)
//       .join(", ");

//     // 1. Convert customer address → lat/lng, with fallbacks if initial lookup fails
//     let custLoc = await getLatLng(cleaned);

//     // If no result, try candidate fallbacks: PinCode, City+PinCode, City only
//     if (!custLoc) {
//       console.warn("Geocode primary failed for:", cleaned);

//       // try to extract 6-digit Indian PIN code
//       const pinMatch = cleaned.match(/\b(\d{6})\b/);
//       const pin = pinMatch ? pinMatch[1] : null;

//       // try city (assume second part if address was like 'addr, city, state, pin')
//       const parts = cleaned.split(",").map((p) => p.trim()).filter(Boolean);
//       const city = parts.length >= 2 ? parts[parts.length - 2] : parts[0];

//       const fallbackCandidates = [];
//       if (pin) fallbackCandidates.push(`${pin}, India`);
//       if (city && pin) fallbackCandidates.push(`${city}, ${pin}, India`);
//       if (city) fallbackCandidates.push(`${city}, India`);

//       for (const candidate of fallbackCandidates) {
//         console.log("Trying fallback geocode for:", candidate);
//         custLoc = await getLatLng(candidate);
//         if (custLoc) {
//           console.log("Fallback geocode succeeded for:", candidate, custLoc);
//           break;
//         }
//       }
//     }

//     if (!custLoc)
//       return res
//         .status(400)
//         .json({ error: "Unable to geocode customer address", debug: { cleaned } });

//     // 2. Fetch service centers from DB
//     const pool = await poolPromise;
//     const result = await pool
//       .request()
//       .query(
//         "SELECT * FROM ServiceCenters WHERE Latitude IS NOT NULL AND Longitude IS NOT NULL"
//       );

//     const centers = result.recordset;

//     if (!centers.length)
//       return res
//         .status(400)
//         .json({ error: "No service centers with coordinates found" });

//     // 3. Find nearest service center
//     let nearest = null;
//     let minDist = Infinity;

//     for (const c of centers) {
//       const dist = haversineKm(
//         custLoc.lat,
//         custLoc.lng,
//         Number(c.Latitude),
//         Number(c.Longitude)
//       );

//       if (dist < minDist) {
//         minDist = dist;
//         nearest = c;
//       }
//     }

//     if (!nearest)
//       return res
//         .status(500)
//         .json({ error: "Nearest center calculation failed" });

//     const outCity = minDist > 40;

//     return res.json({
//       assigned: true,
//       outCity,
//       distance: minDist.toFixed(2) + " km",
//       serviceCenter: nearest,
//     });
//   } catch (err) {
//     console.error("Auto-Assign Error:", err);
//     res.status(500).json({ error: err.message });
//   }
// });

// // Export router and helper for testing
// module.exports = router;
// module.exports.getLatLng = getLatLng;



// this code is based on city and pincode and then distance
// const express = require("express");
// const router = express.Router();
// const { poolPromise } = require("../db");
// const https = require("https");

// // In-memory cache for geocoding
// const geocodeCache = new Map();

// function fetchJson(url, headers = {}) {
//   return new Promise((resolve, reject) => {
//     const reqUrl = new URL(url);
//     const options = {
//       hostname: reqUrl.hostname,
//       path: reqUrl.pathname + reqUrl.search,
//       method: "GET",
//       headers,
//     };

//     const req = https.request(options, (res) => {
//       let body = "";
//       res.on("data", (chunk) => (body += chunk));
//       res.on("end", () => {
//         try {
//           resolve({ status: res.statusCode, body: JSON.parse(body) });
//         } catch (e) {
//           reject(new Error("Invalid JSON response from geocoder"));
//         }
//       });
//     });

//     req.on("error", (err) => reject(err));
//     req.end();
//   });
// }

// async function getLatLng(address) {
//   if (!address || !address.trim()) return null;

//   const fullAddress = `${address.trim()}, India`;
//   if (geocodeCache.has(fullAddress)) return geocodeCache.get(fullAddress);

//   const url = `https://nominatim.openstreetmap.org/search?${new URLSearchParams({
//     q: fullAddress,
//     format: "json",
//     limit: 1,
//   }).toString()}`;

//   const headers = {
//     "User-Agent": "CRM-System/1.0 (contact@yourdomain.com)",
//     "Accept-Language": "en",
//   };

//   for (let attempt = 1; attempt <= 3; attempt++) {
//     try {
//       const { status, body } = await fetchJson(url, headers);
//       if (status >= 200 && status < 300 && Array.isArray(body) && body.length > 0) {
//         const coords = { lat: parseFloat(body[0].lat), lng: parseFloat(body[0].lon) };
//         geocodeCache.set(fullAddress, coords);
//         setTimeout(() => geocodeCache.delete(fullAddress), 1000 * 60 * 60);
//         return coords;
//       }
//     } catch (err) {
//       if (attempt < 3) await new Promise((r) => setTimeout(r, 500 * Math.pow(2, attempt - 1)));
//     }
//   }

//   return null;
// }

// // Haversine formula for distance in km
// function haversineKm(lat1, lon1, lat2, lon2) {
//   const toRad = (v) => (v * Math.PI) / 180;
//   const R = 6371;
//   const dLat = toRad(lat2 - lat1);
//   const dLon = toRad(lon2 - lon1);
//   const a =
//     Math.sin(dLat / 2) ** 2 +
//     Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
//   return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
// }

// // Assign nearest service center
// router.post("/assign-service-centre", async (req, res) => {
//   try {
//     const { customerAddress } = req.body;
//     if (!customerAddress || !customerAddress.trim())
//       return res.status(400).json({ error: "customerAddress is required" });

//     const cleaned = customerAddress
//       .replace(/undefined|null/gi, "")
//       .split(",")
//       .map((s) => s && s.trim())
//       .filter(Boolean)
//       .join(", ");

//     // Extract PinCode and City for priority
//     const pinMatch = cleaned.match(/\b(\d{6})\b/);
//     const pinCode = pinMatch ? pinMatch[1] : null;

//     const parts = cleaned.split(",").map((p) => p.trim()).filter(Boolean);
//     const city = parts.length >= 2 ? parts[parts.length - 2] : parts[0];

//     // Geocode for latitude/longitude
//     let custLoc = await getLatLng(cleaned);

//     const pool = await poolPromise;
//     const result = await pool
//       .request()
//       .query("SELECT * FROM ServiceCenters WHERE Latitude IS NOT NULL AND Longitude IS NOT NULL");

//     const centers = result.recordset;
//     if (!centers.length) return res.status(400).json({ error: "No service centers found" });

//     // Filter by PinCode first, then by City if PinCode not available
//     let candidateCenters = centers;
//     if (pinCode) {
//       const filteredByPin = centers.filter((c) => c.PinCode == pinCode);
//       if (filteredByPin.length) candidateCenters = filteredByPin;
//     } else if (city) {
//       const filteredByCity = centers.filter((c) => c.City?.toLowerCase() === city.toLowerCase());
//       if (filteredByCity.length) candidateCenters = filteredByCity;
//     }

//     // If geocode exists, find nearest using Haversine
//     let nearest = null;
//     let minDist = Infinity;
//     if (custLoc) {
//       for (const c of candidateCenters) {
//         const dist = haversineKm(custLoc.lat, custLoc.lng, Number(c.Latitude), Number(c.Longitude));
//         if (dist < minDist) {
//           minDist = dist;
//           nearest = c;
//         }
//       }
//     } else {
//       // If no geocode, just pick first candidate (filtered by PinCode/City)
//       nearest = candidateCenters[0];
//       minDist = 0;
//     }

//     const outCity = minDist > 40;

//     res.json({
//       assigned: true,
//       outCity,
//       distance: minDist.toFixed(2) + " km",
//       serviceCenter: nearest,
//     });
//   } catch (err) {
//     console.error("Auto-Assign Error:", err);
//     res.status(500).json({ error: err.message });
//   }
// });

// module.exports = router;
// module.exports.getLatLng = getLatLng;

// previous code 0.0KM distance 

// const express = require("express");
// const router = express.Router();
// const { poolPromise } = require("../db");
// const https = require("https");

// // In-memory cache for geocoding
// const geocodeCache = new Map();

// function fetchJson(url, headers = {}) {
//   return new Promise((resolve, reject) => {
//     const reqUrl = new URL(url);
//     const options = {
//       hostname: reqUrl.hostname,
//       path: reqUrl.pathname + reqUrl.search,
//       method: "GET",
//       headers,
//     };

//     const req = https.request(options, (res) => {
//       let body = "";
//       res.on("data", (chunk) => (body += chunk));
//       res.on("end", () => {
//         try {
//           resolve({ status: res.statusCode, body: JSON.parse(body) });
//         } catch {
//           reject(new Error("Invalid JSON response from geocoder"));
//         }
//       });
//     });

//     req.on("error", (err) => reject(err));
//     req.end();
//   });
// }

// // Geocode using OpenStreetMap
// async function getLatLng(address) {
//   if (!address || !address.trim()) return null;

//   const fullAddress = `${address.trim()}, India`;
//   if (geocodeCache.has(fullAddress)) return geocodeCache.get(fullAddress);

//   const url = `https://nominatim.openstreetmap.org/search?${new URLSearchParams({
//     q: fullAddress,
//     format: "json",
//     limit: 1,
//   }).toString()}`;

//   const headers = {
//     "User-Agent": "CRM-System/1.0 (contact@yourdomain.com)",
//     "Accept-Language": "en",
//   };

//   for (let attempt = 1; attempt <= 3; attempt++) {
//     try {
//       const { status, body } = await fetchJson(url, headers);
//       if (status >= 200 && status < 300 && Array.isArray(body) && body.length > 0) {
//         const coords = { lat: parseFloat(body[0].lat), lng: parseFloat(body[0].lon) };
//         geocodeCache.set(fullAddress, coords);
//         setTimeout(() => geocodeCache.delete(fullAddress), 1000 * 60 * 60); // 1 hour cache
//         return coords;
//       }
//     } catch (err) {
//       if (attempt < 3) await new Promise((r) => setTimeout(r, 500 * Math.pow(2, attempt - 1)));
//     }
//   }

//   return null;
// }

// // Haversine formula
// function haversineKm(lat1, lon1, lat2, lon2) {
//   const toRad = (v) => (v * Math.PI) / 180;
//   const R = 6371;
//   const dLat = toRad(lat2 - lat1);
//   const dLon = toRad(lon2 - lon1);
//   const a =
//     Math.sin(dLat / 2) ** 2 +
//     Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
//   return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
// }

// // POST /assign-service-centre
// router.post("/assign-service-centre", async (req, res) => {
//   try {
//     const { customerAddress } = req.body;
//     if (!customerAddress || !customerAddress.trim())
//       return res.status(400).json({ error: "customerAddress is required" });

//     // Clean address
//     const cleaned = customerAddress
//       .replace(/undefined|null/gi, "")
//       .split(",")
//       .map((s) => s && s.trim())
//       .filter(Boolean)
//       .join(", ");

//     // Extract PinCode and City
//     const pinMatch = cleaned.match(/\b(\d{6})\b/);
//     const pinCode = pinMatch ? pinMatch[1] : null;

//     const parts = cleaned.split(",").map((p) => p.trim()).filter(Boolean);
//     const city = parts.length >= 2 ? parts[parts.length - 2] : parts[0];

//     // Geocode
//     let custLoc = await getLatLng(cleaned);

//     const pool = await poolPromise;
//     const result = await pool
//       .request()
//       .query("SELECT * FROM ServiceCenters WHERE Latitude IS NOT NULL AND Longitude IS NOT NULL");
//     const centers = result.recordset;

//     if (!centers.length) return res.status(400).json({ error: "No service centers found" });

//     // 1️⃣ Filter by PinCode first
//     let candidateCenters = centers;
//     if (pinCode) {
//       const filtered = centers.filter((c) => c.PinCode == pinCode);
//       if (filtered.length) candidateCenters = filtered;
//     }
//     // 2️⃣ Then by City if no PinCode match
//     else if (city) {
//       const filtered = centers.filter((c) => c.City?.toLowerCase() === city.toLowerCase());
//       if (filtered.length) candidateCenters = filtered;
//     }

//     // 3️⃣ Nearest by Haversine distance
//     let nearest = candidateCenters[0];
//     let minDist = 0;
//     if (custLoc) {
//       minDist = Infinity;
//       for (const c of candidateCenters) {
//         const dist = haversineKm(custLoc.lat, custLoc.lng, Number(c.Latitude), Number(c.Longitude));
//         if (dist < minDist) {
//           minDist = dist;
//           nearest = c;
//         }
//       }
//     }

//     const outCity = minDist > 40;

//     res.json({
//       assigned: true,
//       outCity,
//       distance: minDist.toFixed(2) + " km",
//       serviceCenter: nearest,
//     });
//   } catch (err) {
//     console.error("Auto-Assign Error:", err);
//     res.status(500).json({ error: err.message });
//   }
// });

// module.exports = router;
// module.exports.getLatLng = getLatLng;

// routes/autoAssign.js


// const express = require("express");
// const router = express.Router();
// const { poolPromise } = require("../db");
// const https = require("https");

// // ===============================================
// // GEO CACHE
// // ===============================================
// const geocodeCache = new Map();

// // ----- GENERIC FETCH WRAPPER -----
// function fetchJson(url, headers = {}) {
//   return new Promise((resolve, reject) => {
//     const req = https.get(
//       url,
//       { headers: { "User-Agent": "CRM-System", ...headers } },
//       (res) => {
//         let data = "";
//         res.on("data", (chunk) => (data += chunk));
//         res.on("end", () => {
//           try {
//             resolve(JSON.parse(data));
//           } catch (error) {
//             reject("Invalid JSON response");
//           }
//         });
//       }
//     );

//     req.on("error", (e) => reject(e));
//   });
// }

// // ===============================================
// // GEOCODING USING OPENSTREETMAP
// // ===============================================
// async function geocodeAddress(address) {
//   if (!address) return null;

//   if (geocodeCache.has(address)) return geocodeCache.get(address);

//   const url =
//     "https://nominatim.openstreetmap.org/search?format=json&q=" +
//     encodeURIComponent(address);

//   try {
//     const result = await fetchJson(url);

//     if (!result || result.length === 0) return null;

//     const loc = {
//       lat: parseFloat(result[0].lat),
//       lon: parseFloat(result[0].lon),
//     };

//     geocodeCache.set(address, loc);
//     return loc;
//   } catch (err) {
//     console.log("Geocode Error:", err);
//     return null;
//   }
// }

// // ===============================================
// // OSRM ROAD DISTANCE
// // ===============================================
// async function getRoadDistance(lat1, lon1, lat2, lon2) {
//   const url = `https://router.project-osrm.org/route/v1/driving/${lon1},${lat1};${lon2},${lat2}?overview=false`;

//   try {
//     const data = await fetchJson(url);

//     if (!data || !data.routes || !data.routes[0]) return null;

//     return data.routes[0].distance / 1000; // meters → KM
//   } catch (err) {
//     console.log("OSRM Error:", err);
//     return null;
//   }
// }

// // ===============================================
// // HAVERSINE FALLBACK
// // ===============================================
// function haversine(lat1, lon1, lat2, lon2) {
//   const R = 6371;

//   const dLat = ((lat2 - lat1) * Math.PI) / 180;
//   const dLon = ((lon2 - lon1) * Math.PI) / 180;

//   const a =
//     Math.sin(dLat / 2) ** 2 +
//     Math.cos(lat1 * (Math.PI / 180)) *
//       Math.cos(lat2 * (Math.PI / 180)) *
//       Math.sin(dLon / 2) ** 2;

//   return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
// }

// // ===============================================
// // MAIN API ROUTE — /api/auto/assign
// // ===============================================
// async function findNearestCenter({ pincode, customerAddress }) {
//   if (!pincode && !customerAddress) throw new Error("Customer pincode or address is required");

//   // get customer location (try address first, then pincode)
//   const customerLocation = (await geocodeAddress(customerAddress)) || (await geocodeAddress(pincode));
//   if (!customerLocation) throw new Error("Unable to locate customer");

//   // fetch centers
//   const pool = await poolPromise;
//   const result = await pool.request().query("SELECT * FROM ServiceCenters");
//   const serviceCenters = result.recordset || [];
//   if (!serviceCenters.length) throw new Error("No service centers in DB");

//   let bestCenter = null;
//   let minDistance = Infinity;

//   for (const center of serviceCenters) {
//     // Prefer stored coordinates if present
//     let centerLat = center.Latitude || center.Lat || null;
//     let centerLon = center.Longitude || center.Lon || null;

//     let centerLoc = null;
//     if (centerLat && centerLon) {
//       centerLoc = { lat: Number(centerLat), lon: Number(centerLon) };
//     } else if (center.Address) {
//       centerLoc = await geocodeAddress(center.Address);
//       if (!centerLoc) continue;
//     } else {
//       continue;
//     }

//     // compute road distance then fallback to haversine
//     let distance = await getRoadDistance(
//       centerLoc.lat,
//       centerLoc.lon,
//       customerLocation.lat,
//       customerLocation.lon
//     );

//     if (distance === null || typeof distance === "undefined") {
//       distance = haversine(centerLoc.lat, centerLoc.lon, customerLocation.lat, customerLocation.lon);
//     }

//     // ensure numeric
//     distance = Number(distance);

//     const name = center.CenterName || center.Name || center.centerName || "(unnamed)";
//     console.log(`Distance to ${name}: ${distance} km`);

//     if (distance < minDistance) {
//       minDistance = distance;
//       bestCenter = center;
//     }
//   }

//   if (!bestCenter) throw new Error("No service centers reachable");

//   return { bestCenter, minDistance };
// }

// router.post("/assign", async (req, res) => {
//   try {
//     const { pincode, customerAddress } = req.body;
//     const { bestCenter, minDistance } = await findNearestCenter({ pincode, customerAddress });
//     const isOutCity = Number(minDistance) > 20;
//     return res.json({ serviceCenter: bestCenter, distance: `${Number(minDistance).toFixed(2)} km`, outCity: isOutCity });
//   } catch (err) {
//     console.error("Auto-Assign Error:", err && err.message ? err.message : err);
//     res.status(500).json({ error: err.message || String(err) });
//   }
// });

// // Alias route to support existing frontend calls
// router.post("/assign-service-centre", async (req, res) => {
//   try {
//     const { pincode, customerAddress } = req.body;
//     const { bestCenter, minDistance } = await findNearestCenter({ pincode, customerAddress });
//     const isOutCity = Number(minDistance) > 20;
//     return res.json({ serviceCenter: bestCenter, distance: `${Number(minDistance).toFixed(2)} km`, outCity: isOutCity });
//   } catch (err) {
//     console.error("Auto-Assign Error (alias):", err && err.message ? err.message : err);
//     res.status(500).json({ error: err.message || String(err) });
//   }
// });

// module.exports = router;
// module.exports.findNearestCenter = findNearestCenter;


// which one of the following is nearer to this location
  // Plot No 12, Sector-22 Opp. Nerul Railway Station W, Phase II, Nerul, Navi Mumbai, Maharashtra 400706  
  // which one of the following is nearer to this above location
  // Sector-3, Near D-Mart, Nerul, Navi Mumbai, Maharashtra 400706
  //Sector-4, Near Palm Beach Road, Nerul, Navi Mumbai, Maharashtra 400706

  





  
const express = require("express");
const router = express.Router();
const { poolPromise } = require("../db");
const https = require("https");

// ===============================================
// GEO CACHE
// ===============================================
const geocodeCache = new Map();

// Geocode address using OpenStreetMap Nominatim (no API key needed)
async function geocodeAddress(query) {
  if (!query) return null;
  const key = String(query).trim();
  if (geocodeCache.has(key)) return geocodeCache.get(key);

  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(key + ', India')}`;

  // helper using https if global fetch is not available
  const fetchWithHttps = (url, headers = {}) =>
    new Promise((resolve, reject) => {
      const req = https.get(url, { headers: { 'User-Agent': 'CRM-System', ...headers } }, (res) => {
        let data = '';
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      });
      req.on('error', reject);
    });

  try {
    let data;
    if (typeof fetch === 'function') {
      const res = await fetch(url, { headers: { 'User-Agent': 'CRM-System' } });
      data = await res.json();
    } else {
      data = await fetchWithHttps(url, { 'User-Agent': 'CRM-System' });
    }

    if (!data || !data.length) {
      console.debug('Geocode no results for:', key);
      return null;
    }

    const loc = { lat: Number(data[0].lat), lon: Number(data[0].lon) };
    geocodeCache.set(key, loc);
    // expire cache in 1 hour
    setTimeout(() => geocodeCache.delete(key), 1000 * 60 * 60);
    return loc;
  } catch (err) {
    console.error('Geocode error for', key, err && (err.message || err));
    return null;
  }
}

// Haversine fallback
function haversine(lat1, lon1, lat2, lon2) {
  const toRad = (v) => (v * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Bing Maps road distance
async function getBingRoadDistance(lat1, lon1, lat2, lon2) {
  const bingKey = "YOUR_BING_API_KEY_HERE"; // <-- Replace with your key
  const url = `https://dev.virtualearth.net/REST/v1/Routes/Driving?wp.0=${lat1},${lon1}&wp.1=${lat2},${lon2}&key=${bingKey}`;

  try {
    const res = await fetch(url);
    const data = await res.json();
    if (
      data.resourceSets &&
      data.resourceSets[0].resources &&
      data.resourceSets[0].resources[0]
    ) {
      return data.resourceSets[0].resources[0].travelDistance; // in km
    }
    return null;
  } catch (err) {
    console.error("Bing route error:", err);
    return null;
  }
}

// -------------------------------
// findNearestCenter helper
// -------------------------------
async function findNearestCenter({ pincode, customerAddress, lat, lon, customer }) {
  // If customer object provided, override address/pincode
  if (customer) {
    pincode = pincode || customer.PinCode || customer.Pin;
    customerAddress =
      customerAddress ||
      [customer.Address, customer.City, customer.State, customer.PinCode]
        .filter(Boolean)
        .join(", ");
  }

  // get customer location
  let customerLoc = null;
  const tried = { attempts: [] };
  if (lat && lon) {
    customerLoc = { lat: Number(lat), lon: Number(lon) };
    tried.attempts.push({ type: 'coords', value: customerLoc });
  } else if (customerAddress) {
    tried.attempts.push({ type: 'address', value: customerAddress });
    customerLoc = await geocodeAddress(customerAddress);
  }

  if (!customerLoc && pincode) {
    tried.attempts.push({ type: 'pincode', value: pincode });
    customerLoc = await geocodeAddress(pincode);
  }

  if (!customerLoc) {
    const err = new Error('Unable to locate customer');
    err.debug = tried;
    throw err;
  }

  // fetch centers in same city/pincode first
  const pool = await poolPromise;

  // Prefer centers in same city if we can extract city from address
  let city = null;
  if (customer && (customer.City || customer.city)) city = customer.City || customer.city;
  else if (customerAddress) {
    const parts = customerAddress.split(",").map((p) => p.trim()).filter(Boolean);
    if (parts.length >= 2) city = parts[parts.length - 2];
  }

  // Query centers; we'll filter in JS to keep SQL simple
  const result = await pool.request().query("SELECT * FROM ServiceCenters");
  let centers = result.recordset || [];

  // Filter by city first, then by pincode
  let candidateCenters = [];
  if (city) {
    candidateCenters = centers.filter((c) => (c.City && c.City.toLowerCase() === city.toLowerCase()));
  }
  if (!candidateCenters.length && pincode) {
    candidateCenters = centers.filter((c) => String(c.PinCode || c.PinCode) === String(pincode));
  }
  // If still empty, fallback to all centers in same state
  if (!candidateCenters.length && customer && (customer.State || customer.state)) {
    candidateCenters = centers.filter((c) => (c.State && c.State.toLowerCase() === (customer.State || customer.state).toLowerCase()));
  }

  // final fallback: all centers
  if (!candidateCenters.length) candidateCenters = centers;

  let bestCenter = null;
  let minDistance = Infinity;

  for (const c of candidateCenters) {
    // prefer stored coords
    let centerLoc = null;
    if (c.Latitude && c.Longitude) centerLoc = { lat: Number(c.Latitude), lon: Number(c.Longitude) };
    else if (c.Address) centerLoc = await geocodeAddress([c.Address, c.City, c.State, c.PinCode].filter(Boolean).join(', '));
    if (!centerLoc) continue;

    // compute distance: prefer OSRM/road distance if available, else haversine
    let dist = null;
    // try OSRM
    try {
      const road = await getRoadDistance(centerLoc.lat, centerLoc.lon, customerLoc.lat, customerLoc.lon);
      if (road !== null && typeof road !== 'undefined') dist = road;
    } catch (e) {
      // ignore
    }

    if (dist === null) {
      dist = haversine(centerLoc.lat, centerLoc.lon, customerLoc.lat, customerLoc.lon);
    }

    if (typeof dist !== 'number' || Number.isNaN(dist)) {
      console.debug('Skipping center due to invalid distance', { center: c.CenterName || c.Name || c.CenterName, dist });
      continue;
    }

    // Detailed log for debugging distance calculation
    console.log('Distance calc:', {
      center: c.CenterName || c.Name || c.CenterName || '(unnamed)',
      centerLoc,
      customerLoc,
      distance: dist,
    });

    if (dist < minDistance) {
      minDistance = dist;
      bestCenter = c;
    }
  }

  if (!bestCenter) throw new Error('No reachable service center found');

  return { bestCenter, minDistance };
}

// Route to assign nearest service center
router.post("/assign-service-centre", async (req, res) => {
  try {
    const { pincode, customerAddress, lat, lon, customer } = req.body;
    const { bestCenter, minDistance } = await findNearestCenter({ pincode, customerAddress, lat, lon, customer });

    const outCity = Number(minDistance) > 40; // 40 km threshold

    res.json({
      serviceCenter: bestCenter,
      distance: Number(minDistance).toFixed(2) + " km",
      outCity,
    });
  } catch (err) {
    console.error('Assign error:', err && (err.message || err));
    // if geocode helper attached debug info, return it for easier diagnosis
    const payload = { error: err.message || String(err) };
    if (err && err.debug) payload.debug = err.debug;
    res.status(500).json(payload);
  }
});

module.exports = router;
// Export helper for external use (server-level alias)
module.exports.findNearestCenter = findNearestCenter;



//Using MapMyIndia api for distance calculation 
// const express = require("express");
// const router = express.Router();
// const fetch = require("node-fetch");
// const { poolPromise } = require("./db"); // your MSSQL pool

// // Use a cache to avoid repeated geocoding or repeated distance-matrix calls
// const geoCache = new Map();

// // Geocode using MapMyIndia (or you can use Nominatim if you want free geocoding)
// async function geocodeAddressMappls(address, apiKey) {
//   if (!address) return null;
//   if (geoCache.has(address)) return geoCache.get(address);

//   // MapMyIndia geocode API (Mappls) – you can use their Geocoding API
//   // But here, for simplicity, let's do a very basic Mappls reverse route trick;
//   // Instead, you could call their Geocode API endpoint.
//   const url = `https://atlas.mapmyindia.com/api/places/geocode/json?address=${encodeURIComponent(
//     address
//   )}&access_token=${apiKey}`;

//   try {
//     const res = await fetch(url);
//     const data = await res.json();
//     if (data && data.results && data.results.length) {
//       const loc = {
//         lat: Number(data.results[0].lat),
//         lon: Number(data.results[0].lng),
//       };
//       geoCache.set(address, loc);
//       return loc;
//     }
//     return null;
//   } catch (err) {
//     console.error("Geocoding (Mappls) error:", err);
//     return null;
//   }
// }

// // Function to call MapMyIndia Distance Matrix API
// async function getMapplsDistanceMatrix(
//   origin,
//   destinations,
//   apiKey
// ) {
//   // origin: { lat, lon }
//   // destinations: array of { lat, lon }

//   // Build coordinate string: “lon,lat;lon,lat;…”
//   const coords = [origin, ...destinations]
//     .map((pt) => `${pt.lon},${pt.lat}`)
//     .join(";");

//   // Mappls API URL (Distance Matrix)
//   const url = `https://route.mappls.com/route/dm/distance_matrix/driving/${coords}?access_token=${apiKey}`;

//   try {
//     const res = await fetch(url);
//     const data = await res.json();
//     return data;
//   } catch (err) {
//     console.error("Mappls distance matrix error:", err);
//     return null;
//   }
// }

// // Your route: /assign-service-centre
// router.post("/assign-service-centre", async (req, res) => {
//   try {
//     const { pincode, customerAddress, lat, lon } = req.body;
//     const API_KEY = process.env.MAPPLS_API_KEY; // set this in your .env

//     if (!API_KEY) {
//       return res
//         .status(500)
//         .json({ error: "Mappls API Key not configured" });
//     }

//     // Determine customer location
//     let customerLoc = null;
//     if (lat != null && lon != null) {
//       customerLoc = { lat: Number(lat), lon: Number(lon) };
//     } else {
//       customerLoc = await geocodeAddressMappls(customerAddress, API_KEY);
//     }

//     if (!customerLoc) {
//       return res.status(400).json({ error: "Cannot geocode customer address" });
//     }

//     // Fetch service centers from DB
//     const pool = await poolPromise;
//     const result = await pool.request().query("SELECT * FROM ServiceCenters");
//     const centers = result.recordset;

//     // Prepare destinations for distance matrix
//     const dests = centers.map((c) => {
//       return {
//         lat: Number(c.Latitude),
//         lon: Number(c.Longitude),
//         id: c.ServiceCenterId,   // or whatever your DB uses
//       };
//     });

//     // Call Mappls Distance Matrix API
//     const matrixResp = await getMapplsDistanceMatrix(customerLoc, dests, API_KEY);
//     if (!matrixResp || !matrixResp.results) {
//       return res
//         .status(500)
//         .json({ error: "Distance matrix API failed" });
//     }

//     // matrixResp.results.distances is a 2D array: [[0, d1, d2, …]]
//     const distances = matrixResp.results.distances[0]; // distances from origin to each dest
//     // durations can also be read similarly
//     const durations = matrixResp.results.durations[0];

//     // Find the minimum
//     let minDist = Infinity;
//     let bestIndex = -1;
//     distances.forEach((d, i) => {
//       if (i === 0) return; // skip origin → origin
//       if (d < minDist) {
//         minDist = d;
//         bestIndex = i;
//       }
//     });

//     if (bestIndex < 0) {
//       return res
//         .status(500)
//         .json({ error: "Could not find a nearest service center" });
//     }

//     const bestCenter = centers[bestIndex - 1]; // because distances array index 1 → first destination
//     const bestDuration = durations[bestIndex];

//     // Out-city rule: example — mark out-city if distance > 40 km
//     const outCity = minDist / 1000 > 40; // distances in meters

//     res.json({
//       serviceCenter: bestCenter,
//       distance: (minDist / 1000).toFixed(2) + " km",
//       durationSec: bestDuration,
//       outCity,
//     });
//   } catch (err) {
//     console.error("Assign error:", err);
//     res.status(500).json({ error: "Server error" });
//   }
// });

// module.exports = router;

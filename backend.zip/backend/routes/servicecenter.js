// backend/routes/servicecenter.js
const express = require("express");
const router = express.Router();
const { poolPromise } = require("../db");
const fetch = global.fetch || require("node-fetch");

async function getLatLng(address) {
  const apiKey = process.env.GOOGLE_GEOCODE_API_KEY;
  if (!apiKey) throw new Error("Missing GOOGLE_GEOCODE_API_KEY env var");
  const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(address)}&key=${apiKey}`;
  const res = await fetch(url);
  const data = await res.json();
  if (data.status === "OK" && data.results.length) return data.results[0].geometry.location;
  return null;
}

router.post("/add", async (req, res) => {
  try {
    const { CenterName, Address, City, State, PinCode, ContactPerson, Phone } = req.body;
    const full = `${Address}, ${City}, ${State}, ${PinCode}`;
    const loc = await getLatLng(full);
    if (!loc) return res.status(400).json({ error: "Could not geocode center address" });

    const pool = await poolPromise;
    await pool.request()
      .input("CenterName", CenterName)
      .input("Address", Address)
      .input("City", City)
      .input("State", State)
      .input("PinCode", PinCode)
      .input("Latitude", loc.lat)
      .input("Longitude", loc.lng)
      .input("ContactPerson", ContactPerson)
      .input("Phone", Phone)
      .query(`
        INSERT INTO ServiceCenters (CenterName, Address, City, State, PinCode, Latitude, Longitude, ContactPerson, Phone)
        VALUES (@CenterName, @Address, @City, @State, @PinCode, @Latitude, @Longitude, @ContactPerson, @Phone)
      `);

    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message || "Failed to add center" });
  }
});

router.get("/all", async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query("SELECT * FROM ServiceCenters");
    res.json(result.recordset || []);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch centers" });
  }
});

module.exports = router;

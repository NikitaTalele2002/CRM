// const express = require("express");
// const router = express.Router();
// const sql = require("mssql");

// // CREATE COMPLAINT
// router.post("/", async (req, res) => {
//   try {
//     const { MobileNo, CallId, SerialNo, CustomerCode, ComplaintId, Name } = req.body;

//     const pool = await sql.connect();

//     await pool.request()
//       .input("MobileNo", sql.NVarChar, MobileNo)
//       .input("CallId", sql.NVarChar, CallId)
//       .input("SerialNo", sql.NVarChar, SerialNo)
//       .input("CustomerCode", sql.NVarChar, CustomerCode)
//       .input("ComplaintId", sql.NVarChar, ComplaintId)
//       .input("Name", sql.NVarChar, Name)
//       .query(`
//         INSERT INTO ComplaintRegistrations
//         (MobileNo, CallId, SerialNo, CustomerCode, ComplaintId, Name)
//         VALUES (@MobileNo, @CallId, @SerialNo, @CustomerCode, @ComplaintId, @Name)
//       `);

//     res.json({ success: true, message: "Complaint created successfully" });
//     alert("complaint registered successfully");

//   } catch (err) {
//     console.error("Complaint insert error:", err);
//     res.status(500).json({ error: "Complaint insert failed" });
//   }
// });

// module.exports = router;


// backend/routes/complaints.js
const express = require("express");
const router = express.Router();
const { poolPromise } = require("../db");

router.post("/register", async (req, res) => {
  try {
    const { customer, product, callInfo } = req.body;
    if (!customer || !product || !callInfo) return res.status(400).json({ error: "Missing payload" });

    const pool = await poolPromise;

    const assignedCenterName = callInfo.AssignedCenter || null;
    // try to find center id by name (adjust per your schema)
    let centerId = null;
    if (assignedCenterName) {
      const q = await pool.request()
        .input("CenterName", assignedCenterName)
        .query("SELECT Id FROM ServiceCenters WHERE CenterName = @CenterName");
      if (q.recordset.length) centerId = q.recordset[0].Id;
    }

    // Insert into ComplaintRegistration
    const insert = await pool.request()
      .input("MobileNo", customer.MobileNo || null)
      .input("Name", customer.Name || null)
      .input("ProductId", product.Id || null)
      .input("ProductSerialNo", product.ProductSerialNo || null)
      .input("CallType", callInfo.CallType || null)
      .input("AppointmentDate", callInfo.AppointmentDate || null)
      .input("AppointmentTime", callInfo.AppointmentTime || null)
      .input("CallerType", callInfo.CallerType || null)
      .input("CustomerRemarks", callInfo.CustomerRemarks || null)
      .input("DealerName", callInfo.DealerName || null)
      .input("Remarks", callInfo.Remarks || null)
      .input("CallSource", callInfo.CallSource || null)
      .input("ContactPerson", callInfo.ContactPerson || null)
      .input("ContactPersonMobile", callInfo.ContactPersonMobile || null)
      .input("Qty", callInfo.Qty || 1)
      .input("AssignedCenterId", centerId)
      .input("DistanceKm", callInfo.Distance || null)
      .query(`
        INSERT INTO ComplaintRegistration
        (MobileNo, Name, ProductId, ProductSerialNo, CallType, AppointmentDate, AppointmentTime, CallerType, CustomerRemarks, DealerName, Remarks, CallSource, ContactPerson, ContactPersonMobile, Qty, AssignedCenterId, DistanceKm, CreatedAt)
        VALUES
        (@MobileNo, @Name, @ProductId, @ProductSerialNo, @CallType, @AppointmentDate, @AppointmentTime, @CallerType, @CustomerRemarks, @DealerName, @Remarks, @CallSource, @ContactPerson, @ContactPersonMobile, @Qty, @AssignedCenterId, @DistanceKm, GETDATE())
      `);

    res.json({ success: true });
  } catch (err) {
    console.error("Register complaint error:", err);
    res.status(500).json({ error: err.message || "Failed to register complaint" });
  }
});

module.exports = router;

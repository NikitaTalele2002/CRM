// const express = require("express");
// const router = express.Router();
// const sql = require("mssql");

// // CREATE COMPLAINT
// router.post("/", async (req, res) => {
//   try {
//     const { MobileNo, CallId, SerialNo, CustomerCode, ComplaintId, Name } = req.body;

//     const pool = await sql.connect();

//     await pool.request()
//       .input("MobileNo", sql.NVarChar, MobileNo)
//       .input("CallId", sql.NVarChar, CallId)
//       .input("SerialNo", sql.NVarChar, SerialNo)
//       .input("CustomerCode", sql.NVarChar, CustomerCode)
//       .input("ComplaintId", sql.NVarChar, ComplaintId)
//       .input("Name", sql.NVarChar, Name)
//       .query(`
//         INSERT INTO ComplaintRegistrations
//         (MobileNo, CallId, SerialNo, CustomerCode, ComplaintId, Name)
//         VALUES (@MobileNo, @CallId, @SerialNo, @CustomerCode, @ComplaintId, @Name)
//       `);

//     res.json({ success: true, message: "Complaint created successfully" });
//     alert("complaint registered successfully");

//   } catch (err) {
//     console.error("Complaint insert error:", err);
//     res.status(500).json({ error: "Complaint insert failed" });
//   }
// });

// module.exports = router;


// backend/routes/complaints.js
// const express = require("express");
// const router = express.Router();
// const { poolPromise } = require("../db");

// router.post("/register", async (req, res) => {
//   try {
//     const { customer, product, callInfo } = req.body;
//     if (!customer || !product || !callInfo) return res.status(400).json({ error: "Missing payload" });

//     const pool = await poolPromise;

//     const assignedCenterName = callInfo.AssignedCenter || null;
//     // try to find center id by name (adjust per your schema)
//     let centerId = null;
//     if (assignedCenterName) {
//       const q = await pool.request()
//         .input("CenterName", assignedCenterName)
//         .query("SELECT Id FROM ServiceCenters WHERE CenterName = @CenterName");
//       if (q.recordset.length) centerId = q.recordset[0].Id;
//     }

//     // Insert into ComplaintRegistration
//     const insert = await pool.request()
//       .input("MobileNo", customer.MobileNo || null)
//       .input("Name", customer.Name || null)
//       .input("ProductId", product.Id || null)
//       .input("ProductSerialNo", product.ProductSerialNo || null)
//       .input("CallType", callInfo.CallType || null)
//       .input("AppointmentDate", callInfo.AppointmentDate || null)
//       .input("AppointmentTime", callInfo.AppointmentTime || null)
//       .input("CallerType", callInfo.CallerType || null)
//       .input("CustomerRemarks", callInfo.CustomerRemarks || null)
//       .input("DealerName", callInfo.DealerName || null)
//       .input("Remarks", callInfo.Remarks || null)
//       .input("CallSource", callInfo.CallSource || null)
//       .input("ContactPerson", callInfo.ContactPerson || null)
//       .input("ContactPersonMobile", callInfo.ContactPersonMobile || null)
//       .input("Qty", callInfo.Qty || 1)
//       .input("AssignedCenterId", centerId)
//       .input("DistanceKm", callInfo.Distance || null)
//       .query(`
//         INSERT INTO ComplaintRegistration
//         (MobileNo, Name, ProductId, ProductSerialNo, CallType, AppointmentDate, AppointmentTime, CallerType, CustomerRemarks, DealerName, Remarks, CallSource, ContactPerson, ContactPersonMobile, Qty, AssignedCenterId, DistanceKm, CreatedAt)
//         VALUES
//         (@MobileNo, @Name, @ProductId, @ProductSerialNo, @CallType, @AppointmentDate, @AppointmentTime, @CallerType, @CustomerRemarks, @DealerName, @Remarks, @CallSource, @ContactPerson, @ContactPersonMobile, @Qty, @AssignedCenterId, @DistanceKm, GETDATE())
//       `);

//     res.json({ success: true });
//   } catch (err) {
//     console.error("Register complaint error:", err);
//     res.status(500).json({ error: err.message || "Failed to register complaint" });
//   }
// });

// // added new code for assigning complaint to technician 
// // ================== FETCH COMPLAINTS WITH PRODUCT & CUSTOMER ==================
// router.get("/complaints", async (req, res) => {
//   try {
//     const pool = await poolPromise;

//     const complaintsResult = await pool.request().query(`
//       SELECT 
//           c.Id AS CustomerId,
//           c.Name AS CustomerName,
//           c.MobileNo,
//           c.City,
//           c.Area,
//           c.PinCode,
//           p.Id AS ProductId,
//           p.Brand,
//           p.ProductGroup,
//           p.Product,
//           p.Model,
//           p.ModelDescription,
//           p.ProductSerialNo,
//           p.WarrantyStatus,
//           p.CallStatus
//       FROM Customers c
//       LEFT JOIN Products p ON p.CustomerId = c.Id
//       WHERE c.Active = 1;
//     `);

//     const techResult = await pool.request().query(`
//       SELECT Id, TechnicianName FROM Technicians WHERE Active = 1;
//     `);

//     res.json({
//       complaints: complaintsResult.recordset,
//       technicians: techResult.recordset
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ message: "Error fetching complaints" });
//   }
// });



// // ================== ASSIGN TECHNICIAN ==================
// router.post("/assign-technician", async (req, res) => {
//   const { productId, technicianId } = req.body;

//   try {
//     const pool = await poolPromise;

//     await pool.request()
//       .input("ProductId", productId)
//       .input("TechnicianId", technicianId)
//       .query(`
//         UPDATE Products SET AssignedTechnicianId = @TechnicianId WHERE Id = @ProductId;
//       `);

//     res.json({ message: "Technician assigned successfully" });
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ message: "Error assigning technician" });
//   }
// });


// module.exports = router;


const express = require("express");
const router = express.Router();
const { poolPromise } = require("../db");
const sql = require("mssql");

// ================== REGISTER COMPLAINT ==================
router.post("/register", async (req, res) => {
  try {
    const { customer, product, callInfo } = req.body;
    if (!customer || !product || !callInfo)
      return res.status(400).json({ error: "Missing payload" });

    const pool = await poolPromise;

    const assignedCenterName = callInfo.AssignedCenter || null;
    let centerId = null;

    if (assignedCenterName) {
      const q = await pool.request()
        .input("CenterName", assignedCenterName)
        .query("SELECT Id FROM ServiceCenters WHERE CenterName = @CenterName");
      if (q.recordset.length) centerId = q.recordset[0].Id;
    }

    await pool.request()
      .input("MobileNo", customer.MobileNo || null)
      .input("Name", customer.Name || null)
      .input("ProductId", product.Id || null)
      .input("ProductSerialNo", product.ProductSerialNo || null)
      .input("CallType", callInfo.CallType || null)
      .input("AppointmentDate", callInfo.AppointmentDate || null)
      .input("AppointmentTime", callInfo.AppointmentTime || null)
      .input("CallerType", callInfo.CallerType || null)
      .input("CustomerRemarks", callInfo.CustomerRemarks || null)
      .input("DealerName", callInfo.DealerName || null)
      .input("Remarks", callInfo.Remarks || null)
      .input("CallSource", callInfo.CallSource || null)
      .input("ContactPerson", callInfo.ContactPerson || null)
      .input("ContactPersonMobile", callInfo.ContactPersonMobile || null)
      .input("Qty", callInfo.Qty || 1)
      .input("AssignedCenterId", centerId)
      .input("DistanceKm", callInfo.Distance || null)
      .query(`
        INSERT INTO ComplaintRegistration
        (MobileNo, Name, ProductId, ProductSerialNo, CallType, AppointmentDate, AppointmentTime, CallerType, CustomerRemarks, DealerName, Remarks, CallSource, ContactPerson, ContactPersonMobile, Qty, AssignedCenterId, DistanceKm, CreatedAt)
        VALUES
        (@MobileNo, @Name, @ProductId, @ProductSerialNo, @CallType, @AppointmentDate, @AppointmentTime, @CallerType, @CustomerRemarks, @DealerName, @Remarks, @CallSource, @ContactPerson, @ContactPersonMobile, @Qty, @AssignedCenterId, @DistanceKm, GETDATE())
      `);

    res.json({ success: true });
  } catch (err) {
    console.error("Register complaint error:", err);
    res.status(500).json({ error: err.message || "Failed to register complaint" });
  }
});

// ================== FETCH COMPLAINTS ==================
router.get("/", async (req, res) => {
  try {
    const pool = await poolPromise;

    // Query A: existing customers with their products (old behaviour)
    const customersProducts = await pool.request().query(`
      SELECT 
        c.Id AS CustomerId,
        c.Name AS CustomerName,
        c.MobileNo,
        c.City,
        p.Id AS ProductId,
        p.Product,
        p.Model,
        p.ProductSerialNo,
        p.WarrantyStatus,
        p.CallStatus,
        NULL AS ComplaintId,
        NULL AS CreatedAt
      FROM Customers c
      LEFT JOIN Products p ON p.CustomerId = c.Id
      WHERE c.Active = 1
    `);

    // Query B: complaints that were registered via the ComplaintRegistration table
    // Join with customers (by MobileNo) and products (by ProductId) when available
    const registeredComplaints = await pool.request().query(`
      SELECT
        c.Id AS CustomerId,
        COALESCE(c.Name, cr.Name) AS CustomerName,
        cr.MobileNo,
        c.City,
        p.Id AS ProductId,
        p.Product,
        p.Model,
        COALESCE(cr.ProductSerialNo, p.ProductSerialNo) AS ProductSerialNo,
        p.WarrantyStatus,
        cr.CallType AS CallStatus,
        cr.Id AS ComplaintId,
        cr.CreatedAt
      FROM ComplaintRegistration cr
      LEFT JOIN Customers c ON c.MobileNo = cr.MobileNo
      LEFT JOIN Products p ON p.Id = cr.ProductId
      WHERE cr.Id IS NOT NULL
      ORDER BY cr.CreatedAt DESC
    `);

    const techResult = await pool.request().query(`SELECT Id, TechnicianName FROM Technicians WHERE Active = 1`);

    // Merge both lists, preferring registration entries first (new complaints), then existing customer-product rows
    const complaints = [...registeredComplaints.recordset, ...customersProducts.recordset];

    res.json({
      complaints,
      technicians: techResult.recordset,
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching complaints" });
  }
});

// ================== ASSIGN TECHNICIAN ==================
router.post("/assign-technician", async (req, res) => {
  const { productId, technicianId, complaintId } = req.body;

  if ((!productId && !complaintId) || !technicianId) {
    return res.status(400).json({ message: "Missing productId/complaintId or technicianId" });
  }

  try {
    console.log("[assign-technician] payload:", { productId, technicianId, complaintId });
    const pool = await poolPromise;

    // Check if already assigned for productId or complaintId and return early with technician name
    let existingAssignedId = null;
    if (productId) {
      const col = await pool.request().query("SELECT COL_LENGTH('dbo.Products','AssignedTechnicianId') AS colExists");
      if (col.recordset && col.recordset[0] && col.recordset[0].colExists) {
        const r = await pool.request()
          .input("ProductId", sql.Int, Number(productId))
          .query("SELECT AssignedTechnicianId FROM Products WHERE Id = @ProductId");
        if (r.recordset && r.recordset[0]) existingAssignedId = r.recordset[0].AssignedTechnicianId;
      }
    }

    if (!existingAssignedId && complaintId) {
      const col2 = await pool.request().query("SELECT COL_LENGTH('dbo.ComplaintRegistration','AssignedTechnicianId') AS colExists");
      if (col2.recordset && col2.recordset[0] && col2.recordset[0].colExists) {
        const r2 = await pool.request()
          .input("ComplaintId", sql.Int, Number(complaintId))
          .query("SELECT AssignedTechnicianId FROM ComplaintRegistration WHERE Id = @ComplaintId");
        if (r2.recordset && r2.recordset[0]) existingAssignedId = r2.recordset[0].AssignedTechnicianId;
      }
    }

    if (existingAssignedId) {
      // fetch technician name
      const techRes = await pool.request()
        .input("TechnicianId", sql.Int, Number(existingAssignedId))
        .query("SELECT TechnicianName FROM Technicians WHERE Id = @TechnicianId");
      const techName = techRes.recordset && techRes.recordset[0] ? techRes.recordset[0].TechnicianName : null;
      return res.json({ message: `Already assigned to ${techName || existingAssignedId}`, assignedTechnicianId: existingAssignedId, assignedTechnicianName: techName });
    }

    // If productId provided, update Products table (existing behaviour)
    if (productId) {
      // Guard Products update in case the column doesn't exist in the schema
      await pool.request()
        .input("ProductId", sql.Int, Number(productId))
        .input("TechnicianId", sql.Int, Number(technicianId))
        .query(`
          IF COL_LENGTH('dbo.Products','AssignedTechnicianId') IS NOT NULL
          BEGIN
            UPDATE Products SET AssignedTechnicianId = @TechnicianId WHERE Id = @ProductId;
          END
        `);

      // Also update any complaint registrations that reference this productId so the UI reflects the assignment
      // Use conditional update guards so we don't error if the column doesn't exist in the DB schema
      await pool.request()
        .input("ProductId", sql.Int, Number(productId))
        .input("TechnicianId", sql.Int, Number(technicianId))
        .query(`
          IF COL_LENGTH('dbo.ComplaintRegistration','AssignedTechnicianId') IS NOT NULL
          BEGIN
            UPDATE ComplaintRegistration SET AssignedTechnicianId = @TechnicianId WHERE ProductId = @ProductId;
          END
          IF COL_LENGTH('dbo.ComplaintRegistration','CallStatus') IS NOT NULL
          BEGIN
            UPDATE ComplaintRegistration SET CallStatus = 'Assigned' WHERE ProductId = @ProductId;
          END
        `);
    }

    // If complaintId provided (for complaints without a linked product), update ComplaintRegistration directly
    if (complaintId) {
      await pool.request()
        .input("ComplaintId", sql.Int, Number(complaintId))
        .input("TechnicianId", sql.Int, Number(technicianId))
        .query(`
          IF COL_LENGTH('dbo.ComplaintRegistration','AssignedTechnicianId') IS NOT NULL
          BEGIN
            UPDATE ComplaintRegistration SET AssignedTechnicianId = @TechnicianId WHERE Id = @ComplaintId;
          END
          IF COL_LENGTH('dbo.ComplaintRegistration','CallStatus') IS NOT NULL
          BEGIN
            UPDATE ComplaintRegistration SET CallStatus = 'Assigned' WHERE Id = @ComplaintId;
          END
        `);
    }

    res.json({ message: "Technician assigned successfully" });
  } catch (err) {
    console.error("Assign tech error:", err && err.message ? err.message : err);
    // send error details for dev troubleshooting
    res.status(500).json({ message: "Error assigning technician", error: err && err.message ? err.message : String(err) });
  }
});


module.exports = router;

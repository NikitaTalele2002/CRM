


// // const express = require("express");
// // const router = express.Router();
// // const sql = require("mssql");
// // const dbConfig = {
// //   user: "crm_user",
// //   password: "StrongPassword123!",
// //   server: "FCL40001748\\SQLEXPRESS",
// //   database: "dashboard",
// //   options: {
// //     encrypt: false,
// //     trustServerCertificate: true,
// //   },
// // };

// // // Get all products that are owned/ purchased by the registered customer
// // router.get("/", async (req, res) => {
// //   try {
// //     const pool = await sql.connect(dbConfig);

// //     const result = await pool
// //       .request()
// //       .query("SELECT * FROM Products");

// //     res.json(result.recordset);
// //   } catch (err) {
// //     console.error("Product fetch error:", err);
// //     res.status(500).json({ error: "Failed to load products" });
// //   }
// // });

// // // Add a new product
// // // router.post("/add", async (req, res) => {
// // //   const { productName, price } = req.body;

// // //   try {
// // //     const pool = await sql.connect(dbConfig);

// // //     await pool.request()
// // //       .input("productName", sql.NVarChar, productName)
// // //       .input("price", sql.Decimal(10,2), price)
// // //       .query(`
// // //         INSERT INTO Products (productName, price)
// // //         VALUES (@productName, @price)
// // //       `);

// // //     res.status(201).json({ message: "Product added" });
// // //   } catch (err) {
// // //     console.log(err);
// // //     res.status(500).send("Error");
// // //   }
// // // });

// // // use camelcase for the database table columns name
// // router.post("/add", async (req, res) => {
// //   const { productName, price } = req.body;

// //   try {
// //     const pool = await sql.connect(dbConfig);

// //     await pool.request()
// //       .input("productName", sql.NVarChar, productName)
// //       .input("price", sql.Decimal(10,2), price)
// //       .query(`
// //         INSERT INTO Products (productName, price)
// //         VALUES (@productName, @price)
// //       `);

// //     res.status(201).json({ message: "Product added" });
// //   } catch (err) {
// //     console.log(err);
// //     res.status(500).send("Error");
// //   }
// // });


// // module.exports = router;


// const express = require("express");
// const router = express.Router();
// const sql = require("mssql");
// const dbConfig = require("../db");

// // Add new product
// router.post("/", async (req, res) => {
//   try {
//     const {
//       Brand, ProductGroup, Product, Model, ModelDescription,
//       ProductSerialNo, PurchaseDate, DealerName,
//       WarrantyStatus, PreviousCalls, CallStatus
//     } = req.body;

//     const pool = await sql.connect(dbConfig);

//     await pool.request()
//       .input("Brand", sql.NVarChar, Brand)
//       .input("ProductGroup", sql.NVarChar, ProductGroup)
//       .input("Product", sql.NVarChar, Product)
//       .input("Model", sql.NVarChar, Model)
//       .input("ModelDescription", sql.NVarChar, ModelDescription)
//       .input("ProductSerialNo", sql.NVarChar, ProductSerialNo)
//       .input("PurchaseDate", sql.DateTime, PurchaseDate)
//       .input("DealerName", sql.NVarChar, DealerName)
//       .input("WarrantyStatus", sql.NVarChar, WarrantyStatus)
//       .input("PreviousCalls", sql.Int, PreviousCalls || 0)
//       .input("CallStatus", sql.NVarChar, CallStatus)
//       .query(`
//         INSERT INTO Products
//         (Brand, ProductGroup, Product, Model, ModelDescription, ProductSerialNo, PurchaseDate, DealerName, WarrantyStatus, PreviousCalls, CallStatus)
//         VALUES
//         (@Brand, @ProductGroup, @Product, @Model, @ModelDescription, @ProductSerialNo, @PurchaseDate, @DealerName, @WarrantyStatus, @PreviousCalls, @CallStatus)
//       `);

//     res.json({ success: true, message: "Product added successfully" });
//   } catch (err) {
//     console.error("Add product error:", err);
//     res.status(500).json({ error: "Product creation failed", details: err.message });
//   }
// });

// // Search products
// router.post("/search", async (req, res) => {
//   try {
//     const { Brand, ProductGroup, Product, Model, ProductSerialNo } = req.body;

//     const pool = await sql.connect(dbConfig);

//     const result = await pool.request()
//       .input("Brand", sql.NVarChar, Brand || null)
//       .input("ProductGroup", sql.NVarChar, ProductGroup || null)
//       .input("Product", sql.NVarChar, Product || null)
//       .input("Model", sql.NVarChar, Model || null)
//       .input("ProductSerialNo", sql.NVarChar, ProductSerialNo || null)
//       .query(`
//         SELECT * FROM Products
//         WHERE (@Brand IS NULL OR Brand LIKE '%' + @Brand + '%')
//           AND (@ProductGroup IS NULL OR ProductGroup LIKE '%' + @ProductGroup + '%')
//           AND (@Product IS NULL OR Product LIKE '%' + @Product + '%')
//           AND (@Model IS NULL OR Model LIKE '%' + @Model + '%')
//           AND (@ProductSerialNo IS NULL OR ProductSerialNo = @ProductSerialNo)
//       `);

//     res.json({ rows: result.recordset });
//   } catch (err) {
//     console.error("Search product error:", err);
//     res.status(500).json({ error: "Product search failed", details: err.message });
//   }
// });

// module.exports = router;

// const express = require("express");
// const router = express.Router();
// const { poolPromise, sql } = require("../db");

// // 📌 GET all products or search by customer / keyword
// // Example: /api/products?customerId=123&search=Samsung
// router.get("/", async (req, res) => {
//   const { customerId, search } = req.query;

//   try {
//     const pool = await poolPromise; // <- now safe
//     const request = pool.request();

//     let query = "SELECT * FROM Products WHERE 1=1";

//     if (customerId) {
//       query += " AND CustomerId = @CustomerId";
//       request.input("CustomerId", sql.Int, customerId);
//     }

//     if (search) {
//       query += ` AND (Brand LIKE @Search OR ProductGroup LIKE @Search OR Product LIKE @Search OR Model LIKE @Search OR ProductSerialNo LIKE @Search)`;
//       request.input("Search", sql.NVarChar, `%${search}%`);
//     }

//     query += " ORDER BY CreatedAt DESC";

//     const result = await request.query(query);
//     res.json(result.recordset);
//   } catch (err) {
//     console.error("Error fetching products:", err);
//     res.status(500).send("Error fetching products");
//   }
// });
// router.post("/add", async (req, res) => {
//   const {
//     Brand,
//     ProductGroup,
//     Product,
//     Model,
//     ModelDescription,
//     ProductSerialNo,
//     PurchaseDate,
//     DealerName,
//     WarrantyStatus,
//     PreviousCalls,
//     CallStatus,
//   } = req.body;

//   try {
//     const pool = await poolPromise;

//     await pool
//       .request()
//       .input("Brand", sql.NVarChar(100), Brand)
//       .input("ProductGroup", sql.NVarChar(100), ProductGroup)
//       .input("Product", sql.NVarChar(100), Product)
//       .input("Model", sql.NVarChar(100), Model)
//       .input("ModelDescription", sql.NVarChar(255), ModelDescription)
//       .input("ProductSerialNo", sql.NVarChar(100), ProductSerialNo)
//       .input("PurchaseDate", sql.DateTime, PurchaseDate || null)
//       .input("DealerName", sql.NVarChar(100), DealerName)
//       .input("WarrantyStatus", sql.NVarChar(50), WarrantyStatus)
//       .input("PreviousCalls", sql.Int, PreviousCalls || 0)
//       .input("CallStatus", sql.NVarChar(50), CallStatus)
//       .query(`
//         INSERT INTO Products 
//         (Brand, ProductGroup, Product, Model, ModelDescription, ProductSerialNo, PurchaseDate, DealerName, WarrantyStatus, PreviousCalls, CallStatus)
//         VALUES
//         (@Brand, @ProductGroup, @Product, @Model, @ModelDescription, @ProductSerialNo, @PurchaseDate, @DealerName, @WarrantyStatus, @PreviousCalls, @CallStatus)
//       `);

//     res.status(201).json({ message: "Product registered successfully" });
//   } catch (err) {
//     console.error("Error registering product:", err);
//     res.status(500).json({ error: err.message });
//   }
// });


// module.exports = router;

// const express = require("express");
// const router = express.Router();
// const { poolPromise, sql } = require("../db");

// // GET all products with customer info
// router.get("/", async (req, res) => {
//   try {
//     const pool = await poolPromise;
//     const result = await pool.request().query(`
//       SELECT 
//         p.Id AS ProductId,
//         p.Brand,
//         p.ProductGroup,
//         p.Product,
//         p.Model,
//         p.ModelDescription,
//         p.ProductSerialNo,
//         p.PurchaseDate,
//         p.DealerName,
//         p.WarrantyStatus,
//         p.PreviousCalls,
//         p.CallStatus,
//         p.CustomerId,
//         c.Name AS CustomerName,
//         c.MobileNo AS CustomerPhone
//       FROM Products p
//       LEFT JOIN Customers c ON p.CustomerId = c.Id
//       ORDER BY p.Id DESC
//     `);

//     res.json(result.recordset);
//   } catch (err) {
//     console.error("Error fetching products:", err);
//     res.status(500).json({ error: "Failed to fetch products" });
//   }
// });

// router.post("/add", async (req, res) => {
//   try {
//     const {
//       Brand,
//       ProductGroup,
//       Product,
//       Model,
//       ModelDescription,
//       ProductSerialNo,
//       PurchaseDate,
//       DealerName,
//       WarrantyStatus,
//       PreviousCalls,
//       CallStatus,
//       CustomerPhone, // <-- frontend must send this
//     } = req.body;

//     // Find customer by phone
//     let customerId = null;
//     if (CustomerPhone) {
//       const result = await pool.request()
//         .input("MobileNo", CustomerPhone)
//         .query("SELECT Id FROM Customers WHERE MobileNo = @MobileNo");

//       if (result.recordset.length > 0) {
//         customerId = result.recordset[0].Id;
//       }
//     }

//     // Insert product and link with customer
//     await pool.request()
//       .input("Brand", Brand)
//       .input("ProductGroup", ProductGroup)
//       .input("Product", Product)
//       .input("Model", Model)
//       .input("ModelDescription", ModelDescription)
//       .input("ProductSerialNo", ProductSerialNo)
//       .input("PurchaseDate", PurchaseDate || null)
//       .input("DealerName", DealerName)
//       .input("WarrantyStatus", WarrantyStatus)
//       .input("PreviousCalls", PreviousCalls || 0)
//       .input("CallStatus", CallStatus)
//       .input("CustomerId", customerId)
//       .query(`
//         INSERT INTO Products 
//         (Brand, ProductGroup, Product, Model, ModelDescription, ProductSerialNo, PurchaseDate, DealerName, WarrantyStatus, PreviousCalls, CallStatus, CustomerId)
//         VALUES (@Brand, @ProductGroup, @Product, @Model, @ModelDescription, @ProductSerialNo, @PurchaseDate, @DealerName, @WarrantyStatus, @PreviousCalls, @CallStatus, @CustomerId)
//       `);

//     res.json({ success: true });
//   } catch (err) {
//     console.error("Failed to register product:", err);
//     res.status(500).json({ error: "Failed to register product" });
//   }
// });

// module.exports = router;


const express = require("express");
const router = express.Router();
const { poolPromise, sql } = require("../db");

// GET /api/products
// Fetch all products with customer info
router.get("/", async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT 
        p.Id AS ProductId,
        p.Brand,
        p.ProductGroup,
        p.Product,
        p.Model,
        p.ModelDescription,
        p.ProductSerialNo,
        p.PurchaseDate,
        p.DealerName,
        p.WarrantyStatus,
        p.PreviousCalls,
        p.CallStatus,
        c.Id AS CustomerId,
        c.Name AS CustomerName,
        c.MobileNo AS CustomerPhone
      FROM Products p
      LEFT JOIN Customers c ON p.CustomerId = c.Id
      ORDER BY p.Id DESC
    `);

    res.json(result.recordset);
  } catch (err) {
    console.error("Error fetching products:", err);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// GET /api/products/by-phone/:phone
// Fetch products for a specific customer based on phone number
router.get("/by-phone/:phone", async (req, res) => {
  const { phone } = req.params;
  try {
    const pool = await poolPromise;

    // Find customer Id by phone
    const customerResult = await pool.request()
      .input("MobileNo", sql.NVarChar, phone)
      .query("SELECT Id FROM Customers WHERE MobileNo = @MobileNo");

    const customer = customerResult.recordset[0];
    if (!customer) return res.status(404).json([]);

    // Fetch products linked to this customer
    const productsResult = await pool.request()
      .input("CustomerId", sql.Int, customer.Id)
      .query("SELECT * FROM Products WHERE CustomerId = @CustomerId ORDER BY Id DESC");

    res.json(productsResult.recordset);
  } catch (err) {
    console.error("Error fetching products by phone:", err);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// POST /api/products/add
// Add product linked to a customer by phone number
router.get("/by-phone/:phone", async (req, res) => {
  const phone = req.params.phone;

  try {
    // Get customer info
    const customerResult = await poolPromise
      .request()
      .input("MobileNo", sql.NVarChar, phone)
      .query("SELECT * FROM Customers WHERE MobileNo = @MobileNo");

    const customer = customerResult.recordset[0];
    if (!customer) return res.status(404).json({ error: "Customer not found" });

    // Get products for that customer
    const productResult = await poolPromise
      .request()
      .input("CustomerId", sql.Int, customer.Id)
      .query("SELECT * FROM Products WHERE CustomerId = @CustomerId");

    res.json({ customer, products: productResult.recordset });
  } catch (err) {
    console.error("Error fetching products by phone:", err);
    res.status(500).json({ error: "Failed to fetch products" });
  }
});

// POST /api/products/add
// Add a product and optionally link it to a customer by phone number
router.post("/add", async (req, res) => {
  try {
    const {
      Brand,
      ProductGroup,
      Product,
      Model,
      ModelDescription,
      ProductSerialNo,
      PurchaseDate,
      DealerName,
      WarrantyStatus,
      PreviousCalls,
      CallStatus,
      CustomerPhone,
    } = req.body;

    const pool = await poolPromise;

    // Try to find customer by phone (optional)
    let customerId = null;
    if (CustomerPhone) {
      const customerResult = await pool
        .request()
        .input("MobileNo", sql.NVarChar, CustomerPhone)
        .query("SELECT Id FROM Customers WHERE MobileNo = @MobileNo");

      if (customerResult.recordset && customerResult.recordset.length > 0) {
        customerId = customerResult.recordset[0].Id;
      }
    }

    await pool
      .request()
      .input("Brand", sql.NVarChar(100), Brand)
      .input("ProductGroup", sql.NVarChar(100), ProductGroup)
      .input("Product", sql.NVarChar(100), Product)
      .input("Model", sql.NVarChar(100), Model)
      .input("ModelDescription", sql.NVarChar(255), ModelDescription)
      .input("ProductSerialNo", sql.NVarChar(100), ProductSerialNo)
      .input("PurchaseDate", sql.DateTime, PurchaseDate || null)
      .input("DealerName", sql.NVarChar(100), DealerName)
      .input("WarrantyStatus", sql.NVarChar(50), WarrantyStatus)
      .input("PreviousCalls", sql.Int, PreviousCalls || 0)
      .input("CallStatus", sql.NVarChar(50), CallStatus)
      .input("CustomerId", sql.Int, customerId)
      .query(`
        INSERT INTO Products
        (Brand, ProductGroup, Product, Model, ModelDescription, ProductSerialNo, PurchaseDate, DealerName, WarrantyStatus, PreviousCalls, CallStatus, CustomerId)
        VALUES
        (@Brand, @ProductGroup, @Product, @Model, @ModelDescription, @ProductSerialNo, @PurchaseDate, @DealerName, @WarrantyStatus, @PreviousCalls, @CallStatus, @CustomerId)
      `);

    res.status(201).json({ message: "Product registered successfully" });
  } catch (err) {
    console.error("Error registering product:", err);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;



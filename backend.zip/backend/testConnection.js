// backend/testConnection.js
import { getConnection } from "./db.js";

async function test() {
  try {
    const pool = await getConnection();
    const result = await pool.request().query("SELECT GETDATE() GETTIME() AS currentTime");
    console.log(" DB Connected:", result.recordset);
  } catch (err) {
    console.error("Connection error details:", err);
  }
}

test();

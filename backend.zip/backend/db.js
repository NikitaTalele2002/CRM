// const sql = require("mssql");

// const config = {
//   user: 'crm_user',
//   password: 'StrongPassword123!',
//   server: 'FCL40001748\\SQLEXPRESS', // Changed from localhost\\SQLEXPRESS
//   database: 'Crm_db',
//   options: {
//     encrypt: false,
//     trustServerCertificate: true,
//     enableArithAbort: true
//   }
// };

// const config= {
//   user: "crm_user",
//   password: "StrongPassword123!",
//   server: "FCL40001748\\SQLEXPRESS",
//   database: "dashboard",
//   options: {
//     encrypt: false, // true if using Azure
//     trustServerCertificate: true,
//     enableArithAbort:true
//   },
// };


// const poolPromise = new sql.ConnectionPool(config)
//   .connect()
//   .then((pool) => {
//     console.log("Connected to MSSQL Database");
//     return pool;
//   })
//   .catch((err) => {
//     console.error("Database Connection Failed!");
//     console.error("Error:", err);
//     throw err;
//   });

// module.exports = { sql, poolPromise };


// import sql from "mssql";

// const dbConfig = {
//   user: "crm_user",
//   password: "StrongPassword123!",
//   server: "FCL40001748\\SQLEXPRESS",
//   database: "dashboard",
//   options: {
//     encrypt: false,
//     trustServerCertificate: true,
//     enableArithAbort: true
//   },
// };

// export default dbConfig;
// export { sql };


// backend/db.js
const sql = require("mssql");

const config = {
  user: "crm_user",
  password: "StrongPassword123!",
  server: "FCL40001748\\SQLEXPRESS",
  database: "dashboard",
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};





// Create a pool and export a promise
let poolPromise;

try {
  const pool = new sql.ConnectionPool(config);
  poolPromise = pool.connect(); // returns a promise
  poolPromise
    .then(() => console.log("MSSQL Connected Successfully"))
    .catch((err) => console.error("MSSQL Pool Connection Error:", err));
} catch (err) {
  console.error("MSSQL Connection Error:", err);
}

module.exports = { sql, poolPromise };


import React from "react";
import { Navigate } from "react-router-dom";
import { useRole } from "../context/RoleContext";

export default function ProtectedRoute({ allowedRoles = [], children }) {
  const { role, isAuthenticated } = useRole(); 

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
    return <Navigate to="/unauthorized" replace />; 
  }

  return children;
}


import React from "react";
import { NavLink } from "react-router-dom";

export default function Navbar() {
  const linkClass = ({ isActive }) =>
    `px-3 py-2 rounded-md text-sm font-medium ${isActive ? 'bg-white text-blue-600' : 'text-white hover:bg-blue-500/90'}`;

  return (
    <nav className="sticky top-0 z-50 bg-blue-600 shadow">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-white font-bold">CRM Dashboard</div>
            <div className="hidden md:block ml-6">
              <div className="flex space-x-2">
                <NavLink to="/" className={linkClass}>Home</NavLink>
                <NavLink to="/call-centre/dashboardCS" className={linkClass}>Call Centre</NavLink>
                <NavLink to="/service-center" className={linkClass}>Service Center</NavLink>
                <NavLink to="/call-centre/register" className={linkClass}>Register Product</NavLink>
                <NavLink to="/call-centre/show" className={linkClass}>Show Products</NavLink>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="flex items-center space-x-2">
              <NavLink to="/login" className={linkClass}>Login</NavLink>
              <NavLink to="/signup" className={linkClass}>Signup</NavLink>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

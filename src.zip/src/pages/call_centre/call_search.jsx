import React, { useState } from "react";
// import axios from "axios";
import CC_Navbar from "../call_centre/NavbarCS";

export default function CallSearch() {
  const [filters, setFilters] = useState({
    fromDate: "",
    toDate: "",
    callId: "",
    mobileNo: "",
    brand: "",
    status: "",
    callType: "",
  });

  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedCall, setSelectedCall] = useState(null);

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // will Replace with real backend API later
      // this is using axios
      // const response = await axios.post("http://localhost:5000/api/calls/search", filters);
      // setResults(response.data);

      // Mock data for demo frontend 
      const mockResults = [
        {
          CallId: "0511250065",
          Age: 3,
          RegistrationDate: "2025-11-04",
          AppointmentDate: "2025-11-06",
          Status: "Open",
          CustomerName: "John Doe",
          Address: "123 Main Street",
          State: "Maharashtra",
          City: "Pune",
          PinCode: "411001",
          MobileNo: "9876543210",
          Brand: "FINOLEX",
          Model: "FX-200",
          Warranty: "In Warranty",
          CustomerRemarks: "Cable heating issue",
          Branch: "Pune Branch",
          ASP_DSA: "ABC Services",
          Technician: "Ravi Kumar",
          ContactPerson: "Suresh",
          ContactNo: "9823012345",
          CallType: "Repair",
          Remarks: "Pending technician visit",
          CallerType: "Customer",
          PendingReason: "Spare not available",
          CancelReason: "",
          CallClosedDate: null,
        },
        {
          CallId: "0511250066",
          Age: 1,
          RegistrationDate: "2025-11-05",
          AppointmentDate: "2025-11-07",
          Status: "Closed",
          CustomerName: "ABC",
          Address: "45 Green Valley",
          State: "MP",
          City: "ABC",
          PinCode: "560076",
          MobileNo: "9845098450",
          Brand: "FINOLEX",
          Model: "HV-1200",
          Warranty: "Out of Warranty",
          CustomerRemarks: "Switch not working",
          Branch: "Bangalore Branch",
          ASP_DSA: "TechFix Pvt Ltd",
          Technician: "Amit Verma",
          ContactPerson: "ABCD",
          ContactNo: "9845123456",
          CallType: "Repair",
          Remarks: "Replaced faulty switch",
          CallerType: "Dealer",
          PendingReason: "",
          CancelReason: "",
          CallClosedDate: "2025-11-06",
        },
        {
          CallId: "051125005677",
          Age: 1,
          RegistrationDate: "2025-11-05",
          AppointmentDate: "2025-11-07",
          Status: "open",
          CustomerName: "QWERT",
          Address: "45 Green Valley",
          State: "Karnataka",
          City: "Bangalore",
          PinCode: "560076",
          MobileNo: "9845098450",
          Brand: "FINOLEX",
          Model: "FL-1200",
          Warranty: "Out of Warranty",
          CustomerRemarks: "Switch not working",
          Branch: "Bangalore Branch",
          ASP_DSA: "TechFix Pvt Ltd",
          Technician: "Amit Verma",
          ContactPerson: "XYZ",
          ContactNo: "9845123456",
          CallType: "Repair",
          Remarks: "Replaced faulty switch",
          CallerType: "customer",
          PendingReason: "",
          CancelReason: "",
          CallClosedDate: "null",
        },

        {
          CallId: "05112504612",
          Age: 1,
          RegistrationDate: "2025-11-05",
          AppointmentDate: "2025-11-07",
          Status: "Closed",
          CustomerName: "Priya Sharma",
          Address: "45 Green Valley",
          State: "Karnataka",
          City: "Bangalore",
          PinCode: "560076", 
          MobileNo: "9845098450",
          Brand: "FINOLEX",
          Model: "HV-1200",
          Warranty: "Out of Warranty",
          CustomerRemarks: "Switch not working",
          Branch: "Bangalore Branch",
          ASP_DSA: "TechFix Pvt Ltd",
          Technician: "Amit Verma",
          ContactPerson: "Rajesh",
          ContactNo: "9845123456",
          CallType: "Repair",
          Remarks: "Replaced faulty switch",
          CallerType: "Dealer",
          PendingReason: "",
          CancelReason: "",
          CallClosedDate: "2025-06-28",
        },
      ];

      setTimeout(() => {
        setResults(mockResults);
        setLoading(false);
      }, 500);
    } catch (err) {
      console.error("Error fetching data:", err);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-screen bg-gray-50">
      <CC_Navbar />

      <div className="max-w-screen-xl mx-auto mt-10 bg-white p-8  shadow-md rounded-lg">
        <h1 className="text-xl font-bold mb-6 text-gray-800 text-center">Call Management - Call Search</h1>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div>
            <label className="block text-gray-700 font-semibold">From Date</label>
            <input
              type="date"
              name="fromDate"
              value={filters.fromDate}
              onChange={handleChange}
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-teal-500"/>
          </div>


          <div>
            <label className="block text-gray-700 font-semibold">To Date</label>
            <input
              type="date"
              name="toDate"
              value={filters.toDate}
              onChange={handleChange}
              className="w-full border rounded px-3 py-2 focus:ring-2 focus:ring-teal-500"/>
          </div>


          <div>
            <label className="block text-gray-700 font-semibold">Call ID</label>
            <input
              type="text"
              name="callId"
              value={filters.callId}
              onChange={handleChange}
              placeholder="0511250065"
              className="w-full border rounded px-3 py-2"/>
          </div>


          <div>
            <label className="block text-gray-700 font-semibold">Mobile No</label>
            <input
              type="text"
              name="mobileNo"
              value={filters.mobileNo}
              onChange={handleChange}
              placeholder="Enter mobile number"
              className="w-full border rounded px-3 py-2"/>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold">Brand</label>
            <select 
              name="brand"
              value={filters.brand}
              onChange={handleChange}
              className="w-full border rounded px-3 py-2">
              <option value="">Select</option>
              <option value="FINOLEX">FINOLEX</option>
              </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold">Status</label>
            <select
              name="status"
              value={filters.status}
              onChange={handleChange}
              className="w-full border rounded px-3 py-2">
              <option value="">All</option>
              <option value="Open">Open</option>
              <option value="Closed">Closed</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-700 font-semibold">Call Type</label>
            <select
              name="callType"
              value={filters.callType}
              onChange={handleChange}
              className="w-full border rounded px-3 py-2">
              <option value="">All</option>
              <option value="Repair">Repair</option>
              <option value="Installation">Installation</option>
            </select>
          </div>

          <div className="md:col-span-3 flex justify-end">
            <button
              type="submit"
              className="bg-teal-500 text-black px-6 py-2 rounded-md hover:bg-teal-600 transition">
              {loading ? "Searching..." : "Search"}
            </button>
          </div>
        </form>

        {/* Results Table */}
        {results.length > 0 && (
          <div className="overflow-x-auto mt-8">
            <table className="min-w-full border border-gray-300 text-sm">
              <thead className="bg-gray-100 text-gray-700">
                <tr>
                  <th className="border px-2 py-1">#</th>
                  <th className="border px-2 py-1">Select</th>
                  <th className="border px-2 py-1">Call Id</th>
                  <th className="border px-2 py-1">Age</th>
                  <th className="border px-2 py-1">Registration Date</th>
                  <th className="border px-2 py-1">Appointment Date</th>
                  <th className="border px-2 py-1">Status</th>
                  <th className="border px-2 py-1">Customer Name</th>
                  <th className="border px-2 py-1">Address</th>
                  <th className="border px-2 py-1">State</th>
                  <th className="border px-2 py-1">City</th>
                  <th className="border px-2 py-1">Pin Code</th>
                  <th className="border px-2 py-1">Mobile No</th>
                  <th className="border px-2 py-1">Brand</th>
                  <th className="border px-2 py-1">Model</th>
                  <th className="border px-2 py-1">Warranty</th>
                  <th className="border px-2 py-1">Customer Remarks</th>
                  <th className="border px-2 py-1">Branch</th>
                  <th className="border px-2 py-1">ASP/DSA</th>
                  <th className="border px-2 py-1">Technician</th>
                  <th className="border px-2 py-1">Contact Person</th>
                  <th className="border px-2 py-1">Contact No</th>
                  <th className="border px-2 py-1">Call Type</th>
                  <th className="border px-2 py-1">Remarks</th>
                  <th className="border px-2 py-1">Caller Type</th>
                  <th className="border px-2 py-1">Pending Reason</th>
                  <th className="border px-2 py-1">Cancel Reason</th>
                  <th className="border px-2 py-1">Call Closed Date</th>
                </tr>
              </thead>
              <tbody>
                {results.map((r, index) => (
                  <tr
                    key={index}
                    className={`text-center hover:bg-gray-50 ${
                      selectedCall === r.CallId ? "bg-teal-100" : ""
                    }`}
                  >
                    <td className="border px-2 py-1">{index + 1}</td>
                    <td className="border px-2 py-1">
                      <input
                        type="radio"
                        name="selectedCall"
                        checked={selectedCall === r.CallId}
                        onChange={() => setSelectedCall(r.CallId)}
                      />
                    </td>
                    <td className="border px-2 py-1">{r.CallId}</td>
                    <td className="border px-2 py-1">{r.Age}</td>
                    <td className="border px-2 py-1">{r.RegistrationDate}</td>
                    <td className="border px-2 py-1">{r.AppointmentDate}</td>
                    <td className="border px-2 py-1">{r.Status}</td>
                    <td className="border px-2 py-1">{r.CustomerName}</td>
                    <td className="border px-2 py-1">{r.Address}</td>
                    <td className="border px-2 py-1">{r.State}</td>
                    <td className="border px-2 py-1">{r.City}</td>
                    <td className="border px-2 py-1">{r.PinCode}</td>
                    <td className="border px-2 py-1">{r.MobileNo}</td>
                    <td className="border px-2 py-1">{r.Brand}</td>
                    <td className="border px-2 py-1">{r.Model}</td>
                    <td className="border px-2 py-1">{r.Warranty}</td>
                    <td className="border px-2 py-1">{r.CustomerRemarks}</td>
                    <td className="border px-2 py-1">{r.Branch}</td>
                    <td className="border px-2 py-1">{r.ASP_DSA}</td>
                    <td className="border px-2 py-1">{r.Technician}</td>
                    <td className="border px-2 py-1">{r.ContactPerson}</td>
                    <td className="border px-2 py-1">{r.ContactNo}</td>
                    <td className="border px-2 py-1">{r.CallType}</td>
                    <td className="border px-2 py-1">{r.Remarks}</td>
                    <td className="border px-2 py-1">{r.CallerType}</td>
                    <td className="border px-2 py-1">{r.PendingReason}</td>
                    <td className="border px-2 py-1">{r.CancelReason}</td>
                    <td className="border px-2 py-1">{r.CallClosedDate || "-"}</td>
                  </tr>
                  
                ))}
                <tr>
                  <td>
                    <button
                      type="submit"
                      className="bg-teal-500 text-black px-6 py-2 rounded-md hover:bg-teal-600 transition">Submit Complaint
                      </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        )}

        {loading && <p className="text-center text-gray-600 mt-4">Loading...</p>}
      </div>
    </div>
  );
}

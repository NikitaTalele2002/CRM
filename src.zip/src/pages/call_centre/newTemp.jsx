Okay, I will give you complete working example:
🎯 Requirements


Fetch customer + product details from DB (JOIN)


Fetch technician list from technician table


Display in table format in React


Add Assign Technician column with <select>


Allow assigning technician (POST API)


I will give:


Node.js Express API (Service Center Route)


React Component code to display table & dropdown


Assign technician API



🛠 Backend Code (Node.js Express)
📌 service-center.js
const express = require("express");
const router = express.Router();
const { poolPromise } = require("../db");

// Fetch complaints with customer + product info + technicians list
router.get("/complaints", async (req, res) => {
  try {
    const pool = await poolPromise;

    const complaintsResult = await pool.request().query(`
      SELECT 
          c.Id AS CustomerId,
          c.Name AS CustomerName,
          c.MobileNo,
          c.City,
          c.Area,
          c.PinCode,
          p.Id AS ProductId,
          p.Brand,
          p.ProductGroup,
          p.Product,
          p.Model,
          p.ModelDescription,
          p.ProductSerialNo,
          p.WarrantyStatus,
          p.CallStatus
      FROM Customers c
      LEFT JOIN Products p ON p.CustomerId = c.Id
      WHERE c.Active = 1;
    `);

    const techResult = await pool.request().query(`
      SELECT Id, TechnicianName FROM Technicians WHERE Active = 1;
    `);

    res.json({
      complaints: complaintsResult.recordset,
      technicians: techResult.recordset
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching complaints" });
  }
});

// Assign technician
router.post("/assign-technician", async (req, res) => {
  const { productId, technicianId } = req.body;

  try {
    const pool = await poolPromise;

    await pool.request()
      .input("ProductId", productId)
      .input("TechnicianId", technicianId)
      .query(`
        UPDATE Products SET AssignedTechnicianId = @TechnicianId WHERE Id = @ProductId;
      `);

    res.json({ message: "Technician assigned successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error assigning technician" });
  }
});

module.exports = router;


🎨 Frontend React Code
📌 ComplaintTable.jsx
import React, { useEffect, useState } from "react";

export default function ComplaintTable() {
  const [data, setData] = useState([]);
  const [technicians, setTechnicians] = useState([]);

  useEffect(() => {
    fetchComplaints();
  }, []);

  async function fetchComplaints() {
    const res = await fetch("http://localhost:5000/api/service-center/complaints");
    const result = await res.json();
    setData(result.complaints);
    setTechnicians(result.technicians);
  }

  async function assignTechnician(productId, technicianId) {
    const res = await fetch("http://localhost:5000/api/service-center/assign-technician", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, technicianId })
    });

    const result = await res.json();
    alert(result.message);
  }

  return (
    <table border="1" cellPadding="8" style={{ marginTop: 20, width: "100%" }}>
      <thead>
        <tr>
          <th>Customer Name</th>
          <th>Mobile</th>
          <th>City</th>
          <th>Product</th>
          <th>Model</th>
          <th>Serial No</th>
          <th>Warranty</th>
          <th>Call Status</th>
          <th>Assign Technician</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row) => (
          <tr key={row.ProductId}>
            <td>{row.CustomerName}</td>
            <td>{row.MobileNo}</td>
            <td>{row.City}</td>
            <td>{row.Product}</td>
            <td>{row.Model}</td>
            <td>{row.ProductSerialNo}</td>
            <td>{row.WarrantyStatus}</td>
            <td>{row.CallStatus}</td>
            <td>
              <select
                onChange={(e) => assignTechnician(row.ProductId, e.target.value)}
                defaultValue=""
              >
                <option value="" disabled>Select Technician</option>
                {technicians.map((t) => (
                  <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
                ))}
              </select>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}


📦 API Index Route Inclusion
In index.js
const serviceCenterRoutes = require("./routes/service-center");
app.use("/api/service-center", serviceCenterRoutes);


🎉 Final Output
This will display:
CustomerMobileProductModelSerialWarrantyAssign TechnicianJohn Doe98765ACVoltasVT123In Warrantydropdown
Selecting technician will:


Update DB using POST API


Show success message



✨ Next Add-on (Optional)


Show assigned technician name


Change CallStatus to "Assigned"


Show status color badges



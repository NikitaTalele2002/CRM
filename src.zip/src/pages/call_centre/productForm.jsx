// Product not found page

import React, { useEffect, useState } from "react";
import { getProducts } from "../api";

export default function productForm() {
  const [rows, setRows] = useState([]);

  useEffect(() => {
    loadProducts();
  }, []);

  async function loadProducts() {
    const result = await getProducts();
    setRows(result.rows);
  }

  return (
    <div style={{ padding: 12 }}>
      <h3>All Products</h3>

      {rows.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <table border="1" cellPadding="5" style={{ marginTop: 10 }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Code</th>
              <th>Price</th>
              <th>CreatedAt</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((p) => (
              <tr key={p.Id}>
                <td>{p.Id}</td>
                <td>{p.ProductName}</td>
                {/* <td>{p.ProductCode}</td> */}
                <td>{p.Price}</td>
                <td>{p.CreatedAt}</td>
              </tr>
            ))}
          </tbody>

          <tbody>
            <tr>
                <td>
                    <button>Register Product</button>
                </td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
}
// import React, { useState } from "react";
// import { registerProduct } from "../api";


// export default function RegisterProduct() {
//   const [product, setProduct] = useState({
//     name: "",
//     price: "",
//   });

//   async function handleSubmit(e) {
//     e.preventDefault();

//     // // Convert form data to backend format
//     // const payload = {
//     //   ProductName: product.name,
//     // //   ProductCode: "AUTO001", // static until you add input
//     //   Price: product.price,
//     // };

//     const payload = {
//   productName: product.name,  // LOWERCASE
//   price: product.price        // LOWERCASE
// };
//     await registerProduct(payload);
//     alert("Product registered!");
//   }

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Register Product</h2>

//       <form onSubmit={handleSubmit}>
//         <input
//           placeholder="Product Name"
//           value={product.name}
//           required
//           onChange={(e) =>
//             setProduct({ ...product, name: e.target.value })
//           }
//         />

//         <br /><br />

//         <input
//           placeholder="Price"
//           value={product.price}
//           required
//           onChange={(e) =>
//             setProduct({ ...product, price: e.target.value })
//           }
//         />

//         <br /><br />

//         <button type="submit">Save</button>
//       </form>
//     </div>
//   );
// }

import React, { useState } from "react";

export default function RegisterProduct() {
  const [product, setProduct] = useState({
    CustomerPhone: "",
    Brand: "",
    ProductGroup: "",
    Product: "",
    Model: "",
    ModelDescription: "",
    ProductSerialNo: "",
    PurchaseDate: "",
    DealerName: "",
    WarrantyStatus: "",
    PreviousCalls: 0,
    CallStatus: "",
  });

  async function handleSubmit(e) {
    e.preventDefault();

    const payload = {
      ...product,
      PreviousCalls: parseInt(product.PreviousCalls) || 0,
      PurchaseDate: product.PurchaseDate || null,
    };

    try {
    const res = await fetch("http://localhost:5000/api/products/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

      if (!res.ok) throw new Error("Failed to register product");

      alert("Product registered successfully!");
      setProduct({
        CustomerPhone: "",
        Brand: "",
        ProductGroup: "",
        Product: "",
        Model: "",
        ModelDescription: "",
        ProductSerialNo: "",
        PurchaseDate: "",
        DealerName: "",
        WarrantyStatus: "",
        PreviousCalls: 0,
        CallStatus: "",
      });
    } catch (err) {
      console.error(err);
      alert("Failed to register product. Check console for details.");
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Register Product</h2>

      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <input
          placeholder="Customer Phone"
          value={product.CustomerPhone}
          required
          onChange={(e) => setProduct({ ...product, CustomerPhone: e.target.value })}
        />
        <input
          placeholder="Brand"
          value={product.Brand}
          required
          onChange={(e) => setProduct({ ...product, Brand: e.target.value })}
        />
        <input
          placeholder="Product Group"
          value={product.ProductGroup}
          onChange={(e) => setProduct({ ...product, ProductGroup: e.target.value })}
        />
        <input
          placeholder="Product Name"
          value={product.Product}
          required
          onChange={(e) => setProduct({ ...product, Product: e.target.value })}
        />
        <input
          placeholder="Model"
          value={product.Model}
          onChange={(e) => setProduct({ ...product, Model: e.target.value })}
        />
        <input
          placeholder="Model Description"
          value={product.ModelDescription}
          onChange={(e) => setProduct({ ...product, ModelDescription: e.target.value })}
        />
        <input
          placeholder="Serial No"
          value={product.ProductSerialNo}
          onChange={(e) => setProduct({ ...product, ProductSerialNo: e.target.value })}
        />
        <input
          type="date"
          placeholder="Purchase Date"
          value={product.PurchaseDate}
          onChange={(e) => setProduct({ ...product, PurchaseDate: e.target.value })}
        />
        <input
          placeholder="Dealer Name"
          value={product.DealerName}
          onChange={(e) => setProduct({ ...product, DealerName: e.target.value })}
        />
        <input
          placeholder="Warranty Status"
          value={product.WarrantyStatus}
          onChange={(e) => setProduct({ ...product, WarrantyStatus: e.target.value })}
        />
        <input
          placeholder="Previous Calls"
          type="number"
          value={product.PreviousCalls}
          onChange={(e) => setProduct({ ...product, PreviousCalls: parseInt(e.target.value) })}
        />
        
        <input
          placeholder="Call Status"
          value={product.CallStatus}
          onChange={(e) => setProduct({ ...product, CallStatus: e.target.value })}
        />

        <button type="submit" style={{ padding: "8px 12px", marginTop: 10 }}>
          Register Product
        </button>
      </form>
    </div>
  );
}





// 
// - CALL INFORMATION -	 
// Call Type*	
// -Select-
// Appointment Date	
 
 
//  calendar(DD/MM/YYYY)	Appointment Time	
//  (HHMM)
// Caller Type	
// Customer
// Caller Mobile *	
// Service Center
// Eleconsolution
// Customer Remarks*	
// Dealer Name	
//  Dealer Name
// Remarks	
// Call Source*	
// Voice
// Contact Person	
// Contact Person Mobile	
// Qty for Call Registration*
// i want that based on the registered complaint pincode i want to assign that complaint to the nearest service centre based on the pincode there may be more than two service centres in the city with same pincode but different location so based on the distance from the customers addresses i want to assign the complaint to the nearest service centre 
// so please hemp me with the algorithm or logic to achieve this 
// and add it into my existing code below the show product code 

// do i need to create a new table for all service centers with their addresses and pincode or can i add the service centre detail in the existing service centre table itself please suggest me the best approach to achieve this 
 	 

// src/pages/call_centre/CallCenterLayout.jsx
import React from "react";
import { Outlet } from "react-router-dom";
import CC_Navbar from "./NavbarCS"; 
//call centre navbar component

export default function CallCenterLayout() {
  return (
    <div className="min-h-screen w-screen bg-gray-50">
      <CC_Navbar />
      <main className="p-4 pt-24">
        <Outlet />
      </main>
    </div>
  );
}

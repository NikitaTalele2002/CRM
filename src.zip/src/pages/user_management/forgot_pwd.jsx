import React from "react";


export default function ForgotPwd(){
    return (
        <div className="min-w-screen flex flex-col justify-center items-center bg-gray-100">
            <div className="w-96 p-6 bg-white rounded shadow-md">
                <h1 className="text-blue-500 text-xl font-bold mb-4">Forgot Password</h1>
                <form className='text-xl'>
                    <div>
                        <label className='block mb-2'>Email</label>
                        <input
                            type="email"
                            placeholder="Enter your email"
                            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <button type="submit" className="mt-4 w-full bg-blue-500 text-black py-2 rounded">Reset Password</button>
                    </div>
                </form>
            </div>
        </div>
    );
}



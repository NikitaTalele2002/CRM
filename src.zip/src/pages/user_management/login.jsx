import React, { useState } from "react";
import { useRole } from "../../context/RoleContext";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useRole(); 
  const navigate = useNavigate();

const handleLogin = (e) => {
  e.preventDefault();

  if (username === "service" && password === "123") {
    login("service_center");
    navigate("/service-center");
  }
  else if (username === "call" && password === "123") {
    login("call_center");
    navigate("/call-centre");
  }
  else {
    alert("Invalid credentials");
  }
};



  return (
    <div className="min-w-screen flex flex-col justify-center items-center bg-gray-100">
      <form
        onSubmit={handleLogin}
        className="bg-white p-6 rounded shadow-md w-96">
        <h2 className="text-xl font-bold mb-4 text-center">Login</h2>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="w-full border p-2 mb-4 rounded"
          required 
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full border p-2 mb-4 rounded"
          required
        />
        <div>
            <a onClick={() => window.location.href = '/forgot_pwd'} className="text-blue-500 hover:underline italic">Forgot Password?</a>
        </div>
        <div>
             <a onClick={() => window.location.href = '/signup'} className="text-blue-500 border-none">Sign Up</a>
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 text-black py-2 rounded hover:bg-blue-700">
          Login
        </button>
      </form>
    </div>
  );
}

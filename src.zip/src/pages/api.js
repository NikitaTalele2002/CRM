const CUSTOMER_API_BASE = "http://localhost:5000/api/customers";
const PRODUCT_API_BASE = "http://localhost:5000/api/products";

// 🆕 Create Customer
export async function createCustomer(form) {
  const res = await fetch(`${CUSTOMER_API_BASE}/`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(form),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Customer creation failed: ${errorText}`);
  }

  return res.json();
}

//  Search Customers
export async function searchCustomers(form) {
  const res = await fetch(`${CUSTOMER_API_BASE}/search`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(form),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Customer search failed: ${errorText}`);
  }

  return res.json();
}

//  Get All Products fetch from the database to print all the customers

export async function getProducts() {
  const res = await fetch(`${PRODUCT_API_BASE}`);
  if (!res.ok) throw new Error("Failed to load products");
  return res.json();
}

//  Register Product based on the database schema
export async function registerProduct(data) {
  const res = await fetch(`${PRODUCT_API_BASE}/add`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.log("ERROR:", res.status, res.statusText, errorText);
    throw new Error("Product registration failed");
  }

  return res.json();
}

//  Register Complaint in the database
export async function createComplaint(data) {
  const res = await fetch("http://localhost:5000/api/complaints", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Complaint creation failed: ${errorText}`);
  }

  return res.json();
}

async function fetchProductsByPhone(phone) {
  setLoading(true);
  try {
    const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
    if (!res.ok) throw new Error("Failed to fetch products");
    const data = await res.json();
    setProducts(Array.isArray(data) ? data : []); // <-- ensure array
  } catch (err) {
    console.error("Error fetching products:", err);
    setProducts([]); // <-- fallback
  } finally {
    setLoading(false);
  }
}

export { fetchProductsByPhone };

// export async function fetchProductsByPhone(phone) {
//   const res = await fetch(`${API_BASE}/products/by-phone/${phone}`);

//   if (!res.ok) throw new Error("Failed to fetch products");

//   return await res.json();
// }


// ------------- ASSIGN SERVICE CENTER API CALL --------------
export async function assignServiceCenter(customerAddress) {
  try {
    const res = await fetch("http://localhost:5000/api/assign-service-centre", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ customerAddress })
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.error || "Failed to assign service center");
    }

    return await res.json();
  } catch (err) {
    console.error("Assign Service Center API Error:", err);
    throw err;
  }
}
export async function registerComplaint(payload) {
  const res = await fetch(`${API_BASE}/complaints/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) throw new Error("Failed to register complaint");

  return await res.json();
}

const SERVICE_CENTER = "D Mart, Plot No R-1, Sector 3, Nerul, Navi Mumbai, Maharashtra 400706, India";
const CUSTOMER = "Terna Engineering College, Plot No.12, Sector 22, Nerul, Navi Mumbai, Maharashtra 400706, India";

// this code is not working for this now 
// please fix this code and give me complete new code
// i got this error Error: Unable to geocode address: D Mart, Plot No R-1, Sector 3, Nerul, Navi Mumbai, Maharashtra 400706, India
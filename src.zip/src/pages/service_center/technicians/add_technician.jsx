// src/pages/service_center/AddTechnician.jsx
import React, { useState, useEffect } from "react";

export default function AddTechnician({ selectedTech, onSave }) {
  const initialFormData = {
    id: "",
    name: "",
    mobileNo: "",
    email: "",
    status: "",
  };

  const [formData, setFormData] = useState(initialFormData);

  // If editing, populate data
  useEffect(() => {
    if (selectedTech) setFormData(selectedTech);
  }, [selectedTech]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
    setFormData(initialFormData);
  };

  return (
    <div>
      <h2 className="text-lg font-bold mb-4">
        {formData.id ? "Edit Technician" : "Add Technician"}
      </h2>

      <form onSubmit={handleSubmit} className="mt-2">
        <table className="border border-gray-300 w-full">
          <tbody>
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold w-1/3">Name</td>
              <td className="p-2">
                <input
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  type="text"
                  placeholder="Enter Name"
                  className="border border-gray-300 p-2 rounded w-full"
                  required
                />
              </td>
            </tr>

            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Mobile No.</td>
              <td className="p-2">
                <input
                  name="mobileNo"
                  value={formData.mobileNo}
                  onChange={handleChange}
                  type="tel"
                  placeholder="Enter Mobile Number"
                  className="border border-gray-300 p-2 rounded w-full"
                  required
                />
              </td>
            </tr>

            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Email</td>
              <td className="p-2">
                <input
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  type="email"
                  placeholder="Enter Email"
                  className="border border-gray-300 p-2 rounded w-full"
                  required
                />
              </td>
            </tr>

            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Status</td>
              <td className="p-2">
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full"
                  required >
                  <option value="">Select</option>
                  <option value="Active">Active</option>
                  <option value="Deactive">Deactive</option>
                </select>
              </td>
            </tr>

            <tr>
              <td colSpan="2" className="text-center p-4">
                <button className="bg-blue-600 hover:bg-blue-700 text-black px-6 py-2 rounded">
                  {formData.id ? "Update Technician" : "Add Technician"}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}


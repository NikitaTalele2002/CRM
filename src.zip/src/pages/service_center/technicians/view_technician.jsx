// src/pages/service_center/ViewTechnicians.jsx
import React from "react";

export default function ViewTechnicians({ technicians = [], onEdit, onRemove }) {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">View Technicians</h2>

      {technicians.length === 0 ? (
        <p>No technicians available.</p>
      ) : (
        <table className="border-2 border-gray-300 w-full text-left">
          <thead className="bg-gray-200">
            <tr>
              <th className="border-2 p-2">Technician ID</th>
              <th className="border-2 p-2">Name</th>
              <th className="border-2 p-2">Mobile No.</th>
              <th className="border-2 p-2">Email</th>
              <th className="border-2 p-2">Status</th>
              <th className="border-2 p-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {technicians.map((tech) => (
              <tr key={tech.id}>
                <td className="border-2 p-2">{tech.id}</td>
                <td className="border-2 p-2">{tech.name}</td>
                <td className="border-2 p-2">{tech.mobileNo}</td>
                <td className="border-2 p-2">{tech.email}</td>
                <td className="border-2 p-2">{tech.status}</td>
                <td className="border-2 p-2 text-center">
                  <button
                    onClick={() => onEdit(tech)}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded mr-2"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => onRemove(tech.id)}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

import React from "react";

export default function RentalReturn() {
  const initialFormData = {
    technicianName: "",
    productGroup: "",
    productType: "",
    model: "",
    quantity: "",
    condition: "",
    remarks: "",
  };

  const [formData, setFormData] = React.useState(initialFormData);

  const technicians = ["John Doe", "Jane Smith", "Bob Lee"];
  const productGroups = ["Digital Lock", "Fans", "Irons"];
// here we can add the enum values in the database table so that dropdown is not required 

  const productTypeMap = {
    "Digital Lock": ["Door Lock"],
    Fans: [
      "Ceiling Fan",
      "Table Fan",
      "Exhaust Fan",
      "Wall Fan",
      "Oscillation Fan",
      "Pedestal Fan",
    ],
    Irons: ["Dry Iron", "Steam Iron"],
  };

  const modelMap = {
    "Door Lock": ["DL100", "DL200"],
    "Ceiling Fan": ["CF-Alpha", "CF-Beta"],
    "Table Fan": ["TF-Standard", "TF-Pro"],
    "Exhaust Fan": ["EF-100", "EF-200"],
    "Wall Fan": ["WF-std", "WF-Pro"],
    "Oscillation Fan": ["OF-standard", "OF-Pro"],
    "Pedestal Fan": ["PF-Standard", "PF-Pro"],
    "Dry Iron": ["DI-1", "DI-2"],
    "Steam Iron": ["SI-100", "SI-200"],
  };

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "productGroup") {
      setFormData((prev) => ({
        ...prev,
        productGroup: value,
        productType: "",
        model: "",
      }));
    } else if (name === "productType") {
      setFormData((prev) => ({
        ...prev,
        productType: value,
        model: "",
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Rental return saved!");
    console.log("Submitted:", formData);
    setFormData(initialFormData);
  };

  const productTypes = formData.productGroup
    ? productTypeMap[formData.productGroup]
    : [];

  const models = formData.productType ? modelMap[formData.productType] : [];

  return (
    <div>
      <h2 className="text-xl font-bold">Rental Return</h2>
      <h4 className="font-bold text-red-500 mt-2">
        Return Spare Parts from Technician
      </h4>

      <form onSubmit={handleSubmit} className="mt-4">
        <table className="border border-gray-300 w-full">
          <tbody>
            {/* Technician Name */}
            <tr className="border">
              <td className="p-2 font-semibold w-1/3">Technician</td>
              <td className="p-2">
                <select
                  name="technicianName"
                  value={formData.technicianName}
                  onChange={handleChange}
                  className="border p-2 rounded w-full" >
                  <option value="">Select Technician</option>
                  {technicians.map((tech) => (
                    <option key={tech} value={tech}>
                      {tech}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Product Group */}
            <tr className="border">
              <td className="p-2 font-semibold">Product Group</td>
              <td className="p-2">
                <select
                  name="productGroup"
                  value={formData.productGroup}
                  onChange={handleChange}
                  className="border p-2 rounded w-full">
                  <option value="">Select Product Group</option>
                  {productGroups.map((group) => (
                    <option key={group} value={group}>
                      {group}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Product Type */}
            <tr className="border">
              <td className="p-2 font-semibold">Product Type</td>
              <td className="p-2">
                <select
                  name="productType"
                  value={formData.productType}
                  onChange={handleChange}
                  className="border p-2 rounded w-full"
                  disabled={!formData.productGroup} >
                  <option value="">Select Product Type</option>
                  {productTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Model */}
            <tr className="border">
              <td className="p-2 font-semibold">Model</td>
              <td className="p-2">
                <select
                  name="model"
                  value={formData.model}
                  onChange={handleChange}
                  className="border p-2 rounded w-full"
                  disabled={!formData.productType} >
                  <option value="">Select Model</option>
                  {models.map((model) => (
                    <option key={model} value={model}>
                      {model}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Quantity */}
            <tr className="border">
              <td className="p-2 font-semibold">Quantity</td>
              <td className="p-2">
                <input
                  type="number"
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleChange}
                  className="border p-2 rounded w-full"
                  placeholder="Enter quantity"/>
              </td>
            </tr>

            {/* Condition */}
            <tr className="border">
              <td className="p-2 font-semibold">Condition</td>
              <td className="p-2">
                <select
                  name="condition"
                  value={formData.condition}
                  onChange={handleChange}
                  className="border p-2 rounded w-full">
                  <option value="">Select condition</option>
                  <option value="Good">Good</option>
                  <option value="Damaged">Damaged</option>
                  <option value="Faulty">Faulty</option>
                </select>
              </td>
            </tr>

            {/* Remarks */}
            <tr className="border align-top">
              <td className="p-2 font-semibold">Remarks</td>
              <td className="p-2">
                <textarea
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleChange}
                  rows="3"
                  className="border p-2 rounded w-full"
                  placeholder="Enter remarks"/>
              </td>
            </tr>

            {/* Submit */}
            <tr>
              <td colSpan="2" className="text-center p-4">
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-black px-6 py-2 rounded"> Save Return
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>
    </div>
  );
}

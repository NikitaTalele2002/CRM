import React, { useState } from "react";

export default function GenerateDCF() {
  const initialFormData = {
    technician: "",
    productGroup: "",
    productType: "",
    model: "",
    quantity: "",
    remarks:"",
  };

  const [formData, setFormData] = useState(initialFormData);
  const [dcfList, setDcfList] = useState([]);

  const technicians = ["John Doe", "Jane Smith", "Bob Lee"];
  const productGroups = ["Digital Lock", "Fans", "Irons"];

  const productTypeMap = {
    "Digital Lock": ["Door Lock"],
    Fans: ["Ceiling Fan", "Table Fan", "Exhaust Fan"],
    Irons: ["Dry Iron", "Steam Iron"],
  };

  const modelMap = {
    "Door Lock": ["DL100", "DL200"],
    "Ceiling Fan": ["CF-Alpha", "CF-Beta"],
    "Table Fan": ["TF-Standard", "TF-Pro"],
    "Exhaust Fan": ["EF-100", "EF-200"],
    "Dry Iron": ["DI-1", "DI-2"],
    "Steam Iron": ["SI-100", "SI-200"],
  };

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "productGroup") {
      setFormData({
        ...formData,
        productGroup: value,
        productType: "",
        model: "",
      });
    } else if (name === "productType") {
      setFormData({
        ...formData,
        productType: value,
        model: "",
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const productTypes = formData.productGroup
    ? productTypeMap[formData.productGroup]
    : [];

  const models = formData.productType ? modelMap[formData.productType] : [];

  // Add row to DCF
  const handleAdd = () => {
    if (
      !formData.technician ||
      !formData.productGroup ||
      !formData.productType ||
      !formData.model ||
      !formData.quantity
    ) {
      alert("Please fill mandatory fields");
      return;
    }

    setDcfList([...dcfList, formData]);
    setFormData(initialFormData);
  };

  // Delete row
  const deleteRow = (index) => {
    const updated = [...dcfList];
    updated.splice(index, 1);
    setDcfList(updated);
  };

  // Generate DCF
  const generateDCF = () => {
    if (dcfList.length === 0) {
      alert("Please add items to DCF");
      return;
    }

    alert("DCF Generated Successfully!");

    console.log("Generated DCF:", dcfList);

    // Later:
    // fetch("/api/dcf/create", { method: "POST", body: JSON.stringify(dcfList) })

    setDcfList([]);
  };

  return (
    <div>
      <h2 className="text-xl font-bold">Generate DCF</h2>
      <h4 className="text-red-500 font-bold mt-2">Delivery Challan Form</h4>

      {/* Form */}
      <div className="border border-gray-300 p-4 mt-4 rounded">
        <div className="grid grid-cols-2 gap-4">

          {/* Technician */}
          <div>
            <label className="font-semibold">Technician</label>
            <select
              name="technician"
              value={formData.technician}
              onChange={handleChange}
              className="border p-2 rounded w-full">
              <option value="">Select Technician</option>
              {technicians.map((tech) => (
                <option key={tech} value={tech}>
                  {tech}
                </option>
              ))}
            </select>
          </div>

          {/* Product Group */}
          <div>
            <label className="font-semibold">Product Group</label>
            <select
              name="productGroup"
              value={formData.productGroup}
              onChange={handleChange}
              className="border p-2 rounded w-full">
              <option value="">Select</option>
              {productGroups.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          {/* Product Type */}
          <div>
            <label className="font-semibold">Product Type</label>
            <select
              name="productType"
              value={formData.productType}
              onChange={handleChange}
              className="border p-2 rounded w-full"
              disabled={!formData.productGroup} >
              <option value="">Select</option>
              {productTypes.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>

          {/* Model */}
          <div>
            <label className="font-semibold">Model</label>
            <select
              name="model"
              value={formData.model}
              onChange={handleChange}
              className="border p-2 rounded w-full"
              disabled={!formData.productType}>
              <option value="">Select</option>
              {models.map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity */}
          <div>
            <label className="font-semibold">Quantity</label>
            <input
              type="number"
              name="quantity"
              value={formData.quantity}
              onChange={handleChange}
              className="border p-2 rounded w-full"
              placeholder="Enter quantity"/>
          </div>

          {/* Remarks */}
          <div className="col-span-2">
            <label className="font-semibold">Remarks</label>
            <textarea
              name="remarks"
              value={formData.remarks}
              onChange={handleChange}
              rows="3"
              className="border p-2 rounded w-full"
              placeholder="Optional remarks" />
          </div>
        </div>

        {/* Add Button */}
        <button
          onClick={handleAdd}
          className="mt-4 bg-green-600 text-black px-6 py-2 rounded hover:bg-green-700">Add
        </button>
      </div>

      {/* DCF Table */}
      <table className="w-full border border-gray-300 mt-6">
        <thead className="bg-gray-200">
          <tr>
            <th className="border p-2">Technician</th>
            <th className="border p-2">Product Group</th>
            <th className="border p-2">Product Type</th>
            <th className="border p-2">Model</th>
            <th className="border p-2">Quantity</th>
            <th className="border p-2">Remarks</th>
            <th className="border p-2">Action</th>
          </tr>
        </thead>

        <tbody>
          {dcfList.length > 0 ? (
            dcfList.map((item, index) => (
              <tr key={index}>
                <td className="border p-2">{item.technician}</td>
                <td className="border p-2">{item.productGroup}</td>
                <td className="border p-2">{item.productType}</td>
                <td className="border p-2">{item.model}</td>
                <td className="border p-2">{item.quantity}</td>
                <td className="border p-2">{item.remarks}</td>
                <td className="border p-2 text-center">
                  <button
                    onClick={() => deleteRow(index)}
                    className="bg-red-500 text-black px-3 py-1 rounded">Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" className="text-center p-4 text-gray-500">No items added
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Submit Button */}
      <button
        onClick={generateDCF}
        className="mt-6 bg-blue-600 text-black px-8 py-2 rounded hover:bg-blue-700">Generate DCF
      </button>
    </div>
  );
}

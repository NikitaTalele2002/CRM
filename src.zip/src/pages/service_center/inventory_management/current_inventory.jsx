import React, { useState } from "react";

export default function CurrentInventory() {
  const [filters, setFilters] = useState({
    productGroup: "",
    productType: "",
    model: "",
  });

  // Dummy Inventory Data — Replace with API data later
  const inventoryData = [
    {
      id: 1,
      productGroup: "Fans",
      productType: "Ceiling Fan",
      model: "CF-Alpha",
      quantity: 20,
      status: "Good",
    },
    {
      id: 2,
      productGroup: "Fans",
      productType: "Table Fan",
      model: "TF-Pro",
      quantity: 15,
      status: "Damaged",
    },
    {
      id: 3,
      productGroup: "Digital Lock",
      productType: "Door Lock",
      model: "DL100",
      quantity: 7,
      status: "Good",
    },
  ];

  const productGroups = ["Digital Lock", "Fans", "Irons"];

  const productTypeMap = {
    "Digital Lock": ["Door Lock"],
    Fans: ["Ceiling Fan", "Table Fan", "Exhaust Fan"],
    Irons: ["Dry Iron", "Steam Iron"],
  };

  const modelMap = {
    "Door Lock": ["DL100", "DL200"],
    "Ceiling Fan": ["CF-Alpha", "CF-Beta"],
    "Table Fan": ["TF-Standard", "TF-Pro"],
    "Exhaust Fan": ["EF-100", "EF-200"],
    "Dry Iron": ["DI-1", "DI-2"],
    "Steam Iron": ["SI-100", "SI-200"],
  };

  const handleFilter = (e) => {
    const { name, value } = e.target;

    if (name === "productGroup") {
      setFilters({
        productGroup: value,
        productType: "",
        model: "",
      });
    } else if (name === "productType") {
      setFilters((prev) => ({
        ...prev,
        productType: value,
        model: "",
      }));
    } else {
      setFilters((prev) => ({ ...prev, [name]: value }));
    }
  };

  const filteredInventory = inventoryData.filter((item) => {
    return (
      (!filters.productGroup ||
        item.productGroup === filters.productGroup) &&
      (!filters.productType || item.productType === filters.productType) &&
      (!filters.model || item.model === filters.model)
    );
  });

  const productTypes = filters.productGroup
    ? productTypeMap[filters.productGroup]
    : [];

  const models = filters.productType ? modelMap[filters.productType] : [];

  return (
    <div>
      <h2 className="text-xl font-bold">Current Inventory</h2>

      {/* Filters Section */}
      <div className="grid grid-cols-3 gap-4 my-4">

        {/* Product Group */}
        <div>
          <label className="font-semibold">Product Group</label>
          <select
            name="productGroup"
            value={filters.productGroup}
            onChange={handleFilter}
            className="border p-2 rounded w-full">
            <option value="">All</option>
            {productGroups.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </div>

        {/* Product Type */}
        <div>
          <label className="font-semibold">Product Type</label>
          <select
            name="productType"
            value={filters.productType}
            onChange={handleFilter}
            className="border p-2 rounded w-full"
            disabled={!filters.productGroup}>
            <option value="">All</option>
            {productTypes.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Model */}
        <div>
          <label className="font-semibold">Model</label>
          <select
            name="model"
            value={filters.model}
            onChange={handleFilter}
            className="border p-2 rounded w-full"
            disabled={!filters.productType}    >
            <option value="">All</option>
            {models.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Inventory Table */}
      <table className="w-full border border-gray-300 mt-4">
        <thead className="bg-gray-200">
          <tr>
            <th className="border p-2">Product Group</th>
            <th className="border p-2">Product Type</th>
            <th className="border p-2">Model</th>
            <th className="border p-2">Quantity</th>
            <th className="border p-2">Status</th>
          </tr>
        </thead>

        <tbody>
          {filteredInventory.length > 0 ? (
            filteredInventory.map((item) => (
              <tr key={item.id}>
                <td className="border p-2">{item.productGroup}</td>
                <td className="border p-2">{item.productType}</td>
                <td className="border p-2">{item.model}</td>
                <td className="border p-2">{item.quantity}</td>
                <td className="border p-2">{item.status}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="text-center p-4 text-red-500">
                No inventory found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

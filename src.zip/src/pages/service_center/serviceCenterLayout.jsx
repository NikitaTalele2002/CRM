// src/components/DashboardLayout.jsx
import React, { useState } from "react";
import Navbar from "./navbar";
import Sidebar from "./sidebar";
import { Outlet } from "react-router-dom";

const ServiceCenterLayout = () => {
  const [activeModule, setActiveModule] = useState("service"); // default module

  return (
    <div>
      <Navbar setActiveModule={setActiveModule} activeModule={activeModule} />
      <div className="flex">
        <Sidebar activeModule={activeModule} />
        <div className="flex-1 p-6 bg-gray-50 min-h-screen">
          <Outlet /> {/* renders the selected route */}
        </div>
      </div>
    </div>
  );
};

export default ServiceCenterLayout;

import React from 'react';

export default function AssignComplaint() {
  return (
    <div style={{ padding: 16 }}>
      <h1 className="text-2xl font-bold mb-4">Assign Complaint</h1>
      <p>This is a static Assign Complaint page. Replace this with real assignment UI later.</p>

      <div className="mt-4 p-4 border rounded bg-white">
        <h2 className="font-semibold mb-2">Quick Actions</h2>
        <ul className="list-disc ml-6 text-gray-700">
          <li>List unassigned complaints</li>
          <li>Choose technician and assign</li>
          <li>Update status and ETA</li>
        </ul>
      </div>
    </div>
  );
}

// import React, { useEffect, useState } from "react";

// export default function ViewComplaints() {
//   const [data, setData] = useState([]);
//   const [technicians, setTechnicians] = useState([]);

//   useEffect(() => {
//     fetchComplaints();
//   }, []);

//   async function fetchComplaints() {
//     try {
//       const res = await fetch("http://localhost:5000/api/complaints");
//       if (!res.ok) throw new Error(res.statusText || "API Not Found");
//       const result = await res.json();
//       setData(result.complaints || []);
//       setTechnicians(result.technicians || []);
//     } catch (err) {
//       console.error("Error fetching complaints:", err);
//       setData([]);
//       setTechnicians([]);
//     }
//   }

//   async function assignTechnician(productId, technicianId) {
//     try {
//       const res = await fetch("http://localhost:5000/api/complaints/assign-technician", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ complaintId: productId, technicianId }),
//       });

//       const result = await res.json();
//       alert(result.message || "Assigned");
//       fetchComplaints();
//     } catch (err) {
//       console.error("Error assigning technician:", err);
//       alert("Assignment failed");
//     }
//   }

//   return (
//     <div className="p-6">
//       <h1 className="text-2xl font-bold mb-4">Complaints List</h1>

//       <table className="border border-gray-300 w-full">
//         <thead>
//           <tr className="bg-gray-200">
//             <th className="p-2">Customer Name</th>
//             <th>Mobile</th>
//             <th>City</th>
//             <th>Product</th>
//             <th>Model</th>
//             <th>Serial No</th>
//             <th>Warranty</th>
//             <th>Call Status</th>
//             <th>Assign Technician</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data.map((row) => (
//             <tr key={row.ProductId} className="border-t">
//               <td className="p-2">{row.CustomerName}</td>
//               <td>{row.MobileNo}</td>
//               <td>{row.City}</td>
//               <td>{row.Product}</td>
//               <td>{row.Model}</td>
//               <td>{row.ProductSerialNo}</td>
//               <td>{row.WarrantyStatus}</td>
//               <td>{row.CallStatus}</td>
//               <td>
//                 <select
//                   onChange={(e) => assignTechnician(row.ProductId, e.target.value)}
//                   defaultValue=""
//                 >
//                   <option value="" disabled>Select Technician</option>
//                   {technicians.map((t) => (
//                     <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
//                   ))}
//                 </select>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }




// import React, { useEffect, useState } from "react";

// export default function ViewComplaints() {
//   const [data, setData] = useState([]);
//   const [technicians, setTechnicians] = useState([]);

//   useEffect(() => {
//     fetchComplaints();
//   }, []);

//   async function fetchComplaints() {
//     try {
//       const res = await fetch("http://localhost:5000/api/complaints");
//       if (!res.ok) throw new Error(res.statusText || "API Not Found");
//       const result = await res.json();
//       setData(result.complaints || []);
//       setTechnicians(result.technicians || []);
//     } catch (err) {
//       console.error("Error fetching complaints:", err);
//       setData([]);
//       setTechnicians([]);
//     }
//   }

//   async function assignTechnician(productId, technicianId) {
//     try {
//       const res = await fetch("http://localhost:5000/api/complaints/assign-technician", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ complaintId: productId, technicianId }),
//       });

//       const result = await res.json();
//       alert(result.message || "Assigned");
//       fetchComplaints();
//     } catch (err) {
//       console.error("Error assigning technician:", err);
//       alert("Assignment failed");
//     }
//   }

//   return (
//     <div className="p-6">
//       <h1 className="text-2xl font-bold mb-4">Complaints List</h1>

//       <table className="border border-gray-300 w-full">
//         <thead>
//           <tr className="bg-gray-200">
//             <th className="p-2">Customer Name</th>
//             <th>Mobile</th>
//             <th>City</th>
//             <th>Product</th>
//             <th>Model</th>
//             <th>Serial No</th>
//             <th>Warranty</th>
//             <th>Call Status</th>
//             <th>Assign Technician</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data.map((row) => (
//             <tr key={row.ProductId} className="border-t">
//               <td className="p-2">{row.CustomerName}</td>
//               <td>{row.MobileNo}</td>
//               <td>{row.City}</td>
//               <td>{row.Product}</td>
//               <td>{row.Model}</td>
//               <td>{row.ProductSerialNo}</td>
//               <td>{row.WarrantyStatus}</td>
//               <td>{row.CallStatus}</td>
//               <td>
//                 <select
//                   onChange={(e) => assignTechnician(row.ProductId, e.target.value)}
//                   defaultValue=""
//                 >
//                   <option value="" disabled>Select Technician</option>
//                   {technicians.map((t) => (
//                     <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
//                   ))}
//                 </select>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }










import React, { useEffect, useState } from "react";

export default function ViewComplaints() {
  const [data, setData] = useState([]);
  const [technicians, setTechnicians] = useState([]);

  useEffect(() => {
    fetchComplaints();
  }, []);

  async function fetchComplaints() {
    try {
      const selectedCenter = localStorage.getItem("selectedServiceCenterId");
      let url = "http://localhost:5000/api/complaints";
      if (selectedCenter) url += `?centerId=${encodeURIComponent(selectedCenter)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(res.statusText || "API Not Found");
      const result = await res.json();
      setData(result.complaints || []);
      setTechnicians(result.technicians || []);
    } catch (err) {
      console.error("Error fetching complaints:", err);
      setData([]);
      setTechnicians([]);
    }
  }

  async function assignTechnician(productId, technicianId) {
    try {
      const res = await fetch("http://localhost:5000/api/complaints/assign-technician", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // If the row has a ProductId we send it as productId, otherwise treat it as complaintId
        body: JSON.stringify({ productId, technicianId }),
      });

      const result = await res.json();
      alert(result.message || "Assigned");
      fetchComplaints();
    } catch (err) {
      console.error("Error assigning technician:", err);
      alert("Assignment failed");
    }
  }
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Complaints List</h1>

      <table className="border border-gray-300 w-full">
        <thead>
          <tr className="bg-gray-200">
            <th className="p-2">Customer Name</th>
            <th>Mobile</th>
            <th>City</th>
            <th>Product</th>
            <th>Model</th>
            <th>Serial No</th>
            <th>Warranty</th>
            <th>Call Status</th>
            <th>Assign Technician</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
              <tr key={row.ComplaintId ?? row.ProductId ?? `${row.MobileNo}-${row.ProductSerialNo}` } className="border-t">
              <td className="p-2">{row.CustomerName}</td>
              <td>{row.MobileNo}</td>
              <td>{row.City}</td>
              <td>{row.Product}</td>
              <td>{row.Model}</td>
              <td>{row.ProductSerialNo}</td>
              <td>{row.WarrantyStatus}</td>
              <td>{row.CallStatus}</td>
              <td>
                <select
                  onChange={(e) => assignTechnician(row.ProductId ?? row.ComplaintId, e.target.value)}
                  defaultValue="">
                  <option value="" disabled>Select Technician</option>
                  {technicians.map((t) => (
                    <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
                  ))}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}








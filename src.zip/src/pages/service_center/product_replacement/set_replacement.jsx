import React from "react";
import { NavLink, Outlet } from "react-router-dom";
import Navbar from "../navbar";

export default function SetReplacement() {
    return(
        <div>
            This is product replacement
        </div>
    )
}

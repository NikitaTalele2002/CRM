// import React from "react";
// import { BrowserRouter, Routes, Route, Navigate, Outlet } from "react-router-dom";
// import { RoleProvider } from "./context/RoleContext";
// import ProtectedRoute from "./components/ProtectedRoute";
// import Loader from "./components/Loader";

// // User Management



// import Login from "./pages/user_management/login";
// import Signup from "./pages/user_management/signup";
// import ForgotPwd from "./pages/user_management/forgot_pwd";

// // Call Centre
// // import CallCenterLayout from "./pages/call_centre/callCentreDashboardLayout";
// import CallSearch from "./pages/call_centre/call_search";
// import ComplaintRegistration from "./pages/call_centre/complaint_registration";
// import CC_Dashboard from "./pages/call_centre/dashboardCS";

// // Service Center
// import DashboardSC from "./pages/service_center/dashboardSC";
// import Technicians from "./pages/service_center/technicians/technicians";
// import AddTechnician from "./pages/service_center/technicians/add_technician";
// import ViewTechnician from "./pages/service_center/technicians/view_technician";

// // Inventory
// import RentalAllocation from "./pages/service_center/inventory_management/rental_allocation";
// import RentalReturn from "./pages/service_center/inventory_management/rental_return";
// import CurrentInventory from "./pages/service_center/inventory_management/current_inventory";
// import OrderRequest from "./pages/service_center/inventory_management/order_request";
// import ConfirmRequest from "./pages/service_center/inventory_management/confirm_request";
// import SparePartReturn from "./pages/service_center/inventory_management/spare_part_return";
// import GenerateDCF from "./pages/service_center/inventory_management/generate_DCF";
// // Product Replacement
// import SetReplacement from "./pages/service_center/product_replacement/set_replacement";
// import ViewReplacementHistory from "./pages/service_center/product_replacement/view_replacement_history";

// // Layouts
// import DashboardLayout from "./pages/service_center/serviceCenterLayout";
// import CallCenterLayout from "./pages/call_centre/callCentreDashboardLayout";

// // 404 Page
// function NotFound() {
//   return (
//     <div className="p-6">
//       <h2 className="text-2xl font-bold">404 — Page not found</h2>
//     </div>
//   );
// }

// export default function App() {
//   return (
//     <RoleProvider>
//       <BrowserRouter>
//         <React.Suspense fallback={<Loader />}>
//           <Routes>
//             {/* ---------- Public Routes ---------- */}
//             <Route path="/login" element={<Login />} />
//             <Route path="/signup" element={<Signup />} />
//             <Route path="/forgot-password" element={<ForgotPwd />} />

//             {/* Default Redirect */}
//             <Route path="/" element={<Navigate to="/service-center/dashboardSC" replace />} />

//             {/* ---------- Protected Routes ---------- */}

//             {/* Service Center Routes */}
//             <Route
//               element={
//                 <ProtectedRoute allowedRoles={["admin", "service_center"]}>
//                   <DashboardLayout />
//                 </ProtectedRoute>
//               }>
//               <Route path="/service-center" element={<Outlet />}>
//                 {/* Dashboard */}
//                 <Route index element={<DashboardSC />} />
//                 <Route path="dashboardSC" element={<DashboardSC />} />

//                 {/* Inventory */}
//                 <Route path="inventory" element={<Outlet />}>
//                   <Route path="order-request" element={<OrderRequest />} />
//                   <Route path="spare-return" element={<SparePartReturn />} />
//                   <Route path="confirm-request" element={<ConfirmRequest />} />
//                   <Route path="rental-allocation" element={<RentalAllocation />} />
//                   <Route path="rental-return" element={<RentalReturn />} />
//                   <Route path="current-inventory" element={<CurrentInventory />} />
//                   <Route path="generate-dcf" element={<GenerateDCF />} />
//                 </Route>

//                 {/* Technicians */}
//                 <Route path="technicians" element={<Outlet />}>
//                   <Route path="technicians" element={<Technicians/>} />
//                   <Route path="add" element={<AddTechnician />} />
//                   <Route path="view" element={<ViewTechnician />} />
//                 </Route>

//                 {/* Product Replacement */}
//                 <Route path="product-replacement" element={<Outlet />}>
//                   <Route path="set" element={<SetReplacement />} />
//                   <Route path="history" element={<ViewReplacementHistory />} />
//                 </Route>
//               </Route>
//             </Route>

//             {/* Call Centre Routes */}
//             <Route
//               element={
//                 <ProtectedRoute allowedRoles={["admin", "call_center"]}>
//                   <CallCenterLayout/>
//                 </ProtectedRoute>
//               }>
//               <Route path="/call-centre" element={<Outlet />}>
//                 <Route index element={<CC_Dashboard />} />
//                 <Route path="dashboardCS" element={<CC_Dashboard />} />
//                 <Route path="search" element={<CallSearch />} />
//                 <Route path="register" element={<ComplaintRegistration />} />
//                 {/* later add report route here if needed */}
//                 {/* <Route path="report" element={<Report />} /> */}
//               </Route>
//             </Route>

//             {/* ---------- 404 ---------- */}
//             <Route path="*" element={<NotFound />} />
//           </Routes>
//         </React.Suspense>
//       </BrowserRouter>
//     </RoleProvider>
//   );
// }


import React, { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, Outlet } from "react-router-dom";
import { RoleProvider } from "./context/RoleContext";
import ProtectedRoute from "./components/ProtectedRoute";
import Loader from "./components/Loader";
import Navbar from "./components/Navbar";

// Call Centre Pages
import SearchForm from "./pages/call_centre/SearchForm";
import CustomerCard from "./pages/call_centre/CustomerCard";
import AddCustomerForm from "./pages/call_centre/AddCustomerForm";
import ComplaintForm from "./pages/call_centre/ComplaintForm";
import CallCenterLayout from "./pages/call_centre/callCentreDashboardLayout";


import Login from "./pages/user_management/login";
import Signup from "./pages/user_management/signup";
import ForgotPwd from "./pages/user_management/forgot_pwd";


// Product Pages
import RegisterProduct from "./pages/call_centre/registerProduct";
import ShowProducts from "./pages/call_centre/ShowProducts";

export default function App() {
  const [customer, setCustomer] = useState(null);
  const [showAdd, setShowAdd] = useState(false);

  return (
    <BrowserRouter>
      <Navbar />
      <div className="pt-16">
      <Routes>

        {/* ---------- DEFAULT PAGE (Complaint Registration) ---------- */}

     
        <Route
          path="/"
          element={
            <div style={{ padding: 20 }}>
              <h2>Complaint Registration</h2>

              <SearchForm
                onResult={(rows) => {
                  if (rows?.length > 0) {
                    setCustomer(rows[0]);
                    setShowAdd(false);
                  } else {
                    setCustomer(null);
                    setShowAdd(true);
                  }
                }}
              />

              {customer && (
                <>
                  <CustomerCard customer={customer} />
                  <ComplaintForm customer={customer} />
                </>
              )}

              {showAdd && (
                <AddCustomerForm onCreated={(c) => setCustomer(c)} />
              )}
            </div>
          }
        />

        {/* ---------- PRODUCT PAGES ---------- */}
        <Route path="/call-centre/register" element={<RegisterProduct customer={customer}  />} />
        <Route path="/call-centre/show" element={<ShowProducts customer={customer}/>} />
      </Routes>
      </div>
    </BrowserRouter>
  );
}


// end of the file
// this is my previous code but as i change the product table now i want you to write the product registration code for me



// import React, { useEffect, useState } from "react";
// import { useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const customer = location.state?.customer;
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     if (customer) fetchProductsByPhone(customer.MobileNo);
//   }, [customer]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(data || []);
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   if (!customer) return <p>Please select a customer first.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Customer & Product Details</h2>

//       {/* Customer Form */}
//       <h3>Customer Information</h3>
//       <form style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//         <label>Name:</label>
//         <input value={customer.Name || ""} readOnly /><br />
//         <label>Mobile No:</label>
//         <input value={customer.MobileNo || ""} readOnly /><br />
//         <label>Email:</label>
//         <input value={customer.Email || ""} readOnly /><br />
//         <label>Address:</label>
//         <input value={customer.Address || ""} readOnly /><br />
//         <label>City:</label>
//         <input value={customer.City || ""} readOnly /><br />
//         <label>State:</label>
//         <input value={customer.State || ""} readOnly /><br />
//         <label>Pin Code:</label>
//         <input value={customer.PinCode || ""} readOnly /><br />
//         <label>Customer Type:</label>
//         <input value={customer.CustomerType || ""} readOnly /><br />
//         <label>Active:</label>
//         <input value={customer.Active ? "Yes" : "No"} readOnly /><br />
//       </form>

//       {/* Products */}
//       <h3>Products for this Customer</h3>
//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products registered for this customer.</p>
//       ) : (
//         products.map((p) => (
//           <form key={p.Id} style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//             <label>Product Group:</label>
//             <input value={p.ProductGroup} readOnly /><br />
//             <label>Brand:</label>
//             <input value={p.Brand} readOnly /><br />
//             <label>Product:</label>
//             <input value={p.Product} readOnly /><br />
//             <label>Model:</label>
//             <input value={p.Model} readOnly /><br />
//             <label>Serial No:</label>
//             <input value={p.ProductSerialNo} readOnly /><br />
//             <label>Purchase Date:</label>
//             <input value={p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : ""} readOnly /><br />
//             <label>Dealer Name:</label>
//             <input value={p.DealerName} readOnly /><br />
//             <label>Warranty Status:</label>
//             <input value={p.WarrantyStatus} readOnly /><br />
//             <label>Previous Calls:</label>
//             <input value={p.PreviousCalls} readOnly /><br />
//             <label>Call Status:</label>
//             <input value={p.CallStatus} readOnly /><br />
//           </form>
//         ))
//       )}
//     </div>
//   );
// }
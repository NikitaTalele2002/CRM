// const express = require('express');
// const router = express.Router();

// // Lightweight sample location data. You can replace these queries
// // with real DB lookups later if you have a locations table.
// const SAMPLE = {
//   states: [
//     { id: 'MH', name: 'Maharashtra' },
//     { id: 'KA', name: 'Karnataka' },
//     { id: 'DL', name: 'Delhi' },
//   ],
//   cities: {
//     MH: [
//       { id: 'mumbai', name: 'Mumbai' },
//       { id: 'pune', name: 'Pune' },
//       { id: 'nerul', name: 'Nerul' },
//     ],
//     KA: [
//       { id: 'bangalore', name: 'Bengaluru' },
//       { id: 'mysore', name: 'Mysuru' },
//     ],
//     DL: [
//       { id: 'newdelhi', name: 'New Delhi' },
//       { id: 'north', name: 'North Delhi' },
//     ],
//   },
//   pincodes: {
//     nerul: ['400706', '400706-2'],
//     mumbai: ['400001', '400002'],
//     pune: ['411001', '411002'],
//     bangalore: ['560001', '560002'],
//     mysore: ['570001'],
//     newdelhi: ['110001'],
//     north: ['110007'],
//   },
// };

// // GET /api/location/states
// router.get('/states', async (req, res) => {
//   try {
//     res.json(SAMPLE.states);
//   } catch (err) {
//     res.status(500).json({ error: 'Failed to load states' });
//   }
// });

// // GET /api/location/cities?state=MH
// router.get('/cities', async (req, res) => {
//   try {
//     const state = req.query.state;
//     if (!state) return res.status(400).json({ error: 'state query required' });
//     const list = SAMPLE.cities[state] || [];
//     res.json(list);
//   } catch (err) {
//     res.status(500).json({ error: 'Failed to load cities' });
//   }
// });

// // GET /api/location/pincodes?state=MH&city=pune
// router.get('/pincodes', async (req, res) => {
//   try {
//     const city = req.query.city;
//     if (!city) return res.status(400).json({ error: 'city query required' });
//     const list = SAMPLE.pincodes[city] || [];
//     res.json(list);
//   } catch (err) {
//     res.status(500).json({ error: 'Failed to load pincodes' });
//   }
// });

// module.exports = router;



const express = require('express');
const router = express.Router();
const multer = require('multer');
const xlsx = require('xlsx');

// Temporary in-memory store (replace with DB)
let LOCATION_DATA = {
  states: [],
  cities: {},
  pincodes: {}
};

// Upload middleware
const upload = multer({ storage: multer.memoryStorage() });

// POST /api/location/uploadExcel
router.post('/uploadExcel', upload.single('file'), async (req, res) => {
  try {
    const workbook = xlsx.read(req.file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(sheet);

    // Expected Excel format: State, City, Pincode
    LOCATION_DATA = { states: [], cities: {}, pincodes: {} };

    rows.forEach(row => {
      const stateId = row.StateCode || row.State; // e.g. "MH"
      const stateName = row.StateName || row.State;
      const cityId = row.CityCode || row.City;
      const cityName = row.CityName || row.City;
      const pincode = row.Pincode;

      // Add state
      if (!LOCATION_DATA.states.find(s => s.id === stateId)) {
        LOCATION_DATA.states.push({ id: stateId, name: stateName });
        LOCATION_DATA.cities[stateId] = [];
      }

      // Add city
      if (!LOCATION_DATA.cities[stateId].find(c => c.id === cityId)) {
        LOCATION_DATA.cities[stateId].push({ id: cityId, name: cityName });
        LOCATION_DATA.pincodes[cityId] = [];
      }

      // Add pincode
      if (!LOCATION_DATA.pincodes[cityId].includes(pincode)) {
        LOCATION_DATA.pincodes[cityId].push(pincode);
      }
    });

    res.json({ message: 'Excel uploaded and parsed successfully', states: LOCATION_DATA.states.length });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to parse Excel file' });
  }
});

// GET endpoints now use LOCATION_DATA
router.get('/states', (req, res) => res.json(LOCATION_DATA.states));
router.get('/cities', (req, res) => {
  const state = req.query.state;
  if (!state) return res.status(400).json({ error: 'state query required' });
  res.json(LOCATION_DATA.cities[state] || []);
});
router.get('/pincodes', (req, res) => {
  const city = req.query.city;
  if (!city) return res.status(400).json({ error: 'city query required' });
  res.json(LOCATION_DATA.pincodes[city] || []);
});

module.exports = router;

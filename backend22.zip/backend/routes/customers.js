const express = require("express");
const router = express.Router();
const sql = require("mssql");

// ===============================
// ✅ CREATE CUSTOMER
// ===============================
router.post("/", async (req, res) => {
  try {
    const data = req.body;
    const request = new sql.Request();

    await request
      .input("Name", sql.NVarChar, data.name)
      .input("MobileNo", sql.NVarChar, data.mobileNo)
      .input("AltMobileNo", sql.NVarChar, data.altMobileNo || null)
      .input("Email", sql.NVarChar, data.email || null)
      .input("Address", sql.NVarChar, data.address || null)
      .input("Landmark", sql.NVarChar, data.landmark || null)
      .input("State", sql.NVarChar, data.state || null)
      .input("City", sql.NVarChar, data.city || null)
      .input("Area", sql.NVarChar, data.area || null)
      .input("PinCode", sql.NVarChar, data.pinCode || null)
      .input("PreferredLanguage", sql.NVarChar, data.preferredLanguage || null)
      .input("CustomerCode", sql.NVarChar, data.customerCode || null)
      .input("CustomerType", sql.NVarChar, data.customerType || null)
      .input("CustomerPriority", sql.NVarChar, data.customerPriority || null)
      .input("Active", sql.Bit, data.active ? 1 : 0)
      .query(`
        INSERT INTO Customers
        (Name, MobileNo, AltMobileNo, Email, Address, Landmark, State, City, Area, PinCode,
         PreferredLanguage, CustomerCode, CustomerType, CustomerPriority, Active)
        VALUES
        (@Name, @MobileNo, @AltMobileNo, @Email, @Address, @Landmark, @State, @City, @Area, @PinCode,
         @PreferredLanguage, @CustomerCode, @CustomerType, @CustomerPriority, @Active)
      `);

    return res.json({ success: true, customer: data });

  } catch (err) {
    console.error("Create customer error:", err);
    res.status(500).json({ error: "Customer creation failed" });
  }
});

// ===============================
// ✅ SEARCH CUSTOMER
// ===============================
router.post("/search", async (req, res) => {
  try {
    const { mobileNo, altMobile, productSerialNo, customerCode, name, state, city } = req.body;

    let query = `SELECT TOP 1 * FROM Customers WHERE 1=1`;
    const request = new sql.Request();

    if (mobileNo && mobileNo.trim() !== "") {
      query += " AND MobileNo = @mobileNo";
      request.input("mobileNo", sql.NVarChar, mobileNo.trim());
    }

    if (altMobile && altMobile.trim() !== "") {
      query += " AND AltMobileNo = @altMobile";
      request.input("altMobile", sql.NVarChar, altMobile.trim());
    }

    if (customerCode && customerCode.trim() !== "") {
      query += " AND CustomerCode = @customerCode";
      request.input("customerCode", sql.NVarChar, customerCode.trim());
    }

    if (name && name.trim() !== "") {
      query += " AND Name LIKE @name";
      request.input("name", sql.NVarChar, `%${name.trim()}%`);
    }

    if (state && state.trim() !== "") {
      query += " AND State = @state";
      request.input("state", sql.NVarChar, state.trim());
    }

    if (city && city.trim() !== "") {
      query += " AND City = @city";
      request.input("city", sql.NVarChar, city.trim());
    }

    // PRODUCT JOIN if productSerialNo present
    if (productSerialNo && productSerialNo.trim() !== "") {
      query = `
        SELECT TOP 1 c.*
        FROM Customers c
        JOIN Products p ON c.CustomerCode = p.CustomerCode
        WHERE p.ProductSerialNo = @psn
      `;
      request.input("psn", sql.NVarChar, productSerialNo.trim());
    }

    const result = await request.query(query);

    if (result.recordset.length > 0) {
      return res.json({ exists: true, customer: result.recordset[0] });
    }

    return res.json({ exists: false });

  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ error: "Search failed" });
  }
});



module.exports = router;



// const express = require("express");
// const cors = require("cors");
// const { poolPromise, sql } = require("./db");

// const app = express();
// app.use(cors());
// app.use(express.json());


// app.get("/api/test", async (req, res) => {
//   try {
//     const pool = await poolPromise; // This will now throw if connection failed
//     const result = await pool.request().query("SELECT GETDATE() AS CurrentTime");
//     res.json({ message: "Database Connected Successfully with your front end", data: result.recordset });
//   } catch (err) {
//     console.error("Query failed:", err);
//     res.status(500).json({ 
//       error: err.message,
//       details: "Database connection or query failed" 
//     });
//   }
// });

// const PORT = 5000;
// app.listen(PORT, () => console.log(` Server running on port ${PORT}`));

// wokring code

// const express = require("express");
// const cors = require("cors");
// const app = express();

// app.use(cors());
// app.use(express.json());

// const complaintsRoute = require("./routes/complaints");
// app.use("/api/complaints", complaintsRoute);

// app.listen(5000, () => console.log("Server running on port 5000"));


// new code
// const express = require("express");
// const cors = require("cors");
// const sql = require("mssql");

// const app = express();

// app.use(cors());
// app.use(express.json());

// // DB Config
// const dbConfig = {
//     user: "crm_user",
//     password: "StrongPassword123!",
//     server: "FCL40001748\\SQLEXPRESS",
//     database: "dashboard",
//     options: {
//         encrypt: false,
//         trustServerCertificate: true
//     }
// };

// sql.connect(dbConfig)
//    .then(() => console.log("MSSQL Connected!"))
//    .catch(err => console.log("DB Error:", err));

// // ROUTES
// // const customerRoutes = require("./routes/customers");
// // app.use("/api/customers", customerRoutes);
// app.use("/api/customers", require("./routes/customers"));
// // DEFAULT
// // app.get("/", (req, res) => {
// //     res.send("API is running...");
// // });

// app.listen(5000, () => console.log("Server listening on 5000"));
// app.post("/api/search-customer", async (req, res) => {
//   try {
//     let { mobile, name } = req.body;

//     // Convert empty strings to null
//     if (!mobile || mobile.trim() === "") mobile = null;
//     if (!name || name.trim() === "") name = null;

//     const pool = await sql.connect(dbConfig);

//     const result = await pool
//       .request()
//       .input("mobile", sql.NVarChar, mobile)
//       .input("name", sql.NVarChar, name)
//       .query(`
//         SELECT * FROM Customers
//         WHERE (@mobile IS NULL OR MobileNo = @mobile)
//         AND (@name IS NULL OR Name LIKE '%' + @name + '%')
//       `);

//     res.json({ rows: result.recordset });
//   } catch (err) {
//     console.error("Search error:", err);
//     res.status(500).json({ error: "Search failed" });
//   }
// });


// const express = require("express");
// const cors = require("cors");
// const sql = require("mssql");

// const app = express();

// app.use(cors());
// app.use(express.json());

// // ========== DB CONFIG ==========
// const dbConfig = {
//   user: "crm_user",
//   password: "StrongPassword123!",
//   server: "FCL40001748\\SQLEXPRESS",
//   database: "dashboard",
//   options: {
//     encrypt: false,
//     trustServerCertificate: true,
//   },
// };

// // Database Connection  
// sql.connect(dbConfig)
//   .then(() => console.log("MSSQL Connected!"))
//   .catch((err) => console.log("DB Error:", err));


// // ========== ROUTES ==========

// // Customers
// app.use("/api/customers", require("./routes/customers"));

// // Complaints
// app.use("/api/complaints", require("./routes/complaints"));

// // app.use("/api/products", require("./routes/products"));
// app.use("/api/products", require("./routes/products"));

// // const productRoutes = require('./routes/product');
// // app.use('/api/products', productRoutes);


// // ========== SEARCH CUSTOMER API ==========
// app.post("/api/search-customer", async (req, res) => {
//   try {
//     let { mobile, name } = req.body;

//     if (!mobile || mobile.trim() === "") mobile = null;
//     if (!name || name.trim() === "") name = null;

//     const pool = await sql.connect(dbConfig);

//     const result = await pool
//       .request()
//       .input("mobile", sql.NVarChar, mobile)
//       .input("name", sql.NVarChar, name)
//       .query(`
//         SELECT * FROM Customers
//         WHERE (@mobile IS NULL OR MobileNo = @mobile)
//         AND (@name IS NULL OR Name LIKE '%' + @name + '%')
//       `);

//     res.json({ rows: result.recordset });
//   } catch (err) {
//     console.error("Search error:", err);
//     res.status(500).json({ error: "Search failed" });
//   }
// });


// // ========== START SERVER ==========
// app.listen(5000, () => console.log("Server listening on port 5000"));




const express = require("express");
const cors = require("cors");
const sql = require("mssql");
const app = express();

app.use(cors());
app.use(express.json());

// ==================== DB CONFIG ====================
const dbConfig = {
  user: "crm_user",
  password: "StrongPassword123!",
  server: "FCL40001748\\SQLEXPRESS",
  database: "dashboard",
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};

// Connect database
sql.connect(dbConfig)
  // .then(() => console.log("MSSQL Connected Successfully"))
  .catch((err) => console.log("DB Connection Error:", err));


// ==================== ROUTES ====================
app.use("/api/customers", require("./routes/customers"));
app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/products", require("./routes/products"));
app.use("/api/servicecenter", require("./routes/servicecenter"));
// app.use("/api/complaints", require("./routes/complaints"));
app.use("/api/auto", require("./routes/autoAssign"));
app.use("/api/location", require("./routes/location"));

// Backwards-compatible top-level route used by some front-end code
const autoAssignModule = require("./routes/autoAssign");
app.post("/api/assign-service-centre", async (req, res) => {
  try {
    const { pincode, customerAddress, lat, lon } = req.body;
    const { bestCenter, minDistance } = await autoAssignModule.findNearestCenter({ pincode, customerAddress, lat, lon });
    const isOutCity = Number(minDistance) > 20;
    return res.json({ serviceCenter: bestCenter, distance: `${Number(minDistance).toFixed(2)} km`, outCity: isOutCity });
  } catch (err) {
    console.error("Top-level AutoAssign Error:", err && err.message ? err.message : err);
    res.status(500).json({ error: err.message || String(err) });
  }
});



// example products route (adjust to your existing logic)
// app.use("/api/products", require("./routes/products"));

// ==================== START SERVER ====================
app.listen(5000, () => console.log("Server running on port 5000"));

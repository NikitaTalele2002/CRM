import React, { useState } from "react";
import { createComplaint } from "../api";

export default function ComplaintForm({ customer }) {
  const [form, setForm] = useState({
    callId: "",
    serialNo: "",
    complaintId: "",
    complaintDetails: ""
  });

  function update(field, value) {
    setForm({ ...form, [field]: value });
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (!customer) {
      alert("No customer selected. Search customer first.");
      return;
    }

    const payload = {
      CallId: form.callId,
      SerialNo: form.serialNo,
      ComplaintId: form.complaintId,
      ComplaintDetails: form.complaintDetails,
      CustomerCode: customer.CustomerCode,
      Name: customer.Name,
      MobileNo: customer.MobileNo,
    };

    const res = await createComplaint(payload);

    alert("Complaint registered successfully!");
  }

  return (
    <form onSubmit={handleSubmit} style={{ border: "1px solid #ddd", padding: 12 }}>
      <h3>Create Complaint</h3>

      <input placeholder="Call ID"
        onChange={(e) => update("callId", e.target.value)} required/>

      <input placeholder="Serial No"
        onChange={(e) => update("serialNo", e.target.value)} required />

      <input placeholder="Complaint ID"
        onChange={(e) => update("complaintId", e.target.value)} required />

      <textarea placeholder="Complaint Details"
        onChange={(e) => update("complaintDetails", e.target.value)} required/>

      <button type="submit" style={{ marginTop: 10 }}>
        Register Complaint
      </button>
    </form>
  );
}


// src/pages/call_centre/navbar.jsx
import React from "react";
import { NavLink } from "react-router-dom";

export default function CC_Navbar({ setActiveModule, activeModule }) {
  const modules = [
    { name: "Dashboard", to: "/call-centre/dashboardCS" },
    { name: "Complaint Registration", to: "/call-centre/register" },
    { name: "Call Search", to: "/call-centre/search" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-blue-500 text-black p-4 flex space-x-4 shadow">
      {modules.map((m) => (
        <NavLink
          key={m.to}
          to={m.to}
          className={({ isActive }) =>
            `px-4 py-2 rounded ${isActive ? "bg-white text-blue-500" : "hover:bg-blue-700 text-white"}`
          }
>
          {m.name}
        </NavLink>
      ))}
    </nav>
  );
}



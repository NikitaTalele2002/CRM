// import React, { useEffect, useState } from "react";
// import { getProducts } from "../api";
// import { useNavigate } from "react-router-dom";

// export default function ShowProducts() {
//   const [products, setProducts] = useState([]);
//   const navigate = useNavigate();
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     loadProducts();
//   }, []);

//   async function loadProducts() {
//     try {
//       const data = await getProducts();
//       setProducts(data); 
//     } catch (err) {
//       console.error("Product load error", err);
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <div style={{ padding: 20 }}>
//       {/* <h2>All Products</h2>

//       {loading && <p>Loading...</p>}

//       {!loading && products.length === 0 && (
//         <div>
//           <p>No products found.</p>
//           <button
//             style={{ padding: "8px 12px", marginTop: 10 }}
//             onClick={() => navigate("/call-centre/register")}>
//             Register Product
//           </button>
//         </div>
//       )} */}

//       <h2>All Products</h2>

// {/* Always show button */}
// {/* <button className="btn btn-primary mb-3">Register Product</button> */}

// {/* Products List */}

// {products.length === 0 ? (
//   <p>No products found.</p>
// ) : (
//   <ul>
//     {products.map((p) => (
//       <li key={p.Id}>
//         {p.ProductName} - ₹{p.Price}
//       </li>
//     ))}
//   </ul>
// )
// } 
// <button style={{ padding: "8px 12px", marginBottom: 10 }} onClick={() => navigate("/call-centre/register")}>
//             Register Product
//           </button>

// {/* 
//       {products.length > 0 && (
//         <div style={{ marginTop: 20 }}>
//           {products.map((p) => (
//             <div
//               key={p.Id}
//               style={{
//                 border: "1px solid #ccc",
//                 padding: 12,
//                 marginBottom: 10,
//                 borderRadius: 6,
//               }}>
//               <h3>{p.ProductName}</h3>
//               <p>Price: ₹{p.Price}</p>
//             </div>
//           ))}
//         </div>
//       )} */}
//     </div>
//   );
// }




// import React, { useEffect, useState } from "react";
// import { getProducts } from "../api";
// import { useNavigate } from "react-router-dom";

// export default function ShowProducts() {
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigate = useNavigate();

//   useEffect(() => {
//     loadProducts();
//   }, []);

//   async function loadProducts() {
//     try {
//       const data = await getProducts();
//       setProducts(data);
//     } catch (err) {
//       console.error("Product load error", err);
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>All Products</h2>

//       <button
//         style={{ padding: "8px 12px", marginBottom: 20 }}
//         onClick={() => navigate("/call-centre/register")}
//       >
//         Register Product
//       </button>

//       {loading && <p>Loading...</p>}

//       {!loading && products.length === 0 && <p>No products found.</p>}

//       {!loading && products.length > 0 && (
//         <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
//           {products.map((p) => (
//             <div
//               key={p.Id}
//               style={{
//                 border: "1px solid #ccc",
//                 padding: 12,
//                 borderRadius: 6,
//               }}
//             >
//               <h3>{p.Product}</h3>
//               <p><strong>Brand:</strong> {p.Brand}</p>
//               <p><strong>Product Group:</strong> {p.ProductGroup}</p>
//               <p><strong>Model:</strong> {p.Model}</p>
//               <p><strong>Description:</strong> {p.ModelDescription}</p>
//               <p><strong>Serial No:</strong> {p.ProductSerialNo}</p>
//               <p><strong>Purchase Date:</strong> {p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "N/A"}</p>
//               <p><strong>Dealer:</strong> {p.DealerName}</p>
//               <p><strong>Warranty Status:</strong> {p.WarrantyStatus}</p>
//               <p><strong>Previous Calls:</strong> {p.PreviousCalls}</p>
//               <p><strong>Call Status:</strong> {p.CallStatus}</p>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }


// import React, { useEffect, useState } from "react";
// import { getProducts } from "../api";
// import { useNavigate } from "react-router-dom";

// export default function ShowProducts() {
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const navigate = useNavigate();

//   useEffect(() => {
//     loadProducts();
//   }, []);

//   async function loadProducts() {
//     try {
//       const data = await getProducts();
//       setProducts(data);
//     } catch (err) {
//       console.error("Error loading products:", err);
//     } finally {
//       setLoading(false);
//     }
//   }

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>All Products</h2>

//       <button
//         style={{ padding: "8px 12px", marginBottom: 10 }}
//         onClick={() => navigate("/call-centre/register")}
//       >
//         Register Product
//       </button>

//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found.</p>
//       ) : (
//         <ul>
//           {products.map((p) => (
//             <li key={p.ProductId} style={{ marginBottom: 10 }}>
//               <strong>{p.Product}</strong> ({p.Model}) - ₹{p.Price || "-"} <br />
//               Brand: {p.Brand}, Group: {p.ProductGroup} <br />
//               Serial No: {p.ProductSerialNo}, Warranty: {p.WarrantyStatus} <br />
//               Purchased: {p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "-"} <br />
//               Dealer: {p.DealerName} <br />
//               Previous Calls: {p.PreviousCalls}, Status: {p.CallStatus} <br />
//               Customer: {p.CustomerName || "-"} (Phone: {p.CustomerPhone || "-"})
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// }


// import React, { useEffect, useState } from "react";
// import { getProducts } from "../api";
// import { useNavigate,useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // Get mobile number from navigation state
//   const customerPhone = location.state?.mobile;

//   useEffect(() => {
//     if (customerPhone) {
//       fetchProductsByPhone(customerPhone);
//     } else {
//       setLoading(false);
//     }
//   }, [customerPhone]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(data);
//     } catch (err) {
//       console.error("Error fetching products:", err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   if (!customerPhone) return <p>Please select a customer to view products.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Products for Customer: {customerPhone}</h2>

//       <button
//         style={{ padding: "8px 12px", marginBottom: 10 }}
//         onClick={() => navigate("/call-centre/register")} >Register Product
//       </button>

//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found for this customer.</p>
//       ) : (
//         <ul>
//           {products.map((p) => (
//             <li key={p.Id} style={{ marginBottom: 10 }}>
//               <strong>{p.Product}</strong> ({p.Model}) <br />
//               Brand: {p.Brand}, Group: {p.ProductGroup} <br />
//               Serial No: {p.ProductSerialNo}, Warranty: {p.WarrantyStatus} <br />
//               Purchased: {p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "-"} <br />
//               Dealer: {p.DealerName} <br />
//               Previous Calls: {p.PreviousCalls}, Status: {p.CallStatus}
//             </li>
//           ))}
//         </ul>
//       )}
//     </div>
//   );
// }


// import React, { useEffect, useState } from "react";
// import { useNavigate, useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   const customerPhone = location.state?.mobile;

//   useEffect(() => {
//     if (customerPhone) fetchProductsByPhone(customerPhone);
//     else setLoading(false);
//   }, [customerPhone]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(Array.isArray(data) ? data : []);
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   const handleViewDetails = (product) => {
//     if (!product.customer) {
//       alert("Customer information not found for this product.");
//       return;
//     }
//     setSelectedProduct(product);
//   };

//   if (!customerPhone) return <p>Please select a customer to view products.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Products for Customer: {customerPhone}</h2>

//       <button
//         style={{ padding: "8px 12px", marginBottom: 10 }}
//         onClick={() => navigate("/call-centre/register")}
//       >
//         Register Product
//       </button>

//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found for this customer.</p>
//       ) : (
//         <table style={{ borderCollapse: "collapse", width: "100%" }}>
//           <thead>
//             <tr>
//               <th style={{ border: "1px solid black", padding: 8 }}>Product</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Brand</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Group</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Model</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Serial No</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Warranty</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Purchase Date</th>
//               <th style={{ border: "1px solid black", padding: 8 }}>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {products.map((p) => (
//               <tr key={p.Id}>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.Product}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.Brand}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.ProductGroup}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.Model}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.ProductSerialNo}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>{p.WarrantyStatus}</td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>
//                   {p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "-"}
//                 </td>
//                 <td style={{ border: "1px solid black", padding: 8 }}>
//                   <button onClick={() => handleViewDetails(p)}>View Details</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       {selectedProduct && (
//         <div style={{ marginTop: 30 }}>
//           <h3>Customer Information</h3>
//           <form style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
//             {Object.entries(selectedProduct.customer).map(([key, value]) => (
//               <input key={key} value={value || ""} readOnly placeholder={key} />
//             ))}
//           </form>

//           <h3 style={{ marginTop: 20 }}>Product Information</h3>
//           <form style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
//             {["ProductGroup", "Brand", "Product", "Model", "PurchaseDate", "ProductSerialNo", "DealerName", "WarrantyStatus", "PreviousCalls", "CallStatus"].map(
//               (field) => (
//                 <input
//                   key={field}
//                   value={
//                     field === "PurchaseDate" && selectedProduct[field]
//                       ? new Date(selectedProduct[field]).toLocaleDateString()
//                       : selectedProduct[field] || ""
//                   }
//                   readOnly
//                   placeholder={field}
//                 />
//               )
//             )}
//           </form>
//         </div>
//       )}
//     </div>
//   );
// }


// //still now displaying

// import React, { useEffect, useState } from "react";
// import { useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const customer = location.state?.customer;
//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     if (customer) fetchProductsByPhone(customer.MobileNo);
//   }, [customer]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(data || []);
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   if (!customer) return <p>Please select a customer first.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Customer & Product Details</h2>

//       {/* Customer Form */}
//       <h3>Customer Information</h3>
//       <form style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//         <label>Name:</label>
//         <input value={customer.Name || ""} readOnly /><br />
//         <label>Mobile No:</label>
//         <input value={customer.MobileNo || ""} readOnly /><br />
//         <label>Email:</label>
//         <input value={customer.Email || ""} readOnly /><br />
//         <label>Address:</label>
//         <input value={customer.Address || ""} readOnly /><br />
//         <label>City:</label>
//         <input value={customer.City || ""} readOnly /><br />
//         <label>State:</label>
//         <input value={customer.State || ""} readOnly /><br />
//         <label>Pin Code:</label>
//         <input value={customer.PinCode || ""} readOnly /><br />
//         <label>Customer Type:</label>
//         <input value={customer.CustomerType || ""} readOnly /><br />
//         <label>Active:</label>
//         <input value={customer.Active ? "Yes" : "No"} readOnly /><br />
//       </form>

//       {/* Products */}
//       <h3>Products for this Customer</h3>
//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products registered for this customer.</p>
//       ) : (
//         products.map((p) => (
//           <form key={p.Id} style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//             <label>Product Group:</label>
//             <input value={p.ProductGroup} readOnly /><br />
//             <label>Brand:</label>
//             <input value={p.Brand} readOnly /><br />
//             <label>Product:</label>
//             <input value={p.Product} readOnly /><br />
//             <label>Model:</label>
//             <input value={p.Model} readOnly /><br />
//             <label>Serial No:</label>
//             <input value={p.ProductSerialNo} readOnly /><br />
//             <label>Purchase Date:</label>
//             <input value={p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : ""} readOnly /><br />
//             <label>Dealer Name:</label>
//             <input value={p.DealerName} readOnly /><br />
//             <label>Warranty Status:</label>
//             <input value={p.WarrantyStatus} readOnly /><br />
//             <label>Previous Calls:</label>
//             <input value={p.PreviousCalls} readOnly /><br />
//             <label>Call Status:</label>
//             <input value={p.CallStatus} readOnly /><br />
//           </form>
//         ))
//       )}
//     </div>
//   );
// }


// import React, { useEffect, useState } from "react";
// import { useNavigate, useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const navigate = useNavigate();
//   const customerPhone = location.state?.mobile;

//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   useEffect(() => {
//     if (customerPhone) fetchProductsByPhone(customerPhone);
//     else setLoading(false);
//   }, [customerPhone]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(data);
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   const handleViewDetails = (product) => setSelectedProduct(product);

//   if (!customerPhone) return <p>Please select a customer to view products.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Products for Customer: {customerPhone}</h2>
//       <button style={{ padding: "8px 12px", marginBottom: 10 }} onClick={() => navigate("/call-centre/register")}>
//         Register Product
//       </button>

//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found for this customer.</p>
//       ) : (
//         <table className="border-collapse border border-gray-400 w-full mb-6">
//           <thead>
//             <tr>
//               <th className="border p-2">Product</th>
//               <th className="border p-2">Brand</th>
//               <th className="border p-2">Group</th>
//               <th className="border p-2">Serial No</th>
//               <th className="border p-2">Warranty</th>
//               <th className="border p-2">Purchase Date</th>
//               <th className="border p-2">Dealer</th>
//               <th className="border p-2">Previous Calls</th>
//               <th className="border p-2">Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {products.map((p) => (
//               <tr key={p.Id}>
//                 <td className="border p-2">{p.Product}</td>
//                 <td className="border p-2">{p.Brand}</td>
//                 <td className="border p-2">{p.ProductGroup}</td>
//                 <td className="border p-2">{p.ProductSerialNo}</td>
//                 <td className="border p-2">{p.WarrantyStatus}</td>
//                 <td className="border p-2">{p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "-"}</td>
//                 <td className="border p-2">{p.DealerName}</td>
//                 <td className="border p-2">{p.PreviousCalls}</td>
//                 <td className="border p-2">
//                   <button onClick={() => handleViewDetails(p)}>View Details</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       {selectedProduct && (
//         <div>
//           <h2>Customer Information</h2>
//           <form style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//          <label>Name:</label>
//         <input value={customer.Name || ""} readOnly /><br />
//         <label>Mobile No:</label>
//          <input value={customer.MobileNo || ""} readOnly /><br />
//          <label>Email:</label>
//         <input value={customer.Email || ""} readOnly /><br />
//         <label>Address:</label>
//          <input value={customer.Address || ""} readOnly /><br />
//          <label>City:</label>
//          <input value={customer.City || ""} readOnly /><br />
//          <label>State:</label>
//          <input value={customer.State || ""} readOnly /><br />
//          <label>Pin Code:</label>
//          <input value={customer.PinCode || ""} readOnly /><br />
//          <label>Customer Type:</label>
//          <input value={customer.CustomerType || ""} readOnly /><br />
//         <label>Active:</label>
//          <input value={customer.Active ? "Yes" : "No"} readOnly /><br />
//        </form>

//           <h2 style={{ marginTop: 20 }}>Product Information</h2>
//           <form className="border-2" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
//             {[
//               "ProductGroup",
//               "Brand",
//               "Product",
//               "Model",
//               "ModelDescription",
//               "PurchaseDate",
//               "ProductSerialNo",
//               "DealerName",
//               "WarrantyStatus",
//               "PreviousCalls",
//               "CallStatus",
//             ].map((field) => (
//               <div key={field} style={{ display: "flex", flexDirection: "column" }}>
//                 <label>{field.replace(/([A-Z])/g, " $1")}</label>
//                 <input
//                   value={
//                     field === "PurchaseDate" && selectedProduct.PurchaseDate
//                       ? new Date(selectedProduct.PurchaseDate).toLocaleDateString()
//                       : selectedProduct[field] || ""
//                   }
//                   readOnly
//                   style={{ padding: 6 }}
//                 />
//               </div>
//             ))}
//           </form>
//         </div>
//       )}
//     </div>
//   );
// }


// this is working code without pincode


// import React, { useEffect, useState } from "react";
// import { useNavigate, useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const navigate = useNavigate();

//   // Get the customer object from location state


//   const customer = location.state?.customer;

//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   useEffect(() => {
//     if (customer?.MobileNo) fetchProductsByPhone(customer.MobileNo);
//     else setLoading(false);
//   }, [customer]);

//   async function fetchProductsByPhone(phone) {
//     setLoading(true);
//     try {
//       const res = await fetch(`http://localhost:5000/api/products/by-phone/${phone}`);
//       if (!res.ok) throw new Error("Failed to fetch products");
//       const data = await res.json();
//       setProducts(Array.isArray(data) ? data : []); // Always ensure array
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   const handleViewDetails = (product) => setSelectedProduct(product);

//   if (!customer) return <p>Please select a customer to view products.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Products for Customer: {customer.Name}</h2> 
//       <button
//         style={{ padding: "8px 12px", marginBottom: 10 }}
//         onClick={() => navigate("/call-centre/register")}
//       >
//         Register Product
//       </button>

//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found for this customer.</p>
//       ) : (
//         <table className="border-collapse border border-gray-400 w-full mb-6">
//           <thead>
//             <tr>
//               <th>Product</th>
//               <th>Brand</th>
//               <th>Group</th>
//               <th>Serial No</th>
//               <th>Warranty</th>
//               <th>Purchase Date</th>
//               <th>Dealer</th>
//               <th>Previous Calls</th>
//               <th>Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {products.map((p) => (
//               <tr key={p.Id}>
//                 <td>{p.Product}</td>
//                 <td>{p.Brand}</td>
//                 <td>{p.ProductGroup}</td>
//                 <td>{p.ProductSerialNo}</td>
//                 <td>{p.WarrantyStatus}</td>
//                 <td>{p.PurchaseDate ? new Date(p.PurchaseDate).toLocaleDateString() : "-"}</td>
//                 <td>{p.DealerName}</td>
//                 <td>{p.PreviousCalls}</td>
//                 <td>
//                   <button onClick={() => handleViewDetails(p)}>View Details</button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       {selectedProduct && (
//         <div>


// {/* Customer Information */}
//           <h2>Customer Information</h2>
//           <form style={{ border: "1px solid #ccc", padding: 12, marginBottom: 20 }}>
//             {[
//               { label: "Name", value: customer.Name },
//               { label: "Mobile No", value: customer.MobileNo },
//               { label: "Email", value: customer.Email },
//               { label: "Address", value: customer.Address },
//               { label: "City", value: customer.City },
//               { label: "State", value: customer.State },
//               { label: "Pin Code", value: customer.PinCode },
//               { label: "Customer Type", value: customer.CustomerType },
//               { label: "Active", value: customer.Active ? "Yes" : "No" },
//             ].map((field) => (
//               <div key={field.label} style={{ marginBottom: 6 }}>
//                 <label>{field.label}:</label>
//                 <input value={field.value || ""} readOnly style={{ width: "100%" }} />
//               </div>
//             ))}
//           </form>




// {/*  Product Information  */}
//           <h2>Product Information</h2>
//           <form
//             style={{
//               border: "1px solid #ccc",
//               padding: 12,
//               display: "grid",
//               gridTemplateColumns: "1fr 1fr",
//               gap: 10,
//             }} >
//             {[
//               "ProductGroup",
//               "Brand",
//               "Product",
//               "Model",
//               "ModelDescription",
//               "PurchaseDate",
//               "ProductSerialNo",
//               "DealerName",
//               "WarrantyStatus",
//               "PreviousCalls",
//               "CallStatus",
//             ].map((field) => (
//               <div key={field} style={{ display: "flex", flexDirection: "column" }}>
//                 <label>{field.replace(/([A-Z])/g, " $1")}</label>
//                 <input
//                   value={
//                     field === "PurchaseDate" && selectedProduct.PurchaseDate
//                       ? new Date(selectedProduct.PurchaseDate).toLocaleDateString()
//                       : selectedProduct[field] || ""
//                   }
//                   readOnly
//                   style={{ padding: 6 }}
//                 />
//               </div>
//             ))}
//           </form>
//         </div>
//       )}
//     </div>
//   );
// }


// with only call Information frontend part


// import React, { useEffect, useState } from "react";
// import { useNavigate, useLocation } from "react-router-dom";

// export default function ShowProducts() {
//   const location = useLocation();
//   const navigate = useNavigate();

//   const customer = location.state?.customer;

//   const [products, setProducts] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   // -------------------------------
//   // CALL INFORMATION STATE
//   // -------------------------------
//   const [callInfo, setCallInfo] = useState({
//     CallType: "",
//     AppointmentDate: "",
//     AppointmentTime: "",
//     CallerType: "Customer",
//     CallerMobile: "",
//     CustomerRemarks: "",
//     DealerName: "",
//     Remarks: "",
//     CallSource: "Voice",
//     ContactPerson: "",
//     ContactPersonMobile: "",
//     Qty: 1,

//     AssignedCenter: "",
//     Distance: "",
//     OutCity: false,
//   });

//   const [assigning, setAssigning] = useState(false);

//   // -------------------------------
//   // LOAD PRODUCTS
//   // -------------------------------
//   useEffect(() => {
//     if (customer?.MobileNo) {
//       fetchProductsByPhone(customer.MobileNo);
//     } else {
//       setLoading(false);
//     }
//   }, [customer]);

//   async function fetchProductsByPhone(phone) {
//     try {
//       setLoading(true);
//       const res = await fetch(
//         `http://localhost:5000/api/products/by-phone/${phone}`
//       );

//       const data = await res.json();
//       setProducts(Array.isArray(data) ? data : []);
//     } catch (err) {
//       console.error(err);
//       setProducts([]);
//     } finally {
//       setLoading(false);
//     }
//   }

//   const handleViewDetails = (product) => {
//     setSelectedProduct(product);
//     setCallInfo((prev) => ({
//       ...prev,
//       AssignedCenter: "",
//       Distance: "",
//       OutCity: false,
//     }));
//   };

//   // -------------------------------
//   // ASSIGN NEAREST CENTER
//   // -------------------------------
//   async function assignNearestCenter() {
//     if (!customer) return;

//     try {
//       setAssigning(true);

//       // Fetch authoritative customer record from backend (by mobile)
//       const custRes = await fetch("http://localhost:5000/api/customers/search", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ mobileNo: customer.MobileNo }),
//       });

//       const custData = await custRes.json();

//       if (!custRes.ok || !custData.exists) {
//         const errMsg = (custData && custData.error) || "Failed to load customer data";
//         alert(errMsg);
//         return;
//       }

//       const authoritativeCustomer = custData.customer;

//       const payload = {
//         pincode: authoritativeCustomer.PinCode || authoritativeCustomer.Pin || "",
//         customerAddress:
//           [authoritativeCustomer.Address, authoritativeCustomer.City, authoritativeCustomer.State, authoritativeCustomer.PinCode]
//             .filter(Boolean)
//             .join(", "),
//       };

//       const res = await fetch("http://localhost:5000/api/auto/assign", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(payload),
//       });

//       const data = await res.json();

//       if (data.error) {
//         alert(data.error || "Assignment failed");
//         return;
//       }

//       setCallInfo((prev) => ({
//         ...prev,
//         AssignedCenter: data.serviceCenter.CenterName,
//         Distance: data.distance,
//         OutCity: data.outCity,
//       }));

//       alert(`Assigned to ${data.serviceCenter.CenterName}`);
//     } catch (err) {
//       console.error(err);
//       alert("Assignment failed");
//     } finally {
//       setAssigning(false);
//     }
//   }

//   // -------------------------------
//   // SUBMIT COMPLAINT
//   // -------------------------------
//   async function submitComplaint() {
//     if (!selectedProduct) return alert("Select a product first!");
//     if (!callInfo.CallType) return alert("Select Call Type");
//     if (!callInfo.CallerMobile) return alert("Enter Caller Mobile");
//     if (!callInfo.CustomerRemarks) return alert("Enter Customer Remarks");

//     const payload = {
//       customer,
//       product: selectedProduct,
//       callInfo,
//     };

//     const res = await fetch(
//       "http://localhost:5000/api/complaints/register",
//       {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(payload),
//       }
//     );

//     const data = await res.json();

//     if (data.success) {
//       alert("Complaint Registered Successfully!");
//       navigate("/call-centre/dashboard");
//     } else {
//       alert("Error: " + data.error);
//     }
//   }

//   // -------------------------------
//   // UI START
//   // -------------------------------
//   if (!customer) return <p>Please select a customer first.</p>;

//   return (
//     <div style={{ padding: 20 }}>
//       <h2>Products for Customer: {customer.Name}</h2>

//       <button
//         style={{ padding: "8px 12px", marginBottom: 10 }}
//         onClick={() => navigate("/call-centre/register")}
//       >
//         Register Product
//       </button>
//       {loading ? (
//         <p>Loading...</p>
//       ) : products.length === 0 ? (
//         <p>No products found.</p>
//       ) : (
//         <table className="border-collapse border border-gray-400 w-full mb-6">
//           <thead>
//             <tr>
//               <th>Product</th>
//               <th>Brand</th>
//               <th>Group</th>
//               <th>Serial No</th>
//               <th>Warranty</th>
//               <th>Purchase</th>
//               <th>Dealer</th>
//               <th>Prev Calls</th>
//               <th>Action</th>
//             </tr>
//           </thead>
//           <tbody>
//             {products.map((p) => (
//               <tr key={p.Id}>
//                 <td>{p.Product}</td>
//                 <td>{p.Brand}</td>
//                 <td>{p.ProductGroup}</td>
//                 <td>{p.ProductSerialNo}</td>
//                 <td>{p.WarrantyStatus}</td>
//                 <td>
//                   {p.PurchaseDate
//                     ? new Date(p.PurchaseDate).toLocaleDateString()
//                     : "-"}
//                 </td>
//                 <td>{p.DealerName}</td>
//                 <td>{p.PreviousCalls}</td>
//                 <td>
//                   <button onClick={() => handleViewDetails(p)}>
//                     View Details
//                   </button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       {/* ---------------- PRODUCT SELECTED ---------------- */}
//       {selectedProduct && (
//         <>
//           <h2>Customer Information</h2>
//           <form style={{ border: "1px solid #ccc", padding: 12 }}>
//             {[
//               { label: "Name", value: customer.Name },
//               { label: "Mobile", value: customer.MobileNo },
//               { label: "Email", value: customer.Email },
//               { label: "Address", value: customer.Address },
//               { label: "City", value: customer.City },
//               { label: "State", value: customer.State },
//               { label: "Pincode", value: customer.PinCode },
//             ].map((f) => (
//               <div key={f.label} style={{ marginBottom: 6 }}>
//                 <label>{f.label}</label>
//                 <input value={f.value || ""} readOnly />
//               </div>
//             ))}
//           </form>

//           <h2 style={{ marginTop: 20 }}>Product Information</h2>
//           <form
//             style={{
//               border: "1px solid #ccc",
//               padding: 12,
//               display: "grid",
//               gridTemplateColumns: "1fr 1fr",
//               gap: 10,
//             }}
//           >
//             {[
//               "ProductGroup",
//               "Brand",
//               "Product",
//               "Model",
//               "ModelDescription",
//               "PurchaseDate",
//               "ProductSerialNo",
//               "DealerName",
//               "WarrantyStatus",
//               "PreviousCalls",
//             ].map((field) => (
//               <div key={field}>
//                 <label>{field}</label>
//                 <input
//                   value={
//                     field === "PurchaseDate"
//                       ? selectedProduct.PurchaseDate
//                         ? new Date(
//                             selectedProduct.PurchaseDate
//                           ).toLocaleDateString()
//                         : "-"
//                       : selectedProduct[field] || ""
//                   }
//                   readOnly
//                 />
//               </div>
//             ))}
//           </form>

//           {/* ---------------- CALL INFORMATION ---------------- */}
//           <h2 style={{ marginTop: 20 }}>Call Information</h2>

//           <form
//             style={{
//               border: "1px solid #aaa",
//               padding: 15,
//               display: "grid",
//               gridTemplateColumns: "1fr 1fr",
//               gap: 10,
//             }}  >
//             <div>
//               <label>Call Type *</label>
//               <select
//                 value={callInfo.CallType}
//                 onChange={(e) =>
//                   setCallInfo({ ...callInfo, CallType: e.target.value })
//                 }>
//                 <option value="">Select</option>
//                 <option value="Installation">Installation</option>
//                 <option value="Service">Service</option>
//                 <option value="Complaint">Complaint</option>
//               </select>
//             </div>

//             <div>
//               <label>Appointment Date</label>
//               <input
//                 type="date"
//                 value={callInfo.AppointmentDate}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     AppointmentDate: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Appointment Time</label>
//               <input
//                 type="time"
//                 value={callInfo.AppointmentTime}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     AppointmentTime: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Caller Type</label>
//               <select
//                 value={callInfo.CallerType}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     CallerType: e.target.value,
//                   })
//                 }>
//                 <option>Customer</option>
//                 <option>Service Center</option>
//               </select>
//             </div>

//             <div>
//               <label>Caller Mobile *</label>
//               <input
//                 value={callInfo.CallerMobile}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     CallerMobile: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div style={{ gridColumn: "span 2" }}>
//               <label>Customer Remarks *</label>
//               <textarea
//                 value={callInfo.CustomerRemarks}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     CustomerRemarks: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Dealer Name</label>
//               <input
//                 value={callInfo.DealerName}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     DealerName: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Remarks</label>
//               <input
//                 value={callInfo.Remarks}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     Remarks: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Call Source *</label>
//               <select
//                 value={callInfo.CallSource}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     CallSource: e.target.value,
//                   })
//                 }
//               >
//                 <option>Voice</option>
//                 <option>WhatsApp</option>
//                 <option>Online</option>
//               </select>
//             </div>

//             <div>
//               <label>Contact Person</label>
//               <input
//                 value={callInfo.ContactPerson}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     ContactPerson: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Contact Person Mobile</label>
//               <input
//                 value={callInfo.ContactPersonMobile}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     ContactPersonMobile: e.target.value,
//                   })
//                 }
//               />
//             </div>

//             <div>
//               <label>Qty *</label>
//               <input
//                 type="number"
//                 value={callInfo.Qty}
//                 onChange={(e) =>
//                   setCallInfo({
//                     ...callInfo,
//                     Qty: Number(e.target.value),
//                   })
//                 }
//               />
//             </div>

//             <div style={{ gridColumn: "span 2" }}>
//               <button
//                 type="button"
//                 disabled={assigning}
//                 onClick={assignNearestCenter}
//               >
//                 {assigning
//                   ? "Assigning..."
//                   : "Assign Nearest Service Center"}
//               </button>
//             </div>

//             {callInfo.AssignedCenter && (
//               <>
//                 <div>
//                   <label>Assigned Center</label>
//                   <input value={callInfo.AssignedCenter} readOnly />
//                 </div>

//                 <div>
//                   <label>Distance</label>
//                   <input value={callInfo.Distance} readOnly />
//                 </div>

//                 {callInfo.OutCity && (
//                   <div style={{ color: "red", fontWeight: "bold" }}>
//                     OUT CITY CALL
//                   </div>
//                 )}
//               </>
//             )}
//           </form>

//           <button
//             style={{
//               marginTop: 20,
//               padding: "10px 15px",
//               background: "green",
//               color: "white",
//             }}
//             onClick={submitComplaint}
//           >
//             Submit Complaint
//           </button>
//         </>
//       )}
//     </div>
//   );
// }



import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

export default function ShowProducts() {
  const location = useLocation();
  const navigate = useNavigate();

  const customer = location.state?.customer;

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);

  // -------------------------------
  // CALL INFORMATION STATE
  // -------------------------------
  const [callInfo, setCallInfo] = useState({
    CallType: "",
    AppointmentDate: "",
    AppointmentTime: "",
    CallerType: "Customer",
    CallerMobile: "",
    CustomerRemarks: "",
    DealerName: "",
    Remarks: "",
    CallSource: "Voice",
    ContactPerson: "",
    ContactPersonMobile: "",
    Qty: 1,

    AssignedCenter: "",
    Distance: "",
    OutCity: false,
  });

  const [assigning, setAssigning] = useState(false);

  // -------------------------------
  // LOAD PRODUCTS
  // -------------------------------
  useEffect(() => {
    if (customer?.MobileNo) {
      fetchProductsByPhone(customer.MobileNo);
    } else {
      setLoading(false);
    }
  }, [customer]);

  async function fetchProductsByPhone(phone) {
    try {
      setLoading(true);
      const res = await fetch(
        `http://localhost:5000/api/products/by-phone/${phone}`
      );

      const data = await res.json();
      setProducts(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      setProducts([]);
    } finally {
      setLoading(false);
    }
  }

  const handleViewDetails = (product) => {
    setSelectedProduct(product);
    setCallInfo((prev) => ({
      ...prev,
      AssignedCenter: "",
      Distance: "",
      OutCity: false,
    }));
  };

 // -------------------------------
// ASSIGN NEAREST CENTER
// -------------------------------
async function assignNearestCenter() {
  if (!customer) return;

  try {
    setAssigning(true);

    // Fetch authoritative customer record from backend (by mobile)
    const custRes = await fetch("http://localhost:5000/api/customers/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mobileNo: customer.MobileNo }),
    });

    const custData = await custRes.json();

    if (!custRes.ok || !custData.exists) {
      const errMsg = (custData && custData.error) || "Failed to load customer data";
      alert(errMsg);
      return;
    }

    const authoritativeCustomer = custData.customer;

    const payload = {
      pincode: authoritativeCustomer.PinCode || authoritativeCustomer.Pin || "",
      customerAddress:
        [authoritativeCustomer.Address, authoritativeCustomer.City, authoritativeCustomer.State, authoritativeCustomer.PinCode]
          .filter(Boolean)
          .join(", "),
      lat: authoritativeCustomer.Latitude || null,
      lon: authoritativeCustomer.Longitude || null,
    };

    // CALL BACKEND
    const res = await fetch("http://localhost:5000/api/assign-service-centre", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();

    if (data.error) {
      alert(data.error || "Assignment failed");
      return;
    }

    setCallInfo((prev) => ({
      ...prev,
      AssignedCenter: data.serviceCenter.CenterName,
      Distance: data.distance,
      OutCity: data.outCity,
    }));

    alert(`Assigned to ${data.serviceCenter.CenterName}`);
  } catch (err) {
    console.error(err);
    alert("Assignment failed");
  } finally {
    setAssigning(false);
  }
}
const geoCache = new Map();

async function geocodeAddress(query) {
  if (!query) return null;
  if (geoCache.has(query)) return geoCache.get(query);

  const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`;
  try {
    const res = await fetch(url, { headers: { "User-Agent": "CRM-System" } });
    const data = await res.json();
    if (!data || !data.length) return null;

    const loc = { lat: Number(data[0].lat), lon: Number(data[0].lon) };
    geoCache.set(query, loc);
    return loc;
  } catch (err) {
    console.log("Geocode error:", err);
    return null;
  }
}

async function getRoadDistance(lat1, lon1, lat2, lon2) {
  try {
    const url = `http://router.project-osrm.org/route/v1/driving/${lon1},${lat1};${lon2},${lat2}?overview=false`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.routes && data.routes[0]) return data.routes[0].distance / 1000;
    return null;
  } catch {
    return null;
  }
}

function haversine(lat1, lon1, lat2, lon2) {
  const toRad = (v) => (v * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}



  // -------------------------------
  // SUBMIT COMPLAINT
  // -------------------------------
  async function submitComplaint() {
    if (!selectedProduct) return alert("Select a product first!");
    if (!callInfo.CallType) return alert("Select Call Type");
    if (!callInfo.CallerMobile) return alert("Enter Caller Mobile");
    if (!callInfo.CustomerRemarks) return alert("Enter Customer Remarks");

    const payload = {
      customer,
      product: selectedProduct,
      callInfo,
    };

    const res = await fetch(
      "http://localhost:5000/api/complaints/register",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );

    const data = await res.json();

    if (data.success) {
      alert("Complaint Registered Successfully!");
      navigate("/call-centre/dashboard");
    } else {
      alert("Error: " + data.error);
    }
  }

  // -------------------------------
  // UI START
  // -------------------------------
  if (!customer) return <p>Please select a customer first.</p>;

  return (
    <div style={{ padding: 20 }}>
      <h2>Products for Customer: {customer.Name}</h2>

      <button
        style={{ padding: "8px 12px", marginBottom: 10 }}
        onClick={() => navigate("/call-centre/register")}>Register Product
      </button>
      {loading ? (
        <p>Loading...</p>
      ) : products.length === 0 ? (
        <p>No products found.</p>
      ) : (
        <table className="border-collapse border border-gray-400 w-full mb-6">
          <thead>
            <tr>
              <th>Product</th>
              <th>Brand</th>
              <th>Group</th>
              <th>Serial No</th>
              <th>Warranty</th>
              <th>Purchase</th>
              <th>Dealer</th>
              <th>Prev Calls</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.Id}>
                <td>{p.Product}</td>
                <td>{p.Brand}</td>
                <td>{p.ProductGroup}</td>
                <td>{p.ProductSerialNo}</td>
                <td>{p.WarrantyStatus}</td>
                <td>
                  {p.PurchaseDate
                    ? new Date(p.PurchaseDate).toLocaleDateString()
                    : "-"}
                </td>
                <td>{p.DealerName}</td>
                <td>{p.PreviousCalls}</td>
                <td>
                  <button onClick={() => handleViewDetails(p)}>
                    View Details
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* ---------------- PRODUCT SELECTED ---------------- */}
      {selectedProduct && (
        <>
          <h2>Customer Information</h2>
          <form className="p-3" style={{ border: "1px solid #ccc", padding: 12 }}>
            {[
              { label: "Name :", value: customer.Name },
              { label: "Mobile :", value: customer.MobileNo },
              { label: "Email :", value: customer.Email },
              { label: "Address :", value: customer.Address },
              { label: "City :", value: customer.City },
              { label: "State :", value: customer.State },
              { label: "Pincode :", value: customer.PinCode },
            ].map((f) => (
              <div key={f.label} style={{ marginBottom: 6 }}>
                <label className="p-5 font-bold">{f.label}</label>
                <input value={f.value || ""} readOnly />
              </div>
            ))}
          </form>

          <h2 style={{ marginTop: 20 }}>Product Information</h2>
          <form
            style={{
              border: "1px solid #ccc",
              padding: 12,
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 10,
            }}>
            {[
              "ProductGroup",
              "Brand",
              "Product",
              "Model",
              "ModelDescription",
              "PurchaseDate",
              "ProductSerialNo",
              "DealerName",
              "WarrantyStatus",
              "PreviousCalls",
            ].map((field) => (
              <div key={field}>
                <label className="p-3 font-bold">{field}</label>
                <input
                  value={
                    field === "PurchaseDate"
                      ? selectedProduct.PurchaseDate
                        ? new Date(
                            selectedProduct.PurchaseDate
                          ).toLocaleDateString()
                        : "-"
                      : selectedProduct[field] || ""
                  }
                  readOnly/>
              </div>
            ))}
          </form>

          {/* ---------------- CALL INFORMATION ---------------- */}
          <h2 style={{ marginTop: 20 }}>Call Information</h2>

          <form
            style={{
              border: "1px solid #aaa",
              padding: 15,
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 10,
            }}  >
            <div>
              <label className="p-2 font-bold">Call Type *</label>
              <select
                value={callInfo.CallType}
                onChange={(e) =>
                  setCallInfo({ ...callInfo, CallType: e.target.value })
                }>
                <option value="">Select</option>
                <option value="Installation">Installation</option>
                <option value="Service">Service</option>
                <option value="Complaint">Complaint</option>
              </select>
            </div>

            <div>
              <label className="p-2 font-bold">Appointment Date</label>
              <input
                type="date"
                value={callInfo.AppointmentDate}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    AppointmentDate: e.target.value,
                  })
                } />
            </div>

            <div>
              <label className="p-2 font-bold">Appointment Time</label>
              <input
                type="time"
                value={callInfo.AppointmentTime}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    AppointmentTime: e.target.value,
                  })
                } />
            </div>

            <div>
              <label className="p-2 font-bold">Caller Type</label>
              <select
                value={callInfo.CallerType}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    CallerType: e.target.value,
                  })}>
                <option>Customer</option>
                <option>Service Center</option>
              </select>
            </div>

            <div>
              <label className="p-2 font-bold">Caller Mobile *</label>
              <input
                value={callInfo.CallerMobile}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    CallerMobile: e.target.value,
                  })
                } />
            </div>

            <div style={{ gridColumn: "span 2" }}>
              <label className="p-2 font-bold">Customer Remarks *</label>
              <textarea
                value={callInfo.CustomerRemarks}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    CustomerRemarks: e.target.value,
                  })
                }/>
            </div>

            <div>
              <label className="p-2 font-bold">Dealer Name</label>
              <input
                value={callInfo.DealerName}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    DealerName: e.target.value,
                  })
                }/>
            </div>

            <div>
              <label className="p-2 font-bold">Remarks</label>
              <input
                value={callInfo.Remarks}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    Remarks: e.target.value,
                  })
                }/>
            </div>

            <div>
              <label className="p-2 font-bold">Call Source *</label>
              <select
                value={callInfo.CallSource}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    CallSource: e.target.value,
                  })
                }>
                <option>Voice</option>
                <option>WhatsApp</option>
                <option>Online</option>
                
              </select>
            </div>

            <div>
              <label className="p-2 font-bold">Contact Person</label>
              <input
                value={callInfo.ContactPerson}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    ContactPerson: e.target.value,
                  })
                }/>
            </div>

            <div>
              <label className="p-2 font-bold">Contact Person Mobile</label>
              <input
                value={callInfo.ContactPersonMobile}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    ContactPersonMobile: e.target.value,
                  })
                } />
            </div>

            <div>
              <label className="p-2 font-bold">Qty *</label>
              <input
                type="number"
                value={callInfo.Qty}
                onChange={(e) =>
                  setCallInfo({
                    ...callInfo,
                    Qty: Number(e.target.value),
                  })
                }/>
            </div>

            <div style={{ gridColumn: "span 2" }}>
              <button
                type="button"
                disabled={assigning}
                onClick={assignNearestCenter} >
                {assigning
                  ? "Assigning..."
                  : "Assign Nearest Service Center"}
              </button>
            </div>

            {callInfo.AssignedCenter && (
              <>
                <div>
                  <label className="p-2 font-bold">Assigned Center:</label>
                  <input className="p-2 font-semibold" value={callInfo.AssignedCenter} readOnly />
                </div>

                <div>
                  <label className="p-2 font-bold">Distance</label>
                  <input className="p-2 font-semibold" value={callInfo.Distance} readOnly />
                </div>

                {callInfo.OutCity && (
                  <div style={{ color: "red", fontWeight: "bold" }}>
                    OUT CITY CALL
                  </div>
                )}
              </>
            )}
          </form>


          <button
            style={{
              marginTop: 20,
              padding: "10px 15px",
              background: "green",
              color: "white",
            }}
            onClick={submitComplaint}> Submit Complaint
          </button>
        </>
      )}
    </div>
  );
}

import { useState } from "react";
import { searchCustomers } from "../api";
import CustomerCard from "./CustomerCard";
import AddCustomerForm from "./AddCustomerForm";

export default function SearchForm() {
  const [result, setResult] = useState(null);

  const [form, setForm] = useState({
    mobileNo: "",
    altMobile: "",
    productSerialNo: "",
    customerCode: "",
    name: "",
    state: "",
    city: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const response = await searchCustomers(form);
      setResult(response);
    } catch (err) {
      console.error("Search failed:", err);
      alert("Search failed");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-4xl mx-auto bg-white shadow-md p-6 rounded">
        <h2 className="text-2xl font-bold mb-4">Customer Search</h2>

        <form onSubmit={handleSearch} className="grid grid-cols-2 gap-4 mb-6">
          <input name="mobileNo" placeholder="Mobile No" value={form.mobileNo} onChange={handleChange} />
          <input name="altMobile" placeholder="Alt Mobile" value={form.altMobile} onChange={handleChange} />
          <input name="productSerialNo" placeholder="Product Serial No" value={form.productSerialNo} onChange={handleChange} />
          <input name="customerCode" placeholder="Customer Code" value={form.customerCode} onChange={handleChange} />
          <input name="name" placeholder="Name" value={form.name} onChange={handleChange} />
          <input name="state" placeholder="State" value={form.state} onChange={handleChange} />
          <input name="city" placeholder="City" value={form.city} onChange={handleChange} />

          <div className="col-span-2">
            <button type="submit" className="bg-blue-600 text-black px-4 py-2 rounded">
              Search
            </button>
          </div>
        </form>

        {/* Result */}
        {result && result.exists && <CustomerCard customer={result.customer} />}
        {result && !result.exists && <AddCustomerForm onCreated={() => setResult(null)} />}
      </div>
    </div>
  );
}


import React, { useState } from "react";
import { createCustomer } from "../api";

export default function AddCustomerForm({ onCreated }) {
  const [form, setForm] = useState({
    name: "",
    mobileNo: "",
    altMobileNo: "",
    email: "",
    address: "",
    landmark: "",
    state: "",
    city: "",
    area: "",
    pinCode: "",
    preferredLanguage: "",
    customerCode: "",
    customerType: "",
    customerPriority: "",
  });
  

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const res = await createCustomer(form);
    if (onCreated) onCreated(res.customer);
  }

  return (
    <form 
      onSubmit={handleSubmit} 
      style={{
        border: "1px dashed #615959", 
        padding: 12,
        display: "grid",
        gap: "8px"
      }}>
      <h3>Add New Customer</h3>

      <input placeholder="Name" required onChange={(e) => update("name", e.target.value)} />
      <input placeholder="Mobile No" required onChange={(e) => update("mobileNo", e.target.value)} />
      <input placeholder="Alternate Mobile" onChange={(e) => update("altMobileNo", e.target.value)} />
      <input placeholder="Email" onChange={(e) => update("email", e.target.value)} />
      
      <input placeholder="Address" required onChange={(e) => update("address", e.target.value)} />
      <input placeholder="Landmark" onChange={(e) => update("landmark", e.target.value)} />

      <input placeholder="State" required onChange={(e) => update("state", e.target.value)} />
      <input placeholder="City" required onChange={(e) => update("city", e.target.value)} />

      <input placeholder="Area" onChange={(e) => update("area", e.target.value)} />
      <input placeholder="Pincode" onChange={(e) => update("pinCode", e.target.value)} />

      <input placeholder="Preferred Language" onChange={(e) => update("preferredLanguage", e.target.value)} />
      <input placeholder="Customer Code" onChange={(e) => update("customerCode", e.target.value)} />
      <input placeholder="Customer Type" onChange={(e) => update("customerType", e.target.value)} />
      <input placeholder="Customer Priority" onChange={(e) => update("customerPriority", e.target.value)} />

      <button type="submit" style={{ marginTop: 10 }}>Create Customer</button>
    </form>
  );
}

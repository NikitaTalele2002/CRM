import React, { useEffect, useState } from 'react';

// Component to upload Excel file
function UploadExcel({ onUploaded }) {
  async function handleUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('http://localhost:5000/api/location/uploadExcel', {
        method: 'POST',
        body: formData,
      });
      const js = await res.json();
      alert(js.message || 'Upload complete');
      if (onUploaded) onUploaded();
    } catch (err) {
      alert('Upload failed');
    }
  }

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium border-3">Upload Excel</label>
      <input type="file" accept=".xlsx,.xls" onChange={handleUpload} />
    </div>
  );
}

export default function PincodeMasters() {
  const [states, setStates] = useState([]);
  const [cities, setCities] = useState([]);
  const [pincodes, setPincodes] = useState([]);

  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedPincode, setSelectedPincode] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load states initially
  useEffect(() => {
    loadStates();
  }, []);

  // Reload cities when state changes
  useEffect(() => {
    setSelectedCity('');
    setSelectedPincode('');
    setPincodes([]);
    if (selectedState) loadCities(selectedState);
    else setCities([]);
  }, [selectedState]);

  // Reload pincodes when city changes
  useEffect(() => {
    setSelectedPincode('');
    if (selectedCity) loadPincodes(selectedCity);
    else setPincodes([]);
  }, [selectedCity]);

  async function loadStates() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('http://localhost:5000/api/location/states');
      const js = await res.json();
      setStates(Array.isArray(js) ? js : []);
    } catch (err) {
      setError('Failed to load states');
    } finally {
      setLoading(false);
    }
  }

  async function loadCities(stateId) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`http://localhost:5000/api/location/cities?state=${encodeURIComponent(stateId)}`);
      const js = await res.json();
      setCities(Array.isArray(js) ? js : []);
    } catch (err) {
      setError('Failed to load cities');
    } finally {
      setLoading(false);
    }
  }

  async function loadPincodes(cityId) {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`http://localhost:5000/api/location/pincodes?city=${encodeURIComponent(cityId)}`);
      const js = await res.json();
      setPincodes(Array.isArray(js) ? js : []);
    } catch (err) {
      setError('Failed to load pincodes');
    } finally {
      setLoading(false);
    }
  }

  function onSubmit(e) {
    e.preventDefault();
    if (!selectedState || !selectedCity || !selectedPincode) {
      setError('Please select state, city and pincode.');
      return;
    }
    setError(null);
    alert(`Saved: State=${selectedState}, City=${selectedCity}, Pincode=${selectedPincode}`);
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-semibold mb-4">Pincode Masters</h1>

      {/* Upload Excel */}
      <UploadExcel onUploaded={loadStates} />

      <form onSubmit={onSubmit} className="space-y-4 bg-white p-4 rounded shadow">
        <div>
          <label className="block text-sm font-medium">State</label>
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="mt-1 block w-full border rounded p-2">
            <option value="">-- Select State --</option>
            {states.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium">City</label>
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            disabled={!selectedState}
            className="mt-1 block w-full border rounded p-2">
            <option value="">-- Select City --</option>
            {cities.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium">Pincode</label>
          <select
            value={selectedPincode}
            onChange={(e) => setSelectedPincode(e.target.value)}
            disabled={!selectedCity}
            className="mt-1 block w-full border rounded p-2">
            <option value="">-- Select Pincode --</option>
            {pincodes.map((p) => (
              <option key={p} value={p}>{p}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <button type="submit" className="px-4 py-2 bg-green-600 text-black rounded">Save</button>
          <button type="button" onClick={() => {
            setSelectedState('');
            setSelectedCity('');
            setSelectedPincode('');
            setCities([]);
            setPincodes([]);
          }} className="px-4 py-2 bg-gray-200 rounded">Reset</button>
          {loading && <div className="text-sm text-gray-600 ml-auto">Loading...</div>}
        </div>

        {error && <div className="text-red-600">{error}</div>}
      </form>

      <div className="mt-6 bg-white p-4 rounded shadow">
        <h2 className="font-semibold mb-2">Current Selection</h2>
        <div>State: <strong>{selectedState}</strong></div>
        <div>City: <strong>{selectedCity}</strong></div>
        <div>Pincode: <strong>{selectedPincode}</strong></div>
      </div>
    </div>
  );
}

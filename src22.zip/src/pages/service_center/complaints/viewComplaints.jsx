import React, { useEffect, useState } from "react";

export default function ViewComplaints() {
  const [data, setData] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchComplaints();
  }, []);

  async function fetchComplaints() {
    try {
      setLoading(true);
      setError(null);
      const selectedCenter = localStorage.getItem("selectedServiceCenterId");
      let url = "http://localhost:5000/api/complaints";
      if (selectedCenter) url += `?centerId=${encodeURIComponent(selectedCenter)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(res.statusText || "API Not Found");
      const result = await res.json();
      setData(result.complaints || []);
      setTechnicians(result.technicians || []);
    } catch (err) {
      console.error("Error fetching complaints:", err);
      setData([]);
      setTechnicians([]);
      setError(err.message || String(err));
    } finally {
      setLoading(false);
    }
  }

  async function assignTechnician(id, isComplaint, technicianId) {
    try {
      const payload = isComplaint
        ? { complaintId: Number(id), technicianId: Number(technicianId) }
        : { productId: Number(id), technicianId: Number(technicianId) };

      const res = await fetch("http://localhost:5000/api/complaints/assign-technician", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const result = await res.json();
      alert(result.message || "Assigned");

      setData((prev) => prev.filter((r) => {
        const compId = r.ComplaintId ?? null;
        const prodId = r.ProductId ?? null;
        if (isComplaint) return Number(compId) !== Number(id);
        return Number(prodId) !== Number(id);
      }));

      fetchComplaints();
    } catch (err) {
      console.error("Error assigning technician:", err);
      alert("Assignment failed");
    }
  }

  const unassigned = (data || []).filter((r) => !(r.AssignedTechnicianId ?? r.assignedTechnicianId));

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Complaints List (Unassigned)</h1>

      <div className="mb-4">
        <button onClick={fetchComplaints} className="px-4 py-2 bg-blue-600 text-white rounded">Refresh</button>
        <span className="ml-4">Not Allocated to Technician: <strong>{unassigned.length}</strong></span>
        {loading && <span className="ml-4 text-sm text-gray-600">Loading...</span>}
        {error && <div className="mt-2 text-red-600">{error}</div>}
      </div>

      <div className="overflow-x-auto bg-white p-4 rounded shadow">
        <table className="min-w-full table-auto border">
          <thead>
            <tr className="bg-gray-100">
              <th className="p-2 border">Call Id</th>
              <th className="p-2 border">Date</th>
              <th className="p-2 border">Customer Name</th>
              <th className="p-2 border">Mobile</th>
              <th className="p-2 border">City / Zone</th>
              <th className="p-2 border">Product</th>
              <th className="p-2 border">Model</th>
              <th className="p-2 border">Serial No</th>
              <th className="p-2 border">Call Status</th>
              <th className="p-2 border">Technician</th>
              <th className="p-2 border">Assign</th>
            </tr>
          </thead>
          <tbody>
            {unassigned.length === 0 && (
              <tr>
                <td colSpan={11} className="p-4 text-center text-gray-600">No unassigned complaints found</td>
              </tr>
            )}

            {unassigned.map((row) => (
              <tr key={row.ComplaintId ?? row.ProductId ?? `${row.MobileNo}-${row.ProductSerialNo}` } className="border-t">
                <td className="p-2 border">{row.ComplaintId ?? '-'}</td>
                <td className="p-2 border">{row.CreatedAt ? new Date(row.CreatedAt).toLocaleString() : '-'}</td>
                <td className="p-2 border">{row.CustomerName}</td>
                <td className="p-2 border">{row.MobileNo}</td>
                <td className="p-2 border">{row.City}</td>
                <td className="p-2 border">{row.Product}</td>
                <td className="p-2 border">{row.Model}</td>
                <td className="p-2 border">{row.ProductSerialNo}</td>
                <td className="p-2 border">{row.CallStatus}</td>
                <td className="p-2 border">{row.AssignedTechnicianName || '-'}</td>
                <td className="p-2 border">
                  <select defaultValue="" onChange={(e) => {
                    const id = row.ComplaintId ?? row.ProductId;
                    const isComplaint = !!row.ComplaintId;
                    assignTechnician(id, isComplaint, e.target.value);
                  }} className="border p-1">
                    <option value="" disabled>Select Technician</option>
                    {technicians.map((t) => (
                      <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({ complaintId: productId, technicianId }),
//       });

//       const result = await res.json();
//       alert(result.message || "Assigned");
//       fetchComplaints();
//     } catch (err) {
//       console.error("Error assigning technician:", err);
//       alert("Assignment failed");
//     }
//   }

//   return (
//     <div className="p-6">
//       <h1 className="text-2xl font-bold mb-4">Complaints List</h1>

//       <table className="border border-gray-300 w-full">
//         <thead>
//           <tr className="bg-gray-200">
//             <th className="p-2">Customer Name</th>
//             <th>Mobile</th>
//             <th>City</th>
//             <th>Product</th>
//             <th>Model</th>
//             <th>Serial No</th>
//             <th>Warranty</th>
//             <th>Call Status</th>
//             <th>Assign Technician</th>
//           </tr>
//         </thead>
//         <tbody>
//           {data.map((row) => (
//             <tr key={row.ProductId} className="border-t">
//               <td className="p-2">{row.CustomerName}</td>
//               <td>{row.MobileNo}</td>
//               <td>{row.City}</td>
//               <td>{row.Product}</td>
//               <td>{row.Model}</td>
//               <td>{row.ProductSerialNo}</td>
//               <td>{row.WarrantyStatus}</td>
//               <td>{row.CallStatus}</td>
//               <td>
//                 <select
//                   onChange={(e) => assignTechnician(row.ProductId, e.target.value)}
//                   defaultValue=""
//                 >
//                   <option value="" disabled>Select Technician</option>
//                   {technicians.map((t) => (
//                     <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
//                   ))}
//                 </select>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }







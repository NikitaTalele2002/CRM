import React, { useEffect, useState } from 'react';

export default function AssignComplaint() {
  const [filters, setFilters] = useState({
    callId: '',
    dateFrom: '',
    dateTo: '',
    zone: '',
    callType: '',
    mobile: '',
    dealer: '',
    technician: 'all',
    unAllocatedOnly: false,
  });

  const [complaints, setComplaints] = useState([]);
  const [technicians, setTechnicians] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // load complaints and technicians for current center on mount
    fetchData();
  }, []);

  async function fetchData() {
    try {
      setLoading(true);
      setError(null);
      const selectedCenter = localStorage.getItem('selectedServiceCenterId');
      let url = 'http://localhost:5000/api/complaints';
      if (selectedCenter) url += `?centerId=${encodeURIComponent(selectedCenter)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(res.statusText || 'API Error');
      const js = await res.json();
      setComplaints(js.complaints || []);
      setTechnicians(js.technicians || []);
    } catch (err) {
      console.error('fetchData error', err);
      setError(err.message || String(err));
      setComplaints([]);
      setTechnicians([]);
    } finally {
      setLoading(false);
    }
  }

  function onChange(e) {
    const { name, value, type, checked } = e.target;
    setFilters((p) => ({ ...p, [name]: type === 'checkbox' ? checked : value }));
  }

  function resetFilters() {
    setFilters({ callId: '', dateFrom: '', dateTo: '', zone: '', callType: '', mobile: '', dealer: '', technician: 'all', unAllocatedOnly: false });
  }

  function applyFilters(items) {
    return items.filter((it) => {
      // Call Id
      if (filters.callId) {
        const cid = String(it.ComplaintId ?? '').toLowerCase();
        if (!cid.includes(filters.callId.toLowerCase())) return false;
      }
      // Date range
      if (filters.dateFrom) {
        const from = new Date(filters.dateFrom);
        const created = new Date(it.CreatedAt || it.createdAt || it.CreatedOn || null);
        if (isNaN(created.getTime()) || created < from) return false;
      }
      if (filters.dateTo) {
        const to = new Date(filters.dateTo);
        const created = new Date(it.CreatedAt || it.createdAt || it.CreatedOn || null);
        if (isNaN(created.getTime()) || created > to) return false;
      }
      // Zone (match City)
      if (filters.zone) {
        if (!String(it.City || '').toLowerCase().includes(filters.zone.toLowerCase())) return false;
      }
      // Call Type
      if (filters.callType) {
        if (!String(it.CallStatus || it.CallType || '').toLowerCase().includes(filters.callType.toLowerCase())) return false;
      }
      // Mobile
      if (filters.mobile) {
        if (!String(it.MobileNo || '').includes(filters.mobile)) return false;
      }
      // Dealer / ASP/DSA
      if (filters.dealer) {
        if (!String(it.DealerName || it.Dealer || '').toLowerCase().includes(filters.dealer.toLowerCase())) return false;
      }
      // Technician
      if (filters.technician && filters.technician !== 'all') {
        const assignedId = it.AssignedTechnicianId ?? it.assignedTechnicianId ?? null;
        if (String(assignedId) !== String(filters.technician)) return false;
      }
      // Un-allocated only
      if (filters.unAllocatedOnly) {
        const assignedId = it.AssignedTechnicianId ?? it.assignedTechnicianId ?? null;
        if (assignedId) return false;
      }

      return true;
    });
  }

  const filtered = applyFilters(complaints || []);
  const notAllocatedCount = (complaints || []).filter((c) => !(c.AssignedTechnicianId ?? c.assignedTechnicianId)).length;

  async function assignTechnician(complaintId, techId) {
    try {
      const res = await fetch('http://localhost:5000/api/complaints/assign-technician', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ complaintId, technicianId: Number(techId) }),
      });
      const js = await res.json();
      alert(js.message || 'Assigned');
      fetchData();
    } catch (err) {
      console.error('assignTechnician error', err);
      alert('Assignment failed');
    }
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Call Management - Call Update - Allocation To Technician</h1>

      <div className="mb-4 bg-white p-4 rounded shadow">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Call Id</label>
            <input name="callId" value={filters.callId} onChange={onChange} className="mt-1 block w-full border rounded p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium">Mobile No</label>
            <input name="mobile" value={filters.mobile} onChange={onChange} className="mt-1 block w-full border rounded p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium">Date From</label>
            <input name="dateFrom" type="date" value={filters.dateFrom} onChange={onChange} className="mt-1 block w-full border rounded p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium">Date To</label>
            <input name="dateTo" type="date" value={filters.dateTo} onChange={onChange} className="mt-1 block w-full border rounded p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium">Zone</label>
            <select name="zone" value={filters.zone} onChange={onChange} className="mt-1 block w-full border rounded p-2">
              <option value="">-- Any --</option>
              <option value="North">North</option>
              <option value="South">South</option>
              <option value="East">East</option>
              <option value="West">West</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">Call Type</label>
            <select name="callType" value={filters.callType} onChange={onChange} className="mt-1 block w-full border rounded p-2">
              <option value="">-- Any --</option>
              <option value="Service">Service</option>
              <option value="Installation">Installation</option>
              <option value="Repair">Repair</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium">ASP/DSA</label>
            <input name="dealer" value={filters.dealer} onChange={onChange} className="mt-1 block w-full border rounded p-2" placeholder="ADINATH ENTERPRISES" />
          </div>
          <div>
            <label className="block text-sm font-medium">Technician</label>
            <select name="technician" value={filters.technician} onChange={onChange} className="mt-1 block w-full border rounded p-2">
              <option value="all">- All -</option>
              {technicians.map((t) => (
                <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
              ))}
            </select>
          </div>
          <div className="flex items-end">
            <label className="inline-flex items-center">
              <input type="checkbox" name="unAllocatedOnly" checked={filters.unAllocatedOnly} onChange={onChange} className="mr-2" />
              Un-Allocated only
            </label>
          </div>
        </div>

        <div className="mt-4 flex items-center gap-2">
          <button onClick={fetchData} className="px-4 py-2 bg-blue-600 text-black rounded">Refresh</button>
          <button onClick={resetFilters} className="px-4 py-2 bg-gray-200 rounded">Reset</button>
          <div className="ml-auto text-sm">Not Allocated to Technician: <strong>{notAllocatedCount}</strong></div>
        </div>
      </div>

      <div className="bg-white p-4 rounded shadow">
        <h2 className="font-semibold mb-2">Search Results {loading && '(loading...)'}</h2>
        {error && <div className="text-red-600 mb-2">{error}</div>}

        <div className="overflow-x-auto">
          <table className="min-w-full border">
            <thead>
              <tr className="bg-gray-100">
                <th className="p-2 border">Call Id</th>
                <th className="p-2 border">Date</th>
                <th className="p-2 border">Customer</th>
                <th className="p-2 border">Mobile</th>
                <th className="p-2 border">Zone</th>
                <th className="p-2 border">Call Type</th>
                <th className="p-2 border">ASP/DSA</th>
                <th className="p-2 border">Technician</th>
                <th className="p-2 border">Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((row) => (
                <tr key={row.ComplaintId ?? row.ProductId ?? `${row.MobileNo}-${row.ProductSerialNo}` } className="border-t">
                  <td className="p-2 border">{row.ComplaintId ?? '-'}</td>
                  <td className="p-2 border">{row.CreatedAt ? new Date(row.CreatedAt).toLocaleString() : '-'}</td>
                  <td className="p-2 border">{row.CustomerName}</td>
                  <td className="p-2 border">{row.MobileNo}</td>
                  <td className="p-2 border">{row.City}</td>
                  <td className="p-2 border">{row.CallStatus}</td>
                  <td className="p-2 border">{row.DealerName || '-'}</td>
                  <td className="p-2 border">{row.AssignedTechnicianName || '-'}</td>
                  <td className="p-2 border">
                    <select defaultValue="" onChange={(e) => assignTechnician(row.ComplaintId, e.target.value)}>
                      <option value="" disabled>Select</option>
                      {technicians.map((t) => (
                        <option key={t.Id} value={t.Id}>{t.TechnicianName}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className="p-4 text-center text-gray-600">No records found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

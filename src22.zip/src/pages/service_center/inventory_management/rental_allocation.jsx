import React from "react";

export default function RentalAllocation() {
  const initialFormData = {
    productGroup: "",
    productType: "",
    model: "",
    partDescription: "",
    technician: "",
    inventoryType: "Good",
    remarks: "",
  };

  const [formData, setFormData] = React.useState(initialFormData);

  // Static data
  const productGroups = ["Digital Lock", "Fans", "Irons"];

  const productTypeMap = {
    "Digital Lock": ["Door Lock"],
    Fans: [
      "Ceiling Fan",
      "Table Fan",
      "Exhaust Fan",
      "Wall Fan",
      "Oscillation Fan",
      "Pedestal Fan",
    ],
    Irons: ["Dry Iron", "Steam Iron"],
    Lightings: ["LED Lighting"],
    "Room Heater": ["Room Heater"],
    "Switchgear MCB": ["DB", "Isolater", "MCB dp"],
    "Switchgear RCCB": [
      "ACCL Switchgear",
      "MCCB Switchgear",
      "RCCB Switchgear",
    ],
  };

  const modelMap = {
    "Door Lock": ["DL100", "DL200"],
    "Ceiling Fan": ["CF-Alpha", "CF-Beta"],
    "Table Fan": ["TF-Standard", "TF-Pro"],
    "Exhaust Fan": ["EF-100", "EF-200"],
    "Wall Fan": ["WF-std", "WF-Pro"],
    "Oscillation Fan": ["OF-standard", "OF-Pro"],
    "Pedestal Fan": ["PF-Standard", "Pf-Pro"],
    "Dry Iron": ["DI-1", "DI-2"],
    "Steam Iron": ["SI-100", "SI-200"],
    "Travel Iron": ["TI-Mini", "TI-Max"],
  };

  const technicians = ["John Doe", "Jane Smith", "Bob Lee"];

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "productGroup") {
      setFormData((prev) => ({
        ...prev,
        productGroup: value,
        productType: "",
        model: "",
      }));
    } else if (name === "productType") {
      setFormData((prev) => ({
        ...prev,
        productType: value,
        model: "",
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Form submitted successfully!");
    console.log("Submitted Data:", formData);
    setFormData(initialFormData);
  };

  const productTypes = formData.productGroup
    ? productTypeMap[formData.productGroup]
    : [];

  const models = formData.productType ? modelMap[formData.productType] : [];

  return (
    <div>
      <h2 className="text-lg font-bold">Rental Allocation</h2>
      <h4 className="font-bold text-red-500 mt-2">
        Allocate inventory to Technician
      </h4>

      <form onSubmit={handleSubmit} className="mt-4">
        <table className="border border-gray-300 w-full">
          <tbody>
            {/* Product Group */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold w-1/3">Product Group</td>
              <td className="p-2">
                <select
                  name="productGroup"
                  value={formData.productGroup}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full" >
                  <option value="">Select Product Group</option>
                  {productGroups.map((group) => (
                    <option key={group} value={group}>
                      {group}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Product Type */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Product Type</td>
              <td className="p-2">
                <select
                  name="productType"
                  value={formData.productType}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full"
                  disabled={!formData.productGroup} >
                  <option value="">Select Product Type</option>
                  {productTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Model */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Model</td>
              <td className="p-2">
                <select
                  name="model"
                  value={formData.model}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full"
                  disabled={!formData.productType} >
                  <option value="">Select Model</option>
                  {models.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Part Description */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Part Description</td>
              <td className="p-2">
                <input
                  type="text"
                  name="partDescription"
                  value={formData.partDescription}
                  onChange={handleChange}
                  placeholder="Enter part description"
                  className="border border-gray-300 p-2 rounded w-full"
                />
              </td>
            </tr>

            {/* Technician */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Technician</td>
              <td className="p-2">
                <select
                  name="technician"
                  value={formData.technician}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full"
                >
                  <option value="">Select Technician</option>
                  {technicians.map((tech) => (
                    <option key={tech} value={tech}>
                      {tech}
                    </option>
                  ))}
                </select>
              </td>
            </tr>

            {/* Inventory Type */}
            <tr className="border border-gray-300">
              <td className="p-2 font-semibold">Inventory Type</td>
              <td className="p-2">
                <select
                  name="inventoryType"
                  value={formData.inventoryType}
                  onChange={handleChange}
                  className="border border-gray-300 p-2 rounded w-full"
                >
                  <option value="Good">Good</option>
                  <option value="Damaged">Damaged</option>
                  <option value="Faulty">Faulty</option>
                </select>
              </td>
            </tr>

            {/* Remarks */}
            <tr className="border border-gray-300 align-top">
              <td className="p-2 font-semibold">Remarks</td>
              <td className="p-2">
                <textarea
                  name="remarks"
                  value={formData.remarks}
                  onChange={handleChange}
                  placeholder="Enter remarks"
                  rows="3"
                  className="border border-gray-300 p-2 rounded w-full"
                />
              </td>
            </tr>

            {/* Submit */}
            <tr>
              <td colSpan="2" className="text-center p-4">
                <button
                  type="submit"
                  className="bg-blue-600 hover:bg-blue-700 text-red-500 px-6 py-2 rounded"
                >
                  Allocate
                </button>
              </td>
            </tr>

          </tbody>
        </table>
      </form>
    </div>
  );
}

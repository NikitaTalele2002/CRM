import React from "react";
import ProductReplacementComponent from "../../../components/service_center/product_replacement/ProductReplacementComponent";
import ServiceCenterLayout from "../serviceCenterLayout";

export default function ProductReplacement()
{
    return(
        <ServiceCenterLayout>
            <ProductReplacementComponent/>
        </ServiceCenterLayout>
    )
}

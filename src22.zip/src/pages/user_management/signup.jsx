import React from "react";
export default function Signup() {
    const [Username, setUsername] = React.useState('');
    const [Password, setPassword] = React.useState('');
    const [ConfirmPassword, setConfirmPassword] = React.useState('');
    const handleLogin = async (e) => {
        e.preventDefault();
        // login logic here
        if (Username && Password && ConfirmPassword) {
            // API call
            console.log('Signing up...', { Username, Password, ConfirmPassword });
        }
    }
  return (
    <div className="min-w-screen flex flex-col justify-center items-center bg-gray-100">
            <div className="w-96 p-6 bg-white rounded shadow-md">
                <h1 className="text-blue-500 text-xl font-bold mb-4">Login</h1>
                <form onSubmit={handleLogin} className='text-xl'>
                    <div>
                        <label className='block mb-2'>Username</label>
                        <input
                            type="text"
                            placeholder="Enter Username"
                            value={Username}        
                            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label className='block mb-2'>Email</label>
                        <input
                            type="email"
                            placeholder="Enter your email"
                            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required
                        />
                    </div>
                    <div>
                        <label className='block mb-2'>Password</label>
                        <input
                            type="password"
                            placeholder="Password"
                            value={Password}
                            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label className='block mb-2'>Confirm Password</label>
                        <input
                            type="password"
                            placeholder="Confirm Password"
                            value={ConfirmPassword}
                            className="w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required 
                        />
                    </div>
                    <div>
                        <label className='block mb-2'>Phone Number</label>
                        <input 
                            type='tel'
                            placeholder="Enter your phone number"
                            className='w-full px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500'
                            required
                        />
                    </div>
                    <div>
                       <a onClick={() => window.location.href = '/login'} className="text-blue-500 hover:underline italic">Login</a>
                    </div>
                    <div>
                        <button type="submit" className="mt-4 w-full bg-blue-500 text-black py-2 rounded">Sign Up</button>
                    </div>
                
                </form>
            </div>
        </div>
  );
}
    